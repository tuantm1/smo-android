package com.smile.studio.libsmilestudio.recyclerviewer;

import android.view.KeyEvent;

/**
 * Created by admin on 23/07/2017.
 */

public interface OnInterceptListener {
    boolean onIntercept(KeyEvent event);
}
