package com.smile.studio.libsmilestudio.utils;

public class VersionSDK {
	
	public static final int versionSDK = 1;
}
