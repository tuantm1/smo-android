package com.smile.studio.libsmilestudio.recyclerviewer;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public abstract class BaseRecyclerViewHolder extends RecyclerView.ViewHolder {

    public BaseRecyclerViewHolder(View itemView) {
        super(itemView);
    }

    public abstract void focusIn();

    public abstract void focusOut();
}
