package com.smile.studio.sapportal.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.fragment.DetailDeliverGuaranteeFragment
import com.smile.studio.sapportal.network.model.DeliverGuarantee
import kotlinx.android.synthetic.main.activity_detail.*

class DetailActivity :BaseActivity() {

    companion object{
        val TYPE = "Type"
        fun openActivity(mContext : Context, data : Any){
            val intent = Intent(mContext, DetailActivity::class.java)
            if(data is DeliverGuarantee){
                intent.putExtra(TYPE, 1)
                intent.putExtra(DeliverGuarantee::class.java.simpleName, data)
            }
            mContext.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        val type = intent.getIntExtra(TYPE, 1)
        var data = when(type){
            1 -> {
                shareViewModel?.setData(intent.getParcelableExtra<DeliverGuarantee>(DeliverGuarantee::class.java.simpleName))
                onChangeFragment(DetailDeliverGuaranteeFragment.newInstance(), "")
            }
            else -> null
        }

    }

}