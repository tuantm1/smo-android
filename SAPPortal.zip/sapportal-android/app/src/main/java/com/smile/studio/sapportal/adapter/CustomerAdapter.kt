package com.smile.studio.sapportal.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.AppCompatTextView
import androidx.recyclerview.widget.RecyclerView
import com.andexert.library.RippleView
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.network.model.Customer

class CustomerAdapter(val mContext: Context?, val mData: ArrayList<Customer>?) : RecyclerView.Adapter<CustomerAdapter.ViewHolder>() {

    var onItemClick: OnItemClickListenerRecyclerView? = null

    fun addAll(mData: ArrayList<Customer>) {
        this.mData?.addAll(mData)
        notifyDataSetChanged()
    }

    fun clear() {
        this.mData?.clear()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(mContext).inflate(R.layout.custom_item_customer, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return mData?.size!!
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tv_customer_id.text = "${mData?.get(position)?.uid?.trim()}"
        holder.tv_customer_name.text = "${mData?.get(position)?.username?.trim()}"
        holder.tv_customer_tax.text = "${mData?.get(position)?.tax?.trim()}"
        holder.tv_customer_phone.text = "${mData?.get(position)?.phone?.trim()}"
        holder.tv_customer_email.text = "${mData?.get(position)?.email?.trim()}"
        holder.tv_customer_address.text = "${mData?.get(position)?.address?.trim()}"
        holder.rippleView.setOnRippleCompleteListener { view ->
            onItemClick?.onClick(view, position)
        }
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val rippleView = view.findViewById<RippleView>(R.id.rippleView)
        val tv_customer_id = view.findViewById<AppCompatTextView>(R.id.tv_customer_id)
        val tv_customer_name = view.findViewById<AppCompatTextView>(R.id.tv_customer_name)
        val tv_customer_tax = view.findViewById<AppCompatTextView>(R.id.tv_customer_tax)
        val tv_customer_phone = view.findViewById<AppCompatTextView>(R.id.tv_customer_phone)
        val tv_customer_email = view.findViewById<AppCompatTextView>(R.id.tv_customer_email)
        val tv_customer_address = view.findViewById<AppCompatTextView>(R.id.tv_customer_address)
    }
}