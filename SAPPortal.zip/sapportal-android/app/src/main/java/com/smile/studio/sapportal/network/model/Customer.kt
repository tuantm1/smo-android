package com.smile.studio.sapportal.network.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Customer(

        @field:SerializedName("KUNNR")
        val uid: String? = null,

        @field:SerializedName("ROUTE")
        val rOUTE: String? = null,

        @field:SerializedName("SDT")
        val phone: String? = null,

        @field:SerializedName("VSART")
        val tax: String? = null,

        @field:SerializedName("EMAIL")
        val email: String? = null,

        @field:SerializedName("TEL_NUMBER")
        val telphone: String? = null,

        @field:SerializedName("VKORG")
        val vKORG: String? = null,

        @field:SerializedName("SPART")
        val sPART: String? = null,

        @field:SerializedName("FAX_NUMBER")
        val faxNumber: String? = null,

        @field:SerializedName("CUSTOMER_NAME")
        val username: String? = null,

        @field:SerializedName("ZCREDIT_CUS")
        val zCREDITCUS: List<String>? = null,

        @field:SerializedName("CITY")
        val city: String? = null,

        @field:SerializedName("VAT_NUMBER")
        val vATNUMBER: String? = null,

        @field:SerializedName("MOB_NUMBER")
        val mOBNUMBER: String? = null,

        @field:SerializedName("ADDRESS")
        val address: String? = null,

        @field:SerializedName("KTOKD")
        val kTOKD: String? = null,

        @field:SerializedName("VTWEG")
        val vTWEG: String? = null,

        @field:SerializedName("CZREDIT")
        val czRedit: ArrayList<String>? = null,

        @field:SerializedName("ZTERM")
        val zTERM: String? = null
) : Parcelable


