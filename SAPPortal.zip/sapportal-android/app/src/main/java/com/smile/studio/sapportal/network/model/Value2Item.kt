package com.smile.studio.sapportal.network.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug
import kotlinx.android.parcel.Parcelize

@Parcelize
class Value2Item(

        @field:SerializedName("MATNR")
        val matnr: String? = null,

        @field:SerializedName("MATNR_REFER", alternate = arrayOf("ID_MATNR_REFER"))
        val matnrRefer: String? = null,

        @field:SerializedName("VALDESCR")
        val valdescr: String? = "",

        @field:SerializedName("DESCRIPTION")
        val description: String? = null,

        @field:SerializedName("MAKTX")
        val maktx: String? = null,

        @field:SerializedName("VALUE")
        val value: String? = "",

        @field:SerializedName("LANGUAGE")
        val language: String? = null,

        @field:SerializedName("LANGUAGE_ISO")
        val languageISO: String? = null,

        @field:SerializedName("ZMBEZ")
        val zmbez: String? = null,

        @field:SerializedName("E_FLAG")
        val eFlag: String? = null,

        @field:SerializedName("E_MESSAGE")
        val eMessage: String? = null,

        ) : Parcelable {
    fun trace() {
        Debug.e("matnr: ${matnr}\nmatnrRefer: ${matnrRefer}\nvalue: ${value} \nvaldescr: ${valdescr}")
    }
}
