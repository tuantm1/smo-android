package com.smile.studio.sapportal.network.model

enum class TypeError(val value: String) {

    SUCCESS("S"), ERROR("E"), CREDIT_LIMIT_EXCEEDED("C"), REJECTED("R"), FAILE("F")
}