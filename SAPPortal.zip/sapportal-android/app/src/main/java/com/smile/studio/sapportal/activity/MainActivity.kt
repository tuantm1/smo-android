package com.smile.studio.sapportal.activity

import android.content.DialogInterface
import android.os.Bundle
import android.os.Process
import androidx.appcompat.app.AlertDialog
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.model.TypeMenu
import com.smile.studio.sapportal.network.response.Menu

class MainActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_main)
        val navView: BottomNavigationView = findViewById(R.id.nav_view)
        val navController = findNavController(R.id.nav_host_fragment)
        val mDataSAP = GlobalApp.getInstance().mDataMenu.filter { it.zzstatus?.equals(TypeMenu.MENU_SAP.value.toString())!! } as ArrayList<Menu>
        val appBarConfiguration = AppBarConfiguration(setOf(R.id.navigation_home, R.id.navigation_manager, R.id.navigation_sap, R.id.navigation_deliver, R.id.navigation_profile))
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)
    }

    override fun onBackPressed() {
        if (supportFragmentManager.backStackEntryCount > 1) {
            super.onBackPressed()
        } else {
            exitApp()
        }
    }

    private fun exitApp() {
        val alertDialog: AlertDialog.Builder? = AlertDialog.Builder(this)
        alertDialog?.setMessage(R.string.text_message_exit_application)
        alertDialog?.setNegativeButton(R.string.text_button_cancel) { dialog: DialogInterface, which: Int ->
        }
        alertDialog?.setPositiveButton(R.string.text_button_exit) { dialog: DialogInterface, which: Int ->
            Process.killProcess(Process.myPid())
        }
        alertDialog?.show()
    }
}