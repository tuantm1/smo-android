package com.smile.studio.sapportal.network.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug
import kotlinx.android.parcel.Parcelize

@Parcelize
class ItemsItem(

        @field:SerializedName("ID_ITEM")
        val idItem: String? = null,

        @field:SerializedName("ID_HEADER")
        val idHeader: String? = null,

        @field:SerializedName("id_user")
        val id_user: String? = null,

        @field:SerializedName("CHARACTERISTICS")
        var characteristics: ArrayList<CharacteristicsItem>? = ArrayList(),

        @field:SerializedName("THANH_LE")
        val thanhle: String? = null,

        @field:SerializedName("TYPE")
        var type: String? = null,

        @field:SerializedName("MATNR")
        var matnr: String? = null,

        @field:SerializedName("NAME")
        var name: String? = null,

        @field:SerializedName("Z_RETURN")
        val zReturn: String? = null,

        @field:SerializedName("ZTERM")
        var zterm: String? = "",

        @field:SerializedName("QUANTITY")
        var quantity: Float? = 0F,

        @field:SerializedName("SALE_UNIT")
        var saleUnit: String? = null,

        @field:SerializedName("WIDTH")
        var width: Float? = 0F,

        @field:SerializedName("HEIGHT")
        var height: Float? = 0F,

        @field:SerializedName("check")
        var check: String? = null,

        @field:SerializedName("id")
        var id: Int? = null,

        @field:SerializedName("ZDKGH")
        var zdkgh: String? = null,

        @field:SerializedName("value")
        var value: String? = null
) : Parcelable {

    fun trace() {
        Debug.e("--- MATNR: ${matnr}\natnam: \nvalue: ${name}\nquantity: ${quantity}\nsaleunit: ${saleUnit}")
    }

    fun getInfoGroups(zGroups: String): ArrayList<CharacteristicsItem> {
        var data = ArrayList<CharacteristicsItem>()
        return characteristics?.filter { return@filter zGroups.equals(it.zGroup) } as ArrayList<CharacteristicsItem>
    }
}