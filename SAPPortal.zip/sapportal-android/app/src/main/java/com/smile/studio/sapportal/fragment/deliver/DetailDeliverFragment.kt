package com.smile.studio.sapportal.fragment.deliver

import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.activity.BaseActivity
import com.smile.studio.sapportal.adapter.ProductAdapter
import com.smile.studio.sapportal.fragment.BaseFragment
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.face.SAPPortal
import com.smile.studio.sapportal.network.model.*
import com.smile.studio.sapportal.network.request.ReasonRequest
import com.smile.studio.sapportal.network.response.AttributesResponse
import com.smile.studio.sapportal.network.response.BaseResponse
import com.smile.studio.sapportal.network.zip.ZipCharacteristicItem
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.functions.BiFunction
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_detail_deliver.*
import java.util.*
import kotlin.collections.ArrayList

class DetailDeliverFragment : BaseFragment() {

    var division: String? = null
    var adapter: ProductAdapter? = null
    var layoutManager: LinearLayoutManager? = null
    var characteristics = ArrayList<CharacteristicsItem>()
    var bufferItem : ArrayList<Items>? = null
    val map = LinkedHashMap<String, HashMap<String, ArrayList<CharacteristicsItem>>>()
    val item = Items()
    val botoi = Items()
    val thanhray = Items()

    companion object {
        fun newInstance(): DetailDeliverFragment {
            val fragment = DetailDeliverFragment()
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_detail_deliver, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        map.put(CharacteristicsItem.Type.GROUP_1.value, HashMap<String, ArrayList<CharacteristicsItem>>())
        map.put(CharacteristicsItem.Type.GROUP_2.value, HashMap<String, ArrayList<CharacteristicsItem>>())
        map.put(CharacteristicsItem.Type.GROUP_3.value, HashMap<String, ArrayList<CharacteristicsItem>>())
        map.put(CharacteristicsItem.Type.GROUP_4.value, HashMap<String, ArrayList<CharacteristicsItem>>())
        map.put(CharacteristicsItem.Type.GROUP_5.value, HashMap<String, ArrayList<CharacteristicsItem>>())
        map.put(CharacteristicsItem.Type.GROUP_6.value, HashMap<String, ArrayList<CharacteristicsItem>>())
        map.put(CharacteristicsItem.Type.GROUP_7.value, HashMap<String, ArrayList<CharacteristicsItem>>())
        map.put(CharacteristicsItem.Type.GROUP_8.value, HashMap<String, ArrayList<CharacteristicsItem>>())
        map.put(CharacteristicsItem.Type.GROUP_9.value, HashMap<String, ArrayList<CharacteristicsItem>>())
        layoutManager = LinearLayoutManager(requireActivity())
        recyclerView.layoutManager = layoutManager
        adapter = ProductAdapter(activity, ArrayList(), false)
        recyclerView.adapter = adapter
        adapter?.onItemClick = object : OnItemClickListenerRecyclerView {
            override fun onClick(view: View?, position: Int) {
                //TODO Action click detail item dialog
                if (position == 0) {
                    (activity as BaseActivity).showProgressDialog()
                    characteristics.groupBy { it.zGroup }.entries.map {
                        val child = HashMap<String, ArrayList<CharacteristicsItem>>()
                        child.put(CharacteristicsItem.getTitle(it.key!!), it.value as ArrayList<CharacteristicsItem>)
                        map.put(it.key!!, child)
                    }
                    (activity as BaseActivity).shareViewModel?.setData(map)
                    val dialog = DetailDeliverOrderDialogFragment.newInstance()
                    dialog.show((activity as BaseActivity).supportFragmentManager, DetailDeliverOrderDialogFragment::class.java.simpleName)
                    (activity as BaseActivity).dismissProgressDialog()
                } else {
                    getCharacteristicItem(position = position, matnr = adapter?.getItem(position)?.matnr!!)
                }

            }

            override fun onLongClick(view: View?, position: Int) {

            }

        }
        (activity as BaseActivity).shareViewModel?.getData()?.observe(viewLifecycleOwner, Observer<Any?> { data ->
            if (data is Deliver) {
//                val dateCreate = GlobalApp.getInstance().dateFormat2.format(Date(System.currentTimeMillis()))
//                tv_date_start.value = dateCreate
                tv_date_end.value = data.date
                tv_address.value = data.address
                tv_total_pirce.value = "${GlobalApp.getInstance().decimalFormat.format(data.totalPrice)} VNĐ"
                tv_order_discount.value = "${GlobalApp.getInstance().decimalFormat.format(data.discount)} VNĐ"
                val tien_sau_chiet_khau = data.totalPrice!! - data.discount!!
                tv_total_order_discount.value = "${GlobalApp.getInstance().decimalFormat.format(tien_sau_chiet_khau)} VNĐ"
                tv_tax.value = "${GlobalApp.getInstance().decimalFormat.format(data.tax)} VNĐ"
                tv_total_after_pirce.value = "${GlobalApp.getInstance().decimalFormat.format(data.zPrice)} VNĐ"
                tv_amount_to_guarantee.value = "${GlobalApp.getInstance().decimalFormat.format(data.guaranteeAmount)} VNĐ"
                tv_note.text = data.note
                val status = data.status
                val ztc = data.ztc
                tv_status.value = if ((status.equals("P") || status.equals("L")) && ztc.equals("0")) {
                    "Đã lưu"
                } else if (status.equals("P") && ztc.equals("2")) {
                    "Đã phê duyệt TC"
                } else if (status.equals("R")) {
                    "Đã Hủy"
                } else if (status.equals("F")) {
                    "Không thành công"
                } else if (status.equals("C")) {
                    "Vượt hạn mức TD"
                } else if (status.equals("T")) {
                    "Chờ xử lý"
                } else if (status.equals("B")) {
                    "Chờ bảo lãnh"
                } else if (status.equals("S")) {
                    "Đặt thành công"
                } else if (status.equals("A")) {
                    "Đã đuyệt"
                } else {
                    ""
                }
                Debug.e("--- status: " + status)
                data(data)
            }
        })
    }

    private fun getCharacteristicItem(position: Int, matnr: String) {
        (activity as BaseActivity).showProgressDialog()
        val characteristic = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getCharacteristic(matnr)
        val characteristicDefault = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getCharacteristicDefault(matnr)
        val subscribe = Observable.zip(characteristic, characteristicDefault, object : BiFunction<AttributesResponse, BaseResponse<ArrayList<CharacteristicsItem>>, ZipCharacteristicItem> {
            override fun apply(t1: AttributesResponse, t2: BaseResponse<ArrayList<CharacteristicsItem>>): ZipCharacteristicItem {
                return ZipCharacteristicItem(t1, t2)
            }

        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            (activity as BaseActivity).dismissProgressDialog()
            try {
                adapter?.getItem(position)?.characteristics?.clear()
                adapter?.getItem(position)?.characteristics?.addAll(item.characteristics!!)
                adapter?.getItem(position)?.characteristics?.addAll(botoi.characteristics!!)
                adapter?.getItem(position)?.characteristics?.addAll(thanhray.characteristics!!)

                val buffer = bufferItem?.get(position)?.characteristics!!
                adapter?.getItem(position)?.characteristics?.forEachIndexed { index, characteristicsItem ->
                    buffer.forEachIndexed { indexBuffer, characteristicsItemBuffer ->
                        if (!TextUtils.isEmpty(characteristicsItemBuffer.value) && characteristicsItem.atnam.equals(characteristicsItemBuffer.atnam)) {
                            characteristicsItem.value = if(!TextUtils.isEmpty(characteristicsItemBuffer.value)) characteristicsItemBuffer.value else characteristicsItem.value
                            characteristicsItem.ausp1 = if(!TextUtils.isEmpty(characteristicsItemBuffer.ausp1)) characteristicsItemBuffer.ausp1 else characteristicsItem.ausp1
                            Debug.e("--- Thuc hien kiem tra: ${characteristicsItem.atnam} name: ${characteristicsItem.smbez}")
                            characteristicsItem.trace()
                        }
                    }
                }
                val map = LinkedHashMap<String, HashMap<String, ArrayList<CharacteristicsItem>>>()
                adapter?.getItem(position)?.characteristics?.groupBy { it.zGroup }?.entries?.map {
                    val child = HashMap<String, ArrayList<CharacteristicsItem>>()
                    child.put(CharacteristicsItem.getTitle(it.key!!), it.value as ArrayList<CharacteristicsItem>)
                    map.put(it.key!!, child)
                }
                (activity as BaseActivity).shareViewModel?.setData(map)
                val dialog = DetailDeliverOrderDialogFragment.newInstance()
                dialog.show((activity as BaseActivity).supportFragmentManager, DetailDeliverOrderDialogFragment::class.java.simpleName)
            } catch (e: Exception) {
                Debug.e("--- Error: ${e.message}")
            }
        }.subscribe({
            item.characteristics?.clear()
            botoi.characteristics?.clear()
            thanhray.characteristics?.clear()
//            characteristics.clear()
            val dataCharacteristic = it.characteristic_t1?.data
            val dataCharacteristicDefault = it.characteristicDefault_t2?.data
            dataCharacteristic?.forEachIndexed { i, attribute ->
                dataCharacteristicDefault?.forEachIndexed { j, characteristicsItem ->
                    if (attribute.atnam == characteristicsItem.atnam && !TextUtils.isEmpty(characteristicsItem.zGroup) && characteristicsItem.zDefault?.equals("X", true)!!) {
                        if (attribute.value2?.size!! > 0) {
                            when (attribute.atnam) {
                                CharacteristicsItem.Z_WIDTH -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = characteristics.find { return@find it.atnam.equals(CharacteristicsItem.Z_WIDTH) }?.value
                                    Debug.e("--- value Z_WIDTH: ${value}")
                                    val valueDefault = attribute.value2 as ArrayList
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    botoi.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_HEIGHT -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = characteristics.find { return@find it.atnam.equals(CharacteristicsItem.Z_HEIGHT) }?.value
                                    Debug.e("--- value Z_HEIGHT: ${value}")
                                    val valueDefault = attribute.value2 as ArrayList
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    botoi.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_LOAI_CUA, CharacteristicsItem.Z_MODEL_CUA -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = characteristics.find { return@find it.atnam.equals(CharacteristicsItem.Z_MODEL_CUA) || it.atnam.equals(CharacteristicsItem.Z_LOAI_CUA) }?.value
                                    Debug.e("--- value Z_LOAI_CUA: ${value}")
                                    val valueDefault = attribute.value2 as ArrayList
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    botoi.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_SO_LUONG -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = "1"
                                    Debug.e("--- value Z_SO_LUONG: ${value}")
                                    val valueDefault = attribute.value2 as ArrayList
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    botoi.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_KT_THANH -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = characteristics.find { return@find it.atnam.equals(CharacteristicsItem.Z_KT_THANH) }?.value
                                    Debug.e("--- value Z_KT_THANH: ${value}")
                                    val valueDefault = attribute.value2 as ArrayList
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    thanhray.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_SO_THANH -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = characteristics.find { return@find it.atnam.equals(CharacteristicsItem.Z_SO_THANH) }?.value
                                    Debug.e("--- value Z_SO_THANH: ${value}")
                                    val valueDefault = attribute.value2 as ArrayList
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    thanhray.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_KO_DAU_TRUC -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = characteristics.find { return@find it.atnam.equals(CharacteristicsItem.Z_KO_DAU_TRUC) }?.value
                                    Debug.e("--- value Z_KO_DAU_TRUC: ${value}")
                                    val valueDefault = attribute.value2 as ArrayList
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    characteristics.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                else -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = characteristicsItem.value
                                    Debug.e("--- value ${atnam}: ${value}")
                                    val valueDefault = attribute.value2 as ArrayList
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    when (position) {
                                        1 -> {
                                            botoi.characteristics?.add(characteristicsItem)
                                        }
                                        2 -> {
                                            thanhray.characteristics?.add(characteristicsItem)
                                        }
                                    }
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                            }
                        } else {
                            when (attribute.atnam) {
                                CharacteristicsItem.Z_WIDTH -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = characteristics.find { return@find it.atnam.equals(CharacteristicsItem.Z_WIDTH) }?.value
                                    Debug.e("--- value Z_WIDTH: ${value}")
                                    val valueDefault = ArrayList<Value2Item>()
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    botoi.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_HEIGHT -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = characteristics.find { return@find it.atnam.equals(CharacteristicsItem.Z_HEIGHT) }?.value
                                    Debug.e("--- value Z_HEIGHT: ${value}")
                                    val valueDefault = ArrayList<Value2Item>()
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    botoi.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_MODEL_CUA, CharacteristicsItem.Z_LOAI_CUA -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = characteristics.find { return@find it.atnam.equals(CharacteristicsItem.Z_MODEL_CUA) || it.atnam.equals(CharacteristicsItem.Z_LOAI_CUA) }?.value
                                    Debug.e("--- value Z_LOAI_CUA: ${value}")
                                    val valueDefault = ArrayList<Value2Item>()
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    botoi.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_SO_LUONG -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = "1"
                                    Debug.e("--- value Z_SO_LUONG: ${value}")
                                    val valueDefault = ArrayList<Value2Item>()
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    botoi.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_KT_THANH -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = characteristics.find { return@find it.atnam.equals(CharacteristicsItem.Z_KT_THANH) }?.value
                                    Debug.e("--- value Z_KT_THANH: ${value}")
                                    val valueDefault = ArrayList<Value2Item>()
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    thanhray.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_SO_THANH -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = characteristics.find { return@find it.atnam.equals(CharacteristicsItem.Z_SO_THANH) }?.value
                                    Debug.e("--- value Z_SO_THANH: ${value}")
                                    val valueDefault = ArrayList<Value2Item>()
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    thanhray.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_KO_DAU_TRUC -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = characteristics?.find { return@find it.atnam.equals(CharacteristicsItem.Z_KO_DAU_TRUC) }?.value
                                    Debug.e("--- value Z_KO_DAU_TRUC: ${value}")
                                    val valueDefault = attribute.value2 as ArrayList
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    characteristics.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                else -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = characteristicsItem.value
                                    Debug.e("--- value ${atnam}: ${value}")
                                    val valueDefault = ArrayList<Value2Item>()
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    when (position) {
                                        1 -> {
                                            botoi.characteristics?.add(characteristicsItem)
                                        }
                                        2 -> {
                                            thanhray.characteristics?.add(characteristicsItem)
                                        }
                                    }
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                            }
                        }
                    }
                }
            }
        }, {
            Debug.e("--- Error: ${it.message}")
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    private fun data(deliver: Deliver) {
        val creditRequest: ReasonRequest = ReasonRequest(idOrder = deliver.idOrder)
        (activity as BaseActivity).showProgressDialog()
        val requestDeliver = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getDetailOrder(creditRequest)
        val subscribe = requestDeliver.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            (activity as BaseActivity).dismissProgressDialog()
        }.subscribe({
            division = it.data?.division
            try {
                tv_date_start.value = GlobalApp.getInstance().dateFormat4.format(Date(it.data?.today))
            } catch (e: Exception) {
                Debug.e("--- Error: ${e.message}")
            }
            tv_username_reciver.value = it.data?.usernameReciver
            tv_phone.value = it.data?.phoneNumber
            tv_username_customer.value = it.data?.usernameCustomer
            tv_phone_end_user.value = it.data?.phoneEndUser
            tv_address_customer.value = it.data?.addressCustomer
            try {
                tv_date_request_company.value = GlobalApp.getInstance().dateFormat2.format(GlobalApp.getInstance().dateFormat3.parse(it.data?.zntcxd))
            } catch (e: Exception) {
                Debug.e("--- Error: ${e.message} value: ${it.data?.zntcxd}")
            }
            tv_agency.value = it.data?.nameShipTo
            bufferItem = it.data?.items
            characteristics = it.data?.items?.get(0)?.characteristics!!
            if (!TextUtils.isEmpty(it.data.znguoigh)) {
                try {
                    tv_date_gh.value = GlobalApp.getInstance().dateFormat2.format(GlobalApp.getInstance().dateFormat3.parse(it.data.zngaygh))
                } catch (e: Exception) {
                    Debug.e("--- Error: ${e.message} value: ${it.data.zngaygh}")
                }
                tv_user_gh.value = it.data.znguoigh
            }
            getDetailUser(deliver)
            getRouter(it.data.route!!, it.data.vSart!!)
            getDetailItem(deliver)
        }, {
            Debug.e("--- Error: ${it.message}")
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    private fun getDetailItem(deliver: Deliver) {
//        sendData = OrderRequest(GlobalApp.getInstance().profile?.uid!!, detailProperties)
        val itMaras = ArrayList<Items>()
        deliver.items?.forEachIndexed { index, itemsItem ->
            itMaras.add(Items(matnr = itemsItem.matnr))
        }
        val body = ReasonRequest(idUser = deliver.idUser, division = deliver.division, itMaras = itMaras)
        (activity as BaseActivity).showProgressDialog()
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getEsitmateDelive(body)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            (activity as BaseActivity).dismissProgressDialog()
            adapter?.addAll(deliver.items!!)
        }.subscribe({ response ->
            itMaras.forEachIndexed { m, itemsClient ->
                response.data?.forEachIndexed { n, itemsResponse ->
                    itMaras.forEachIndexed { m, itemsClient ->
                        response.data.forEachIndexed { n, itemsResponse ->
                            if (itemsClient.matnr?.equals(itemsResponse.matnr)!!) {
                                try {
                                    when (n) {
                                        0 -> {
                                            deliver.items?.get(0)?.name = response.data.get(m).name
                                            deliver.items?.get(0)?.zPrice = response.data.get(m).zPrice
                                            val dateStart = System.currentTimeMillis()
//                                            tv_date_start.value = GlobalApp.getInstance().dateFormat2.format(Date(dateStart))
                                            val calendar = Calendar.getInstance()
                                            calendar.timeInMillis = dateStart
                                            calendar.add(Calendar.DAY_OF_WEEK, response.data.get(m).zdkgh?.toIntOrNull()!!)
                                            tv_date_estimated.value = GlobalApp.getInstance().dateFormat2.format(calendar.time)
                                            tv_date_end.value = GlobalApp.getInstance().dateFormat2.format(calendar.time)
                                            Debug.e("index: ${m}: | zdkgh:${response.data.get(m).zdkgh} |   name: ${response.data.get(m).name}|   name: ${response.data.get(m).zPrice}")
                                            return@forEachIndexed
                                        }
                                        1 -> {
                                            deliver.items?.get(1)?.zPrice = response.data.get(m).zPrice
                                            Debug.e("index: ${m}: | zdkgh:${response.data.get(m).zdkgh} |   name: ${response.data.get(m).name}|   name: ${response.data.get(m).zPrice}")
                                            return@forEachIndexed
                                        }
                                        2 -> {
                                            deliver.items?.get(2)?.zPrice = response.data.get(m).zPrice
                                            Debug.e("index: ${m}: | zdkgh:${response.data.get(m).zdkgh} |   name: ${response.data.get(m).name}|   name: ${response.data.get(m).zPrice}")
                                            return@forEachIndexed
                                        }
                                    }
                                } catch (e: Exception) {
                                    Debug.e("--- Error: ${e.message}")
                                }
                            }
                        }
                    }
                }
            }
        }, {
            Debug.e("--- Error: ${it.message}")
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    private fun getRouter(idRouter: String, vsart: String) {
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getRoute()
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
        }.subscribe({
            val mDataRoute = it.route?.filter { return@filter idRouter.equals(it.route) }
            if (mDataRoute?.size!! > 0) {
                tv_district.value = mDataRoute.get(0).bezei
            } else {
                Debug.e("--- Khong thay idRouter:${idRouter}")
            }
            val mDataVSart = it.t173t?.filter { return@filter vsart.equals(it.vSart) }
            if (mDataVSart?.size!! > 0) {
                tv_city.value = mDataVSart.get(0).bezei
            } else {
                Debug.e("--- Khong thay vsart: ${vsart}")
            }
        }, {
            Debug.e("--- Error: ${it.message}")
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    private fun getDetailCusomter(kunnr: String) {
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getDetailCustomers(kunnr)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
        }.subscribe({
            //Công nợ hiện tại
            it.data?.zCreditCustomer?.forEachIndexed { index, zCreditCustomer ->
                if (zCreditCustomer.cs?.equals("CS${division}")!!) {
                    zCreditCustomer.trace()
                    tv_zcreditcus.value = "${GlobalApp.getInstance().decimalFormat.format(zCreditCustomer.value)} VNĐ"
                }
            }
            //Hạn mức tín dụng
            it.data?.zCredit?.forEachIndexed { index, zCredit ->
                if (zCredit.cs?.equals("CS${division}")!!) {
                    zCredit.trace()
                    tv_zCredit.value = "${GlobalApp.getInstance().decimalFormat.format(zCredit.value)} VNĐ"
                }
            }
        }, {
            Debug.e("--- Error: ${it.message}")
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    private fun getDetailUser(detailOrder: Deliver) {
        val body = ReasonRequest(idUser = detailOrder.idUser)
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getDetailUser(body)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
        }.subscribe({
            Debug.e("--- kunnr: ${it.user?.kunnr!!}")
            getDetailCusomter(it.user.kunnr!!)
        }, {
            Debug.e("--- Error: ${it.message}")
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

}