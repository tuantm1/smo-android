package com.smile.studio.sapportal.view

import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.smile.studio.libsmilestudio.network.BaseDialogFragment
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.network.model.API
import kotlinx.android.synthetic.main.dialog_fragment_setting_domain.*

class SettingDomainDialogFragment : BaseDialogFragment(), View.OnClickListener {

    companion object {
        fun newInstance(): SettingDomainDialogFragment {
            val fragment = SettingDomainDialogFragment()
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        super.onCreateView(inflater, container, savedInstanceState)
        return inflater.inflate(R.layout.dialog_fragment_setting_domain, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        edt_domain.setText(API.domain)
        edt_server_name.setText(API.server_name)
        btn_confirm.setOnClickListener(this)
        btn_confirm.isSelected = true
    }

    override fun onClick(v: View?) {
        when(v?.id){
            R.id.btn_confirm -> {
                var flag = false
                val domain = edt_domain.text.toString()
                if(TextUtils.isEmpty(domain)){
                    edt_domain.setError("Vui lòng nhập domain")
                    flag = true
                }
                val serverName = edt_server_name.text.toString()
                if(TextUtils.isEmpty(domain)){
                    edt_server_name.setError("Vui lòng nhập Server Name")
                    flag = true
                }
                if(!flag){
                    API.domain = domain
                    API.server_name = serverName
                    API.saveState(requireActivity())
                    API.loadState(requireActivity())
                    Debug.e("--- ${API.domain}\n--- ${API.server_name}")
                    dismiss()
                    Debug.showAlert(requireActivity(), "Đã đổi thông tin server thành công")
                }
            }
        }
    }
}