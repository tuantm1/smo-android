package com.smile.studio.sapportal.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.fragment.DetailCreditFragment
import com.smile.studio.sapportal.network.model.Credit
import kotlinx.android.synthetic.main.activity_change_password.*

class DetailCreditActivity : BaseActivity() {

    companion object{
        fun openActivity(mContext : Context, credit : Credit){
            val intent = Intent(mContext, DetailCreditActivity::class.java)
            intent.putExtra(Credit::class.java.simpleName, credit)
            mContext.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_credit)
        setSupportActionBar(toolbar!!)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_back_gray)
        val credit = intent.getParcelableExtra<Credit>(Credit::class.java.simpleName)!!
        onChangeFragment(DetailCreditFragment.newInstance(credit), "")
    }
}