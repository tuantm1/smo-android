package com.smile.studio.sapportal.network.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug
import kotlinx.android.parcel.Parcelize

@Parcelize
data class SampleOrder(

        @field:SerializedName("ID_TEMPLATE")
        val idTemplate: String? = null,

        @field:SerializedName("ID_TEMP_CLONE")
        val idTempclone: String? = null,

        @field:SerializedName("ORDER_TYPE")
        val ordertype: String? = null,

        @field:SerializedName("DIVISION")
        val division: String? = null,

        @field:SerializedName("NAME_SHIPTO")
        val nameshipto: String? = null,

        @field:SerializedName("NAME")
        val name: String? = null,

        @field:SerializedName("Z_RETURN")
        val zReturn: String? = null,

        @field:SerializedName("NOTE")
        val note: String? = null,

        @field:SerializedName("ID_ITEM")
        val idItem: String? = null,

        @field:SerializedName("DIVISION_NAME")
        val divisionName: String? = null,

        @field:SerializedName("ID_USER")
        val iduser: String? = null,

        @field:SerializedName("ZTERM")
        val zterm: String? = null,

        @field:SerializedName("DC")
        val dc: String? = null,

        @field:SerializedName("ZTYPE")
        var ztype: String? = null
) : Parcelable {
    fun trace() {
        Debug.e("idTemp: ${idTemplate}")
    }
}
