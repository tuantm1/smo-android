package com.smile.studio.sapportal.view

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.libsmilestudio.utils.IAction
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.activity.BaseActivity
import com.smile.studio.sapportal.adapter.ProductAdapter
import com.smile.studio.sapportal.adapter.ProductFilterAdapter
import com.smile.studio.sapportal.adapter.ProductMoreAdapter
import com.smile.studio.sapportal.network.model.Items
import kotlinx.android.synthetic.main.dialog_fragment_add_item.*

class AddItemDialogFragment : BottomSheetDialogFragment() {

    var adapter: ProductMoreAdapter ? = null
    var layoutManager: LinearLayoutManager? = null
    var callBack: IAction.Factory.ActionObject? = null

    companion object {
        fun newInstance(): AddItemDialogFragment {
            val fragment = AddItemDialogFragment()
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.dialog_fragment_add_item, container)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = ProductMoreAdapter(activity, ArrayList(), false)
        recyclerView.adapter = adapter
        adapter?.onItemClick = object : OnItemClickListenerRecyclerView {
            override fun onClick(view: View?, position: Int) {
                val item = adapter?.getItem(position)
                item?.trace()
                callBack?.callback(item)
            }

            override fun onLongClick(view: View?, position: Int) {

            }

        }
        layoutManager = LinearLayoutManager(activity)
        recyclerView.layoutManager = layoutManager
        recyclerView.setHasFixedSize(true)
        (activity as BaseActivity).shareViewModel?.getData()?.observe(viewLifecycleOwner, Observer<Any?> { data ->
            adapter?.addAll(data as ArrayList<Items>)
        })
        edt_search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                adapter?.filter?.filter(edt_search.text.toString().trim())
            }

            override fun afterTextChanged(s: Editable?) {

            }

        })
    }
}