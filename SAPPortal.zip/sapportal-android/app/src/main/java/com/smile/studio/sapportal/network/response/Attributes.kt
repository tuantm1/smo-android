package com.smile.studio.sapportal.network.response

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.network.model.Value2Item
import kotlinx.android.parcel.Parcelize

@Parcelize
class Attributes(

        @field:SerializedName("SMBEZ")
        var smbez: String? = null,

        @field:SerializedName("VALUE1")
        val value1: Value1? = null,

        @field:SerializedName("VALUE2")
        val value2: List<Value2Item>? = null,

        @field:SerializedName("AUSP1")
        val ausp1: String? = null,

        @field:SerializedName("ATNAM")
        var atnam: String? = null,

        @field:SerializedName("ZGROUP")
        var zGroup: String? = "",

        @field:SerializedName("ZSORT")
        var zSort: String? = null,

        @field:SerializedName("ZTYPE")
        var zType: String? = "",

        @field:SerializedName("VALUE")
        var value: String? = "",

        @field:SerializedName("MATNR")
        var matnr: String? = ""

) : Parcelable {
    fun trace() {
        Debug.e("matnr: $matnr\natnam: ${atnam}\nsmbez: ${smbez}\nvalue: ${value}\nzType: ${zType}\nzGroup: ${zGroup}\nzSort: ${zSort}")
    }
}

@Parcelize
data class Value1(

        @field:SerializedName("AUTHORITY_GROUP")
        val authorityGroup: String? = null,

        @field:SerializedName("ENTRY_REQ")
        val entryReq: String? = null,

        @field:SerializedName("UNFORMATED")
        val unformated: String? = null,

        @field:SerializedName("DISPL_EXP")
        val displExp: String? = null,

        @field:SerializedName("CHARNUMBER")
        val charnumber: String? = null,

        @field:SerializedName("GROUP")
        val group: String? = null,

        @field:SerializedName("STATUS")
        val status: String? = null,

        @field:SerializedName("NEG_VALS")
        val negValues: String? = null,

        @field:SerializedName("TEMPLATE")
        val template: String? = null,

        @field:SerializedName("NO_DISPLAY")
        val noDisplay: String? = null,

        @field:SerializedName("INTERV")
        val interv: String? = null,

        @field:SerializedName("DECPLACES")
        val decplaces: String? = null,

        @field:SerializedName("NO_ENTRY")
        val noEntry: String? = null,

        @field:SerializedName("UNIT")
        val unit: String? = null,

        @field:SerializedName("DOC_VERS")
        val docVerions: String? = null,

        @field:SerializedName("DOCUMENT")
        val document: String? = null,

        @field:SerializedName("DOC_TYPE")
        val docType: String? = null,

        @field:SerializedName("ADDIT_VALS")
        val additValues: String? = null,

        @field:SerializedName("DOC_PART")
        val docPart: String? = null,

        @field:SerializedName("DISPL_VALS")
        val displValues: String? = null,

        @field:SerializedName("UDEF_CLASS")
        val udefClass: String? = null,

        @field:SerializedName("VALASSIGNM")
        val valassignm: String? = null,

        @field:SerializedName("DATATYPE")
        val dataType: String? = null,

        @field:SerializedName("PROP_TEMPL")
        val propTempl: String? = null,

        @field:SerializedName("EXPONENT")
        val exponent: String? = null,

        @field:SerializedName("CASESENS")
        val casesens: String? = null
) : Parcelable
