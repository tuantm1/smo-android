package com.smile.studio.sapportal.model

import com.google.gson.GsonBuilder
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.BuildConfig
import com.smile.studio.sapportal.network.model.User
import com.smile.studio.sapportal.network.response.Menu
import okhttp3.Interceptor
import okhttp3.JavaNetCookieJar
import okhttp3.OkHttpClient
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import java.net.CookieManager
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.concurrent.TimeUnit

class GlobalApp {

    private var client: OkHttpClient? = null
    private var logging = HttpLoggingInterceptor(object : HttpLoggingInterceptor.Logger {
        override fun log(message: String) {
            Debug.e("\n" + message)
        }

    })
    var gson = GsonBuilder().setPrettyPrinting().setLenient().create()
    val decimalFormat = DecimalFormat("###,###,###")
    val dateFormat1 = SimpleDateFormat("yyyyMMdd")
    val dateFormat2 = SimpleDateFormat("dd/MM/yyyy")
    val dateFormat3 = SimpleDateFormat("yyyy-MM-dd")
    val dateFormat4 = SimpleDateFormat("dd/MM/yyyy HH:mm")
    var mDataMenu = ArrayList<Menu>()
    var profile: User? = null
    var colors = ArrayList<String>()
    var zType: String? = ""

    companion object {

        private var instance: GlobalApp? = null

        fun getInstance(): GlobalApp {
            if (instance == null) {
                synchronized(GlobalApp::class.java) {
                    instance = GlobalApp()
                }
            }
            return instance!!
        }
    }

    init {
        val value = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BODY else HttpLoggingInterceptor.Level.NONE
        logging.level = value
        val interceptor = object : Interceptor {
            override fun intercept(chain: Interceptor.Chain): Response {
                val original = chain.request()
                val request = original.newBuilder()
                request.method(original.method, original.body)
                return chain.proceed(request.build())
            }

        }
        client = OkHttpClient().newBuilder()
                .addInterceptor(interceptor).addNetworkInterceptor(logging)
                .cookieJar(JavaNetCookieJar(CookieManager()))
                .connectTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build()
    }

    fun baseURL(url: String): Retrofit {
        return Retrofit.Builder()
                .baseUrl(url)
                .client(client)
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build()
    }
}