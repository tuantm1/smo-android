package com.smile.studio.sapportal.activity

import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.adapter.GuaranteeAdapter
import com.smile.studio.sapportal.network.model.TypeUser
import com.smile.studio.sapportal.network.response.DetailProfileResponse
import kotlinx.android.synthetic.main.activity_change_password.toolbar
import kotlinx.android.synthetic.main.activity_detail_user.*

class DetailUserActivity : BaseActivity() {

    var detailUser: DetailProfileResponse? = null
    var adapter: GuaranteeAdapter? = null
    var layoutManager: LinearLayoutManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_user)
        setSupportActionBar(toolbar!!)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_back_gray)
        savedInstanceState?.let {
            detailUser = it.getParcelable(DetailProfileResponse::class.java.simpleName)
        } ?: run{
            detailUser = intent.getParcelableExtra(DetailProfileResponse::class.java.simpleName)
        }
        tv_id.text = detailUser?.user?.uid
        tv_accountname.text = detailUser?.user?.username
        tv_username.text = detailUser?.user?.description
        tv_type.text = detailUser?.user?.getType()
        tv_account_management.text = if (!detailUser?.userK?.isEmpty()!!) detailUser?.userK?.get(0)?.username else ""
        tv_account_guarantee.text = if (!detailUser?.userU?.isEmpty()!!) detailUser?.userU?.get(0)?.username else ""
        layoutManager = LinearLayoutManager(this)
        recyclerView.layoutManager = layoutManager
        adapter = GuaranteeAdapter(this, detailUser?.userU)
        recyclerView.adapter = adapter
        recyclerView.setHasFixedSize(true)
        recyclerView.isNestedScrollingEnabled = false
        if(detailUser?.user?.mType.equals(TypeUser.S.name, true)){
            groups_guarantee.visibility = View.GONE
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putParcelable(DetailDeliverHistoryActivity::class.java.simpleName, detailUser)
    }
}