package com.smile.studio.sapportal.network.request

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.network.model.CharacteristicsItem
import com.smile.studio.sapportal.network.model.Items
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ReasonRequest(

        @field:SerializedName("ID_USER")
        val idUser: String? = null,

        @field:SerializedName("ID_ORDER")
        val idOrder: String? = null,

        @field:SerializedName("ID_CREDIT")
        val idCredit: String? = null,

        @field:SerializedName("REJECT_REASON")
        var rejectReason: String? = null,

        @field:SerializedName("IT_MARAS")
        var itMaras: ArrayList<Items>? = null,

        @field:SerializedName("MATNR")
        var matnr: String? = null,

        @field:SerializedName("division")
        var division: String? = null,

        @field:SerializedName("GT_CHARACTER")
        var characteristics: ArrayList<CharacteristicsItem>? = null,

        @field:SerializedName("CHECK_CREDIT")
        var checkCredit: String? = null,

        @field:SerializedName("ztype")
        val ztype: String? = null

) : Parcelable {
    fun trace() {
        Debug.e("--- matnr: ${matnr} \nidUser: ${idUser}\nidOrder: ${idOrder}\nrejectReason: ${rejectReason}")
        characteristics?.forEachIndexed { index, characteristicsItem ->
            characteristicsItem.trace()
        }
    }
}
