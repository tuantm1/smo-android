package com.smile.studio.sapportal.network.response

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.smile.studio.sapportal.network.model.Return
import com.smile.studio.sapportal.network.model.User
import kotlinx.android.parcel.Parcelize

@Parcelize
class DetailProfileResponse(

        @field:SerializedName("RETURN")
        val mReturn: Return? = null,

        @field:SerializedName("USER")
        val user: User? = null,

        @field:SerializedName("USERS_K")
        val userK: ArrayList<User>? = null,

        @field:SerializedName("USERS_U")
        val userU: ArrayList<User>? = null
) : Parcelable {
    fun trace() {
        user?.trace()
    }
}