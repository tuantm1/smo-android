package com.smile.studio.sapportal.network.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug
import kotlinx.android.parcel.Parcelize
import java.math.BigDecimal

@Parcelize
class DetailCustomer(

        @field:SerializedName("KUNNR")
        val uid: String? = null,

        @field:SerializedName("ROUTE")
        val route: String? = null,

        @field:SerializedName("SDT")
        val phone: String? = null,

        @field:SerializedName("VSART")
        val vSart: String? = null,

        @field:SerializedName("EMAIL")
        val email: String? = null,

        @field:SerializedName("TEL_NUMBER")
        val telphone: String? = null,

        @field:SerializedName("VKORG")
        val vkorg: String? = null,

        @field:SerializedName("SPART")
        val spart: String? = null,

        @field:SerializedName("FAX_NUMBER")
        val faxNumber: String? = null,

        @field:SerializedName("CUSTOMER_NAME")
        val username: String? = null,

        @field:SerializedName("ZCREDIT_CUS")
        val zCreditCustomer: ArrayList<ZCredit>? = null,

        @field:SerializedName("CITY")
        val city: String? = null,

        @field:SerializedName("VAT_NUMBER")
        val vatnumber: String? = null,

        @field:SerializedName("MOB_NUMBER")
        val mobilenumber: String? = null,

        @field:SerializedName("ADDRESS")
        val address: String? = null,

        @field:SerializedName("KTOKD")
        val ktokd: String? = null,

        @field:SerializedName("VTWEG")
        val vtweg: String? = null,

        @field:SerializedName("CZREDIT")
        val zCredit: ArrayList<ZCredit>? = null,

        @field:SerializedName("ZTERM")
        val zterm: String? = null
) : Parcelable {
    fun trace() {
        Debug.e("city: ${city}")
    }
}

@Parcelize
class ZCredit(
        @SerializedName("DIVISION")
        val name: String? = null,
        @SerializedName("VALUE", alternate = arrayOf("Z_AMOUNT_L"))
        val value: BigDecimal? = null,
        @SerializedName("VALUE1")
        val value1: String? = null,
        @SerializedName("CS")
        val cs: String? = null
) : Parcelable {

    fun trace() {
        Debug.e("name: ${name}\nvalue: ${value}\nvalue1: ${value1}\ncs: ${cs}")
    }

}