package com.smile.studio.sapportal.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.andexert.library.RippleView
import com.daimajia.swipe.SwipeLayout
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.model.Items
import com.smile.studio.sapportal.view.TextLabel
import java.math.BigDecimal

class ProductAdapter(val mContext: Context?, val mData: ArrayList<Items>, val isRemove: Boolean) : RecyclerView.Adapter<ProductAdapter.ViewHolder>() {

    val haveAttributes by lazy { false }
    var onItemClick: OnItemClickListenerRecyclerView? = null

    fun getItem(position: Int): Items? {
        return mData.get(position)
    }

    fun updatePosition(position: Int, mData: Items?) {
        this.mData.set(position, mData!!)
        notifyDataSetChanged()
    }

    fun removeItem(position: Int) {
        this.mData.removeAt(position)
        notifyDataSetChanged()
    }

    fun add(position: Int, mData: Items) {
        this.mData.add(position, mData)
        notifyDataSetChanged()
    }

    fun add(mData: Items) {
        this.mData.add(mData)
        notifyDataSetChanged()
    }

    fun addAll(mData: ArrayList<Items>) {
        this.mData.addAll(mData)
        notifyDataSetChanged()
    }

    fun clear() {
        this.mData.clear()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(mContext).inflate(R.layout.custom_item_product, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return mData.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.init(mData.get(position))
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val swipeLayout = view.findViewById<SwipeLayout>(R.id.swipeLayout)
        val rippleView = view.findViewById<RippleView>(R.id.rippleView)
        val tv_product_amount = view.findViewById<TextLabel>(R.id.tv_product_amount)
        val tv_product_name = view.findViewById<TextLabel>(R.id.tv_product_name)
        val tv_product_type = view.findViewById<TextLabel>(R.id.tv_product_type)
        val tv_money = view.findViewById<TextLabel>(R.id.tv_money)
        val btn_remove = view.findViewById<TextView>(R.id.btn_remove)

        fun init(item: Items) {
            tv_product_name.value = item.name
            tv_product_amount.value = "${item.quantity?.toString()}"
            tv_product_type.value = item.getUnit()
            try {
                if (item.zPrice?.compareTo(BigDecimal("0")) == 0) {
                    tv_money.value = "${GlobalApp.getInstance().decimalFormat.format(0)} VNĐ"
                } else {
                    tv_money.value = "${GlobalApp.getInstance().decimalFormat.format(item.zPrice)} VNĐ"
                }
            } catch (e: Exception) {
                Debug.e("--- Error: ${e.message} value: ${item.zPrice}")
            }
            rippleView.setOnRippleCompleteListener { view ->
                item.trace()
                onItemClick?.onClick(view, adapterPosition)
            }
            if (isRemove) {
                if (adapterPosition == 0 && haveAttributes) {
                    swipeLayout.isLeftSwipeEnabled = false
                    swipeLayout.isRightSwipeEnabled = false
                } else {
                    swipeLayout.isLeftSwipeEnabled = true
                    swipeLayout.isRightSwipeEnabled = true
                }
            } else {
                swipeLayout.isLeftSwipeEnabled = false
                swipeLayout.isRightSwipeEnabled = false
            }
            btn_remove.setOnClickListener { view ->
                onItemClick?.onClick(view, adapterPosition)
            }
        }
    }

}