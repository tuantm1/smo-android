package com.smile.studio.sapportal.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.activity.CreateOrderActivity
import com.smile.studio.sapportal.activity.SwitchMenuActivity
import com.smile.studio.sapportal.adapter.MenuAdapter
import com.smile.studio.sapportal.network.model.TypeAction
import com.smile.studio.sapportal.network.response.Menu
import kotlinx.android.synthetic.main.fragment_menu.*

class ChildMenuHomeFragment : BaseFragment() {

    var adapter: MenuAdapter? = null
    var layoutManager: GridLayoutManager? = null

    companion object {
        fun newInstance(mData: ArrayList<Menu>?): ChildMenuHomeFragment {
            val bundle = Bundle()
            bundle.putParcelableArrayList(Menu::class.java.simpleName, mData)
            val fragment = ChildMenuHomeFragment()
            fragment.arguments = bundle
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_child_menu, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        numberColumns = 2
        layoutManager = GridLayoutManager(activity, numberColumns)
        recyclerView.layoutManager = layoutManager
        val mData: ArrayList<Menu>? = arguments?.let {
            it.getParcelableArrayList(Menu::class.java.simpleName)
        }
        adapter = MenuAdapter(activity, numberColumns, mData)
        recyclerView.adapter = adapter
        adapter?.onItemClick = object : OnItemClickListenerRecyclerView {
            override fun onClick(view: View?, position: Int) {
                val item = adapter?.mData?.get(position)
                item?.trace()
                if (!item?.action?.isEmpty()!!) {
                    when (item.action.get(0).functionmodule) {
                        TypeAction.GET_TEMP.value, TypeAction.CREATE_ORDER_RETURN.value -> {
                            Debug.showAlert(activity, "Tính năng đang được cập nhật")
                        }
                        TypeAction.CREATE_ORDER.value -> {
                            val intent = Intent(activity, CreateOrderActivity::class.java)
                            startActivity(intent)
                        }
                        else -> {
                            item.trace()
                            val intent = Intent(activity, SwitchMenuActivity::class.java)
                            intent.putExtra(Menu::class.java.simpleName, item)
                            startActivity(intent)
                        }
                    }
                } else {
                    Debug.e("--- single action")
                    Debug.showAlert(activity, "Tính năng đang được cập nhật")
                }
            }

            override fun onLongClick(view: View?, position: Int) {

            }

        }
        recyclerView.setHasFixedSize(true)
    }

}