package com.smile.studio.sapportal.network.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.network.response.Attributes
import kotlinx.android.parcel.Parcelize

@Parcelize
class DetailProperties(

        @field:SerializedName("ID_TEMPLATE")
        val idTemplate: String? = null,

        @field:SerializedName("ID_TEMP_CLONE")
        val idTempClone: String? = null,

        @field:SerializedName("ORDER_TYPE")
        val orderType: String? = null,

        @field:SerializedName("ITEMS")
        var items: ArrayList<ItemsItem>? = null,

        @field:SerializedName("DIVISION")
        val division: String? = null,

        @field:SerializedName("NAME_SHIPTO")
        var nameShipTo: String? = null,

        @field:SerializedName("TEN_NNH")
        var usernameReciver: String? = null,

        @field:SerializedName("TEN_KHC")
        var usernameCustomer: String? = null,

        @field:SerializedName("SDT_KHC")
        var phoneEndUser: String? = null,

        @field:SerializedName("DC_KHC")
        var addressCustomer: String? = null,

        @field:SerializedName("NAME")
        val name: String? = null,

        @field:SerializedName("Z_RETURN")
        var zReturn: String? = null,

        @field:SerializedName("NOTE")
        val note: String? = null,

        @field:SerializedName("ID_ITEM")
        val idItem: String? = null,

        @field:SerializedName("DIVISION_NAME")
        val divisionName: String? = null,

        @field:SerializedName("ID_USER")
        val idUser: String? = null,

        @field:SerializedName("ZTERM")
        val zTerm: String? = null,

        @field:SerializedName("DC")
        val dc: String? = null,

        @field:SerializedName("STATUS")
        var status: String? = null,

        @field:SerializedName("TODAY")
        var zDateCreate: String? = null,

        @field:SerializedName("Z_DATE")
        var zDate: String? = null,

        @field:SerializedName("ZPRICE")
        var zPrice: String? = null,

        @field:SerializedName("TOTAL_PRICE")
        var totalPrice: String? = null,

        @field:SerializedName("CK")
        var ck: String? = null,

        @field:SerializedName("TAX")
        var tax: String? = null,

        @field:SerializedName("TOTAL_INQUIRY")
        var totalInquiry: String? = null,

        @field:SerializedName("ADDRESS")
        var address: String? = null,

        @field:SerializedName("VSART")
        var vsart: String? = null,

        @field:SerializedName("ROUTE")
        var route: String? = null,

        @field:SerializedName("ZTC")
        var ztc: Int? = null,

        @field:SerializedName("VKORG")
        var origin: String? = null,

        @field:SerializedName("attributes")
        var attributes: LinkedHashMap<Int, Attributes>? = null
) : Parcelable {
    fun trace() {
        Debug.e("--- zDate:${zDate}\nzPrice:${zPrice}\ntotalPrice: ${totalPrice}\nck: ${ck}\ntax:${tax}" +
                "\ntotalInquiry: ${totalInquiry}\naddress:${address}\nvsart: ${vsart}\nroute:${route}" +
                "\nstatus:${status}\nztc: ${ztc}")
        attributes?.get(0)?.trace()
    }
}
