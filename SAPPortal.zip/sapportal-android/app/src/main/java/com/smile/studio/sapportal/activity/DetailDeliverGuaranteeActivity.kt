package com.smile.studio.sapportal.activity

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.fragment.app.Fragment
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.fragment.deliver.DetailDeliverFragment
import com.smile.studio.sapportal.fragment.guarantee.CreateDeliverGuaranteerFragment
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.face.SAPPortal
import com.smile.studio.sapportal.network.model.API
import com.smile.studio.sapportal.network.model.Deliver
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_detail_deliver.*

class DetailDeliverGuaranteeActivity : BaseActivity(), View.OnClickListener {

    var mapFragments: LinkedHashMap<String, Fragment>? = LinkedHashMap<String, Fragment>()
    var mListDeliver: ArrayList<Deliver>? = null
    var page = 0
    var creator : CreateDeliverGuaranteerFragment? = null

    companion object {
        val IS_CREATED = "isCreate"

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_deliver)
        setSupportActionBar(toolbar!!)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_back_gray)
        val deliver: Deliver = intent.getParcelableExtra(Deliver::class.java.simpleName)!!
        val isCreate = intent.getBooleanExtra(IS_CREATED, false)
        shareViewModel?.setData(deliver)
        if (isCreate) {
            tv_title_toolbar.text = "Tạo Bảo lãnh đơn hàng"
            btn_save.visibility = View.VISIBLE
            btn_save.setOnClickListener(this)
            creator = CreateDeliverGuaranteerFragment.newInstance()
            onChangeFragment(creator!!, "")
        } else {
            tv_title_toolbar.text = "Đơn hàng"
            btn_save.visibility = View.GONE
            onChangeFragment(DetailDeliverFragment.newInstance(), "")
        }
//        val jsonObject: String = intent.getStringExtra(DetailDeliverGuaranteeActivity::class.java.simpleName)
//        mListDeliver = GlobalApp.getInstance().gson.fromJson(jsonObject, Array<Deliver>::class.java).toList() as ArrayList<Deliver>
//        tv_page_of_groups.text = getString(R.string.title_page_of_groups, page + 1, mListDeliver?.size)
//        mListDeliver?.forEachIndexed { index, deliver ->
//            mapFragments?.put(deliver.idOrder.toString(), DetailDeliverFragment.newInstance(deliver))
//        }
//        val tabFragmentAdapter = TabFragmentAdapter(this@DetailDeliverGuaranteeActivity, supportFragmentManager, mapFragments, true, viewPager)
//        viewPager.adapter = tabFragmentAdapter
//        viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
//            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
//
//            }
//
//            override fun onPageSelected(position: Int) {
//                tv_page_of_groups.text = getString(R.string.title_page_of_groups, position + 1, mListDeliver?.size)
//            }
//
//            override fun onPageScrollStateChanged(state: Int) {
//
//            }
//        })
//        viewPager.setCurrentItem(page, true)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btn_save -> {
                showProgressDialog()
                val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).createCredit(creator?.creditRequest!!)
                val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
                    dismissProgressDialog()
                }.subscribe({
                    Debug.showAlert(this, "Bảo lãnh thành công")
                    setResult(2000)
                    finish()
                }, {
                    Debug.showAlert(this, "Error: ${it.message}")
                })
                compositeDisposable.add(subscribe)
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
            }
        }
        return super.onOptionsItemSelected(item)
    }

}