package com.smile.studio.sapportal.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.network.response.Route

class RouteAdapter(val mContext: Context?, val mData: ArrayList<Route>?) : BaseAdapter() {

    var filterData = mData
    var onItemClick: OnItemClickListenerRecyclerView? = null

    fun addAll(mData: ArrayList<Route>) {
        this.filterData?.addAll(mData)
        notifyDataSetChanged()
    }

    fun clear() {
        this.filterData?.clear()
        notifyDataSetChanged()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var view: View? = convertView
        val holder: ViewHolder
        if (view == null) {
            view = LayoutInflater.from(mContext).inflate(R.layout.simple_spinner_item, parent, false)
            holder = ViewHolder(view)
            view?.tag = holder
        } else {
            holder = view.tag as ViewHolder
        }
        holder.tv_name.text = filterData?.get(position)?.bezei
        holder.tv_name.isSelected = true
        return view!!
    }

    override fun getItem(position: Int): Route {
        return filterData?.get(position)!!
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getCount(): Int {
        return filterData?.size!!
    }

    fun filterCity(district: Route) {
        Debug.e("--- Thực hiện lọc city theo district")
    }

    fun filterDistrict(city: Route) {
        filterData = mData?.filter { return@filter city.vSart.equals(it.vSart) } as ArrayList<Route>
        notifyDataSetChanged()
    }

    inner class ViewHolder(view: View) {
        val tv_name = view.findViewById<TextView>(android.R.id.text1)
    }

}