package com.smile.studio.sapportal.fragment

import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.viewpager.widget.ViewPager
import com.smile.studio.libsmilestudio.fragment.TabFragmentAdapter
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.model.Customer
import com.smile.studio.sapportal.network.model.Item
import com.smile.studio.sapportal.network.model.TypeDeliver
import com.wdullaer.materialdatetimepicker.date.DatePickerDialog
import kotlinx.android.synthetic.main.fragment_history_deliver.*
import org.greenrobot.eventbus.EventBus
import java.util.*
import kotlin.collections.ArrayList

class DeliverHistoryFragment : BaseFragment(), View.OnClickListener {

    val calendar = Calendar.getInstance()
    var layoutManager: LinearLayoutManager? = null
    var items = ArrayList<Item>()
    var date = ""
    var customer: Customer? = null
    var mapFragments = LinkedHashMap<String, Fragment>()
    var adapter: TabFragmentAdapter? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_history_deliver, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        date = if (TextUtils.isEmpty(date)) GlobalApp.getInstance().dateFormat1.format(Date()) else date
        btn_date.setColorFilter(ContextCompat.getColor(requireActivity(), R.color.colorPrimary))
        btn_date.setOnClickListener(this)
        mapFragments.put(getString(R.string.title_detail_tab_delived), ChildDeliverFragment.newInstance(TypeDeliver.NOT_DELIVER.value))
        mapFragments.put(getString(R.string.title_detail_tab_not_delived), ChildDeliverFragment.newInstance(TypeDeliver.DELIVER.value))
        adapter = TabFragmentAdapter(activity, childFragmentManager, mapFragments, false, viewPager)
        viewPager.adapter = adapter
        viewPager.offscreenPageLimit = 1
        viewPager?.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrollStateChanged(state: Int) {

            }

            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {

            }

            override fun onPageSelected(position: Int) {

            }

        })
        tabLayout.setupWithViewPager(viewPager)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btn_date -> {
                calendar.time = GlobalApp.getInstance().dateFormat1.parse(date)
                val datePickerDialog = DatePickerDialog.newInstance(object : DatePickerDialog.OnDateSetListener {
                    override fun onDateSet(view: DatePickerDialog, year: Int, monthOfYear: Int, dayOfMonth: Int) {
                        calendar.set(year, monthOfYear, dayOfMonth)
//                        adapter?.clear()
                        if (!date.equals(GlobalApp.getInstance().dateFormat1.format(calendar.time))) {
                            date = GlobalApp.getInstance().dateFormat1.format(calendar.time)
//                        getData(date)
                            EventBus.getDefault().postSticky(date)
                        }
                    }
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH))
                datePickerDialog.show(activity?.supportFragmentManager!!, DatePickerDialog::class.java.simpleName)
            }
        }
    }

}