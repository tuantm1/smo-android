package com.smile.studio.sapportal.activity

import android.content.Intent
import android.os.Bundle
import com.smile.studio.libsmilestudio.utils.AndroidDeviceInfo
import com.smile.studio.libsmilestudio.utils.AndroidUtils
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.model.API
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_splash.*
import java.util.concurrent.TimeUnit

class SplashActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_splash)
        API.loadState(this)
        Debug.e("--- ${API.server_name}\n--- ${API.domain}\n--- SHA1: ${AndroidUtils.getSHA1(this)}")
        GlobalApp.getInstance().colors.clear()
        GlobalApp.getInstance().colors.addAll(resources.getStringArray(R.array.listColors))
        tv_version_application.text = getString(R.string.title_version_app, getString(R.string.app_name), AndroidDeviceInfo.getAppVersionName(this))
        val disposable = Observable.timer(TIME_DELAY, TimeUnit.MILLISECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe { it ->
                    //TODO
                    val intent = Intent(this@SplashActivity, LoginActivity::class.java)
                    startActivity(intent)
                    finish()
                }
        compositeDisposable.add(disposable)
    }
}