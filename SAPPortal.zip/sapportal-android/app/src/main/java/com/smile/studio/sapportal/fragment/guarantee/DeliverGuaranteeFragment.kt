package com.smile.studio.sapportal.fragment.guarantee

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.activity.BaseActivity
import com.smile.studio.sapportal.activity.DetailDeliverGuaranteeActivity
import com.smile.studio.sapportal.adapter.DeliverGuaranteeAdapter
import com.smile.studio.sapportal.fragment.BaseFragment
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.face.SAPPortal
import com.smile.studio.sapportal.network.model.API
import com.smile.studio.sapportal.network.model.Deliver
import com.smile.studio.sapportal.network.request.ReasonRequest
import com.smile.studio.sapportal.view.ReasonRejectDialogFragment
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_detail_customer_credit.*

class DeliverGuaranteeFragment : BaseFragment(), SwipeRefreshLayout.OnRefreshListener {

    var adapter: DeliverGuaranteeAdapter? = null
    var layoutManager: LinearLayoutManager? = null

    companion object {
        fun newInstance(): DeliverGuaranteeFragment {
            val fragment = DeliverGuaranteeFragment()
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_detail_deliver_guarantee, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        swipeRefreshLayout.setColorSchemeResources(android.R.color.holo_blue_bright, android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_red_light)
        swipeRefreshLayout.setOnRefreshListener(this)
        swipeRefreshLayout.isRefreshing = false
        layoutManager = LinearLayoutManager(activity)
        recyclerView.layoutManager = layoutManager
        adapter = DeliverGuaranteeAdapter(requireActivity(), ArrayList())
        adapter?.onItemClick = object : OnItemClickListenerRecyclerView {

            override fun onClick(view: View?, position: Int) {
                val item = adapter?.mData?.get(position)!!
                when (view?.id) {
                    R.id.btn_approve -> {
                        Debug.e("---  Accept Approve")
                        val intent = Intent(context, DetailDeliverGuaranteeActivity::class.java)
                        intent.putExtra(Deliver::class.java.simpleName, item)
                        intent.putExtra(DetailDeliverGuaranteeActivity.IS_CREATED, true)
                        startActivityForResult(intent, 2000)
                    }
                    R.id.btn_reject -> {
                        if (TextUtils.isEmpty(item.statusbl)) {
                            Debug.e("---  Reject Approve")
                            val reason = ReasonRequest(idUser = item.idUser, idOrder = item.idOrder!!)
                            val dialog = ReasonRejectDialogFragment.newInstance(reason)
                            dialog.iAction = object : ReasonRejectDialogFragment.IActon {
                                override fun callBack() {
                                    adapter?.removeItem(position)
                                }
                            }
                            dialog.show(childFragmentManager, ReasonRejectDialogFragment::class.java.simpleName)
                        } else {
                            Debug.e("---  Approved")
                            val intent = Intent(context, DetailDeliverGuaranteeActivity::class.java)
                            intent.putExtra(Deliver::class.java.simpleName, item)
                            activity?.startActivityForResult(intent, 2000)
                        }
                    }
                    else -> {
                        Debug.e("--- click here")
                        val intent = Intent(context, DetailDeliverGuaranteeActivity::class.java)
                        intent.putExtra(Deliver::class.java.simpleName, item)
                        activity?.startActivity(intent)
                    }
                }
            }

            override fun onLongClick(view: View?, position: Int) {

            }

        }
        recyclerView.adapter = adapter
        recyclerView.setHasFixedSize(true)
        getData()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2000 && resultCode == 2000) {
            Debug.e("--- reload data")
            adapter?.clear()
            getData()
        }
    }

    private fun getData() {
        (activity as BaseActivity).showProgressDialog()
        val body = ReasonRequest(idUser = GlobalApp.getInstance().profile?.uid)
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getListDeliverGuarantee(body)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            swipeRefreshLayout.isRefreshing = false
            (activity as BaseActivity).dismissProgressDialog()
        }.subscribe({
            adapter?.addAll(it?.resource!!)
        }, {
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    override fun onRefresh() {
        if (swipeRefreshLayout.isRefreshing) {
            adapter?.clear()
            page = 0
            getData()
        }
    }

    override fun onPause() {
        super.onPause()
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.isRefreshing = false
            swipeRefreshLayout.destroyDrawingCache()
            swipeRefreshLayout.clearAnimation()
        }
    }

}