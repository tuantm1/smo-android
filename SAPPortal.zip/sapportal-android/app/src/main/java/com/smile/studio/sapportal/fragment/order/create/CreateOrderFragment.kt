package com.smile.studio.sapportal.fragment.order.create

import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.activity.BaseActivity
import com.smile.studio.sapportal.adapter.SaleAdapter
import com.smile.studio.sapportal.adapter.SampleOrderAdapter
import com.smile.studio.sapportal.fragment.BaseFragment
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.face.SAPPortal
import com.smile.studio.sapportal.network.model.API
import com.smile.studio.sapportal.network.model.Sale
import com.smile.studio.sapportal.network.model.SampleOrder
import com.smile.studio.sapportal.network.request.ReasonRequest
import com.smile.studio.sapportal.network.response.BaseResponse
import com.smile.studio.sapportal.network.zip.ZipInfoSale
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.functions.Function4
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_create_order.*

class CreateOrderFragment : BaseFragment(), View.OnClickListener {

    var saleOrginAdapter: SaleAdapter? = null
    var saleChannelAdapter: SaleAdapter? = null
    var industryInformationAdapter: SaleAdapter? = null
    var sampleOrderAdapter: SampleOrderAdapter? = null
    var listSampleOrder: ArrayList<SampleOrder>? = null
    var sampleExtraAdapter: SampleOrderAdapter? = null
    var sampleOrder: SampleOrder? = null
    var orderType = ""

    companion object {
        var VKORG: String? = null
        fun newInstance(): CreateOrderFragment {
            val fragment = CreateOrderFragment()
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_create_order, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        btn_create.isSelected = true
        btn_create.setOnClickListener(this)
        saleOrginAdapter = SaleAdapter(activity, ArrayList())
        spinnerSalesUnit.adapter = saleOrginAdapter
        spinnerSalesUnit.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val sale = spinnerSalesUnit.adapter?.getItem(position) as Sale
                VKORG = sale.vkorg
                Debug.e("--- sale org: ${VKORG}")
                orderType = when (VKORG) {
                    "1000" -> {
                        "ZI01"
                    }
                    "3000" -> {
                        "(ZI11)|(ZI09)"
                    }
                    else -> {
                        ""
                    }
                }
                sampleOrderAdapter?.filter?.filter(orderType)
                Debug.showAlert(activity, sale.vtext)
                sale.trace()
            }

        }
        saleChannelAdapter = SaleAdapter(activity, ArrayList())
        spinnerSalesChannel.adapter = saleChannelAdapter
        spinnerSalesChannel.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val sale = spinnerSalesChannel.adapter?.getItem(position) as Sale
                Debug.showAlert(activity, sale.vtext)
            }

        }
        industryInformationAdapter = SaleAdapter(activity, ArrayList())
        spinnerIndustryInformation.adapter = industryInformationAdapter
        spinnerIndustryInformation.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val sale = spinnerIndustryInformation.adapter?.getItem(position) as Sale
                layout_extra.visibility = if (sale.vtext.equals("NH Cửa cuốn", true)) View.VISIBLE else View.GONE
                Debug.showAlert(activity, sale.vtext)
                sampleOrderAdapter?.clear()
                val listData = listSampleOrder?.filter {
                    return@filter it.division.equals(sale.spart)
                }
                sampleOrderAdapter?.addAll(listData as ArrayList<SampleOrder>)
                sampleOrderAdapter?.filter?.filter(orderType)
                Debug.e("--- size: ${sampleOrderAdapter?.count}")
            }

        }
        sampleOrderAdapter = SampleOrderAdapter(activity, ArrayList())
        spinnerSampleOrders.adapter = sampleOrderAdapter
        spinnerSampleOrders.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                sampleOrder = spinnerSampleOrders.adapter?.getItem(position) as SampleOrder
            }

        }
        val mData = ArrayList<SampleOrder>()
        mData.add(SampleOrder(ztype = "", name = ""))
        mData.add(SampleOrder(ztype = "PKADC", name = "Phụ kiện AD"))
        mData.add(SampleOrder(ztype = "PKDTC", name = "Phụ kiện DT"))
        mData.add(SampleOrder(ztype = "PKNL", name = "Phụ kiện nan lẻ & thanh đáy"))
        mData.add(SampleOrder(ztype = "CCBH", name = "Công cụ bán hàng"))
        sampleExtraAdapter = SampleOrderAdapter(activity, mData)
        spinnerExtraPhuKien.adapter = sampleExtraAdapter
        spinnerExtraPhuKien.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val item = spinnerExtraPhuKien.adapter?.getItem(position) as SampleOrder
                Debug.e("--- idItem: ${item.idItem}\n--- name: ${item.name}")
                sampleOrder?.ztype = item.ztype
            }

        }
        getData()
    }

    private fun getData() {
        (activity as BaseActivity).showProgressDialog()
        val kunnr = GlobalApp.getInstance().profile?.kunnr!!
        val body = ReasonRequest(idUser = GlobalApp.getInstance().profile?.uid)
        Debug.e("--- kunnr: ${kunnr}")
        val saleOrginRequest = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getSaleOrgin(kunnr)
        val saleChannelRequest = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getSaleChannel(kunnr)
        val industryInformationRequest = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getIndustryInformation()
        val sampleOrderRequest = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getSampleOrder(body)
        val subscribe = Observable.zip(saleOrginRequest, saleChannelRequest, industryInformationRequest, sampleOrderRequest,
                object : Function4<BaseResponse<ArrayList<Sale>>, BaseResponse<ArrayList<Sale>>, BaseResponse<ArrayList<Sale>>, BaseResponse<ArrayList<SampleOrder>>, ZipInfoSale> {
                    override fun apply(t1: BaseResponse<ArrayList<Sale>>, t2: BaseResponse<ArrayList<Sale>>, t3: BaseResponse<ArrayList<Sale>>, t4: BaseResponse<ArrayList<SampleOrder>>): ZipInfoSale {
                        return ZipInfoSale(t1, t2, t3, t4)
                    }

                }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            (activity as BaseActivity).dismissProgressDialog()
        }.subscribe({
            saleOrginAdapter?.addAll(it.salesUnit?.sales!!)
            saleChannelAdapter?.addAll(it.salesChannel?.salesChannel!!)
            industryInformationAdapter?.addAll(it.industryInformation?.industryInformation!!)
            listSampleOrder = it.sampleOrder?.resource
            VKORG = saleOrginAdapter?.getItem(0)?.vkorg
            spinnerSalesUnit.setSelection(0, true)
        }, {
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btn_create -> {
                if (sampleOrder != null && !TextUtils.isEmpty(sampleOrder?.name)) {
                    if (!TextUtils.isEmpty(sampleOrder?.ztype)) {
                        GlobalApp.getInstance().zType = sampleOrder?.ztype
                    } else {
                        GlobalApp.getInstance().zType = ""
                    }
                    (activity as BaseActivity).shareViewModel?.setData(sampleOrder)
                    (activity as BaseActivity).onChangeFragment(DetailOrderFragment.newInstance(), DetailOrderFragment::class.java.simpleName)
                }
            }
        }
    }
}