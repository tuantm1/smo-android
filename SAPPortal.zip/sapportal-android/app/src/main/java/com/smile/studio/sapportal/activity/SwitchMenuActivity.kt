package com.smile.studio.sapportal.activity

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.MenuItem
import androidx.appcompat.widget.SearchView
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.libsmilestudio.utils.KeyboardUtils
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.fragment.CustomerCreditFragment
import com.smile.studio.sapportal.fragment.CustomerFragment
import com.smile.studio.sapportal.fragment.ListDeliverFragment
import com.smile.studio.sapportal.fragment.ProductFragment
import com.smile.studio.sapportal.fragment.guarantee.DeliverGuaranteeFragment
import com.smile.studio.sapportal.network.model.TypeAction
import com.smile.studio.sapportal.network.response.Menu
import kotlinx.android.synthetic.main.activity_switch_menu.*

class SwitchMenuActivity : BaseActivity(), SearchView.OnQueryTextListener {

    var menu: Menu? = null
    var searchView: SearchView? = null
    var keyword: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_switch_menu)
        setSupportActionBar(toolbar!!)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_back)
        savedInstanceState?.let {
            menu = it.getParcelable(Menu::class.java.simpleName)
        } ?: run {
            menu = intent.getParcelableExtra(Menu::class.java.simpleName)
        }
        tv_title_toolbar.text = menu?.description
        when (menu?.action?.get(0)?.functionmodule) {
            TypeAction.GET_MARA.value -> {
                onChangeFragment(ProductFragment.newInstance(), "")
            }
            TypeAction.GET_CUSTOMER.value, TypeAction.GET_DETAIL_CUSTOMER.value -> {
                onChangeFragment(CustomerFragment.newInstance(), "")
            }
            TypeAction.CREDIT.value -> {
                onChangeFragment(CustomerCreditFragment.newInstance(), "")
            }
            TypeAction.GET_CREDIT_ORDER.value -> {
                onChangeFragment(DeliverGuaranteeFragment.newInstance(), "")
            }
            TypeAction.GET_ORDER.value -> {
                onChangeFragment(ListDeliverFragment.newInstance(), "")
            }
            else -> {
                Debug.e("--- Tính năng đang được cập nhật: ${menu?.action?.get(0)?.functionmodule}")
            }
        }
    }

    override fun onCreateOptionsMenu(menu: android.view.Menu?): Boolean {
        menuInflater.inflate(R.menu.swich_menu, menu)
        searchView = menu?.findItem(R.id.navigation_search)?.actionView as SearchView
        searchView?.queryHint = getString(R.string.hint_search)
        searchView?.setOnQueryTextListener(this)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onQueryTextSubmit(query: String?): Boolean {
        val query = query?.trim { it <= ' ' } as String
        if (!TextUtils.isEmpty(keyword) || keyword != query) {
            keyword = query
            KeyboardUtils.toggleKeyboardVisibility(this@SwitchMenuActivity)
            keyword = null.toString()
            searchView?.clearFocus()
            Debug.e("--- action: ${menu?.action?.get(0)?.functionmodule}\nsearch: $keyword")
            when (menu?.action?.get(0)?.functionmodule) {
                TypeAction.GET_MARA.value -> {
                }
                TypeAction.GET_CUSTOMER.value, TypeAction.GET_DETAIL_CUSTOMER.value -> {
                }
                TypeAction.CREDIT.value -> {
                }
                TypeAction.GET_CREDIT_ORDER.value -> {
                }
                TypeAction.GET_ORDER.value -> {

                }
                else -> {
                    Debug.e("--- unknow action: ${menu?.action?.get(0)?.functionmodule}")
                }
            }
        }
        return true
    }

    override fun onQueryTextChange(newText: String): Boolean {
        return false
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onBackPressed() {
        val fragment = supportFragmentManager.findFragmentById(R.id.container)
        if (fragment is ListDeliverFragment) {
            val intent = Intent(this, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_CLEAR_TASK or
                    Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
        } else {
            super.onBackPressed()
        }
    }
}