package com.smile.studio.sapportal.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.smile.studio.sapportal.R;

/**
 * Created by admin on 25/10/2016.
 */

public class TextLabel extends LinearLayout {

    private View view;
    private TextView tv_label, tv_value;

    public TextLabel(Context context) {
        super(context);
        init(context);
    }

    public TextLabel(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public TextLabel(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    private void init(Context context) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view = inflater.inflate(R.layout.text_label, this, true);
        tv_label = view.findViewById(R.id.tv_label);
        tv_value = view.findViewById(R.id.ediText);
    }

    @SuppressWarnings("ResourceAsColor")
    private void init(Context context, AttributeSet attrs) {
        init(context);
        TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.TextLabel, 0, 0);
        String label = ta.getString(R.styleable.TextLabel_textLabel);
        String value = ta.getString(R.styleable.TextLabel_textValue);
        int color1 = ta.getColor(R.styleable.TextLabel_textColor1, getResources().getColor(android.R.color.darker_gray));
        int color2 = ta.getColor(R.styleable.TextLabel_textColor2, getResources().getColor(android.R.color.black));
        ta.recycle();
        tv_label.setText(label);
        tv_label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        tv_label.setTextColor(color1);
        tv_value.setText(value);
        tv_value.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        tv_value.setTextColor(color2);
        tv_value.setSelected(true);
    }

    public void setLabel(String label){
        tv_label.setText(label);
    }

    public String getValue(){
        return tv_value.getText().toString();
    }

    public String getValueMoney(){
        return tv_value.getText().toString().replace(" VNĐ", "").replaceAll(".","");
    }

    public void setValue(String value) {
        tv_value.setText(value);
    }

    public void setValue(int resId) {
        tv_value.setText(resId);
    }

}
