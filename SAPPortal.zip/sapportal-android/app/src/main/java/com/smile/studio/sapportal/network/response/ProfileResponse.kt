package com.smile.studio.sapportal.network.response

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.network.model.Return
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ProfileResponse(

        @field:SerializedName("RETURN")
        val mReturn: Return? = null,

        @field:SerializedName("GS_AUTHEN")
        val authen: Authen? = null
) : Parcelable

@Parcelize
data class Menu(

        @field:SerializedName("ACTION")
        val action: List<Action>? = null,

        @field:SerializedName("DESCRIPTION")
        val description: String? = null,

        @field:SerializedName("ZINDEX")
        val zindex: String? = null,

        @field:SerializedName("ZZSTATUS")
        val zzstatus: String? = null,

        @field:SerializedName("ID_MAPPING")
        val idmapping: String? = null,

        @field:SerializedName("ID_MENU")
        val idmenu: String? = null,

        @field:SerializedName("NAME")
        val name: String? = null,

        @field:SerializedName("color")
        var color: String? = null
) : Parcelable {
    fun trace() {
        Debug.e("description: ${description}")
        action?.forEachIndexed { index, action ->
            action.trace()
        }
    }
}

@Parcelize
data class Authen(

        @field:SerializedName("ID_USER")
        val uid: String? = null,

        @field:SerializedName("USERNAME")
        val username: String? = null,

        @field:SerializedName("ID_PEER")
        val idpeer: String? = null,

        @field:SerializedName("US_TYPE")
        val ustype: String? = null,

        @field:SerializedName("KUNNR")
        val kunnr: String? = null,

        @field:SerializedName("MENU")
        val menu: List<Menu>? = null
) : Parcelable

@Parcelize
data class Action(

        @field:SerializedName("DESCRIPTION")
        val description: String? = null,

        @field:SerializedName("ZZSTATUS")
        val zzstatus: String? = null,

        @field:SerializedName("FUNCTIONMODULE")
        val functionmodule: String? = null,

        @field:SerializedName("ID_ACTION")
        val idaction: String? = null
) : Parcelable {
    fun trace() {
        Debug.e("action: ${functionmodule}")
    }
}
