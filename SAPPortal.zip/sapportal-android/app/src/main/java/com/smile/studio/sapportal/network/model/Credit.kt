package com.smile.studio.sapportal.network.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.model.GlobalApp
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Credit(

        @field:SerializedName("ID_CREDIT")
        val idCredit: String? = null,

        @field:SerializedName("ID_REQUEST")
        val idRequest: String? = null,

        @field:SerializedName("ID_APPROVE")
        val idApprove: String? = null,

        @field:SerializedName("ID_ORDER")
		val idOrder: String? = null,

        @field:SerializedName("ZDATE")
		val date: String? = null,

        @field:SerializedName("ZPRICE")
        val price: Double? = null,

        @field:SerializedName("ZDAY")
        val day: String? = null,

        @field:SerializedName("NOTE")
        val note: String? = null,

        @field:SerializedName("STBL")
        val guaranteeAmount: Double? = null,

        @field:SerializedName("STATUS")
        val status: String? = null
) : Parcelable {
    fun trace() {
        Debug.e("ID_CREDIT: ${idCredit}\nidOrder: ${idOrder}\nidRequest: ${idRequest}\nidApprove: ${idApprove}\ndate: ${date}\naddress: ${note}\nguaranteeAmount: ${GlobalApp.getInstance().decimalFormat.format(guaranteeAmount)} VNĐ\nstatus: ${status}")
    }
}
