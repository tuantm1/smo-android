package com.smile.studio.sapportal.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.AppCompatTextView
import androidx.recyclerview.widget.RecyclerView
import com.andexert.library.RippleView
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.network.model.User

class GuaranteeAdapter(val mContext: Context?, val mData: ArrayList<User>?) : RecyclerView.Adapter<GuaranteeAdapter.ViewHolder>() {

    var onItemClick: OnItemClickListenerRecyclerView? = null

    fun addAll(mData: ArrayList<User>) {
        this.mData?.addAll(mData)
        notifyDataSetChanged()
    }

    fun clear() {
        this.mData?.clear()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(mContext).inflate(R.layout.custom_item_guarantee, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return mData?.size!!
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tv_id.text = mData?.get(position)?.uid
        holder.tv_accountname.text = mData?.get(position)?.username
        holder.tv_type.text = mData?.get(position)?.getType()
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val rippleView = view.findViewById<RippleView>(R.id.rippleView)
        val tv_id = view.findViewById<AppCompatTextView>(R.id.tv_id)
        val tv_accountname = view.findViewById<AppCompatTextView>(R.id.tv_accountname)
        val tv_type = view.findViewById<AppCompatTextView>(R.id.tv_type)
    }
}