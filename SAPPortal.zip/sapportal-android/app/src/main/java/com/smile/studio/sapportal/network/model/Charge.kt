package com.smile.studio.sapportal.network.model

import com.google.gson.annotations.SerializedName

data class Charge(

        @field:SerializedName("VALUE")
        val value: String? = null,

        @field:SerializedName("DESCRIPTION")
        val description: String? = null
)
