package com.smile.studio.sapportal.view

import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.smile.studio.libsmilestudio.network.BaseDialogFragment
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.activity.BaseActivity
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.face.SAPPortal
import com.smile.studio.sapportal.network.model.API
import com.smile.studio.sapportal.network.request.ReasonRequest
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.dialog_fragment_reason_reject.*

class ReasonRejectDialogFragment : BaseDialogFragment(), View.OnClickListener {

    val compositeDisposable = CompositeDisposable()
    lateinit var reason: ReasonRequest
    public var iAction: IActon? = null

    companion object {

        fun newInstance(reason: ReasonRequest): ReasonRejectDialogFragment {
            val bundle = Bundle()
            bundle.putParcelable(ReasonRequest::class.java.simpleName, reason)
            val fragment = ReasonRejectDialogFragment()
            fragment.arguments = bundle
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        super.onCreateView(inflater, container, savedInstanceState)
        return inflater.inflate(R.layout.dialog_fragment_reason_reject, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        arguments?.let {
            reason = it.getParcelable<ReasonRequest>(ReasonRequest::class.java.simpleName) as ReasonRequest
            btn_confirm.setOnClickListener(this)
            btn_confirm.isSelected = true
        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btn_confirm -> {
                var flag = false
                val reasonReject = edt_reason.text.toString()
                if (TextUtils.isEmpty(reasonReject)) {
                    edt_reason.error = "Vui lòng nhập lý do"
                    flag = true
                }
                if (!flag) {
                    reason.rejectReason = reasonReject
                    onActionReject(reason)
                }
            }
        }
    }

    private fun onActionReject(reason: ReasonRequest) {
        (activity as BaseActivity).showProgressDialog()
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).rejectReason(reason)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            (activity as BaseActivity).dismissProgressDialog()
            dismiss()
        }.subscribe({
            iAction?.callBack()
            Debug.showAlert(requireActivity(), "Yêu cầu bảo lãnh đã được từ chối")
        }, {
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    interface IActon {
        fun callBack()
    }
}