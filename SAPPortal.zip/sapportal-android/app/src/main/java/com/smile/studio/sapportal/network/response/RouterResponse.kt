package com.smile.studio.sapportal.network.response

import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug

class RouterResponse(
        @SerializedName("GT_ROUTE")
        val route: ArrayList<Route>? = null,
        @SerializedName("GT_T173T")
        val t173t: ArrayList<Route>? = null
)

class Route(
        @SerializedName("MANDT")
        val mandt: String? = null,
        @SerializedName("SPRAS")
        val spras: String? = null,
        @SerializedName("ROUTE")
        val route: String? = null,
        @SerializedName("BEZEI")
        val bezei: String? = null,
        @SerializedName("VSART")
        val vSart: String? = null
) {
    fun trace() {
        Debug.e("bezei: ${bezei}\nroute: ${route}\nvSart: ${vSart}")
    }
}