package com.smile.studio.sapportal.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.activity.BaseActivity
import com.smile.studio.sapportal.activity.DetailDeliverActivity
import com.smile.studio.sapportal.adapter.DeliverAdapter
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.face.SAPPortal
import com.smile.studio.sapportal.network.model.API
import com.smile.studio.sapportal.network.request.ReasonRequest
import com.smile.studio.sapportal.view.ReasonRejectDialogFragment
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_list_deliver.*

class ListDeliverFragment : BaseFragment(), SwipeRefreshLayout.OnRefreshListener {

    var adapter: DeliverAdapter? = null
    var layoutManager: LinearLayoutManager? = null

    companion object {
        fun newInstance(): ListDeliverFragment {
            val fragment = ListDeliverFragment()
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_list_deliver, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        swipeRefreshLayout.setColorSchemeResources(android.R.color.holo_blue_bright, android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_red_light)
        swipeRefreshLayout.setOnRefreshListener(this)
        swipeRefreshLayout.isRefreshing = false
        layoutManager = LinearLayoutManager(activity)
        recyclerView.layoutManager = layoutManager
        adapter = DeliverAdapter(requireActivity(), ArrayList())
        recyclerView.adapter = adapter
        adapter?.onItemClick = object : OnItemClickListenerRecyclerView {
            override fun onClick(view: View?, position: Int) {
                val item = adapter?.mData?.get(position)!!
                when (view?.id) {
                    R.id.btn_approve -> {
                        (activity as BaseActivity).showProgressDialog()
                        val reasonRequest = ReasonRequest(idUser = GlobalApp.getInstance().profile?.uid, idOrder = item.idOrder!!, checkCredit = "X")
                        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).approveOrder(reasonRequest)
                        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
                            (activity as BaseActivity).dismissProgressDialog()
                        }.subscribe({
                            adapter?.clear()
                            getData()
                        }, {
                            Debug.e("--- Error: ${it.message}")
                            Debug.showAlert(activity, "Error: ${it.message}")
                        })
                        compositeDisposable.add(subscribe)
                    }
                    R.id.btn_reject -> {
                        val reason = ReasonRequest(idUser = GlobalApp.getInstance().profile?.uid, idOrder = item.idOrder!!)
                        val dialog = ReasonRejectDialogFragment.newInstance(reason)
                        dialog.iAction = object : ReasonRejectDialogFragment.IActon {
                            override fun callBack() {
                                adapter?.clear()
                                getData()
                            }

                        }
                        dialog.show(childFragmentManager, ReasonRejectDialogFragment::class.java.simpleName)
                    }
                    else -> {
                        DetailDeliverActivity.openIntentData(activity!!, item)
                    }
                }
            }

            override fun onLongClick(view: View?, position: Int) {

            }

        }
        recyclerView.setHasFixedSize(true)
        getData()
    }

    private fun getData() {
        (activity as BaseActivity).showProgressDialog()
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getListDeliver(GlobalApp.getInstance().profile?.uid!!)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            swipeRefreshLayout.isRefreshing = false
            (activity as BaseActivity).dismissProgressDialog()
        }.subscribe({
            adapter?.addAll(it?.resource!!)
        }, {
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    override fun onRefresh() {
        if (swipeRefreshLayout.isRefreshing) {
            adapter?.clear()
            page = 0
            getData()
        }
    }

    override fun onPause() {
        super.onPause()
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.isRefreshing = false
            swipeRefreshLayout.destroyDrawingCache()
            swipeRefreshLayout.clearAnimation()
        }
    }
}