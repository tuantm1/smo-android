package com.smile.studio.sapportal.network.request

import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug

data class DeliverPDFRequest(
        @SerializedName("so")
        val so: String? = null,
        @SerializedName("from")
        val from: String? = null,
        @SerializedName("to")
        val to: String? = null
) {
    fun trace() {
        Debug.e("so: ${so}\nfrom: ${from}\nto: ${to}")
    }
}

