package com.smile.studio.sapportal.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.widget.AppCompatTextView
import androidx.recyclerview.widget.RecyclerView
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.model.Deliver
import com.smile.studio.sapportal.view.TextLabel

class DeliverAdapter(val mContext: Context?, val mData: ArrayList<Deliver>?) : RecyclerView.Adapter<DeliverAdapter.ViewHolder>() {

    var onItemClick: OnItemClickListenerRecyclerView? = null

    fun addAll(mData: ArrayList<Deliver>) {
        this.mData?.addAll(mData)
        notifyDataSetChanged()
    }

    fun removeItem(position: Int) {
        this.mData?.removeAt(position)
        notifyDataSetChanged()
    }

    fun clear() {
        this.mData?.clear()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(mContext).inflate(R.layout.custom_item_deliver, parent, false)
        return ViewHolder(view, viewType)
    }

    override fun getItemCount(): Int {
        return mData?.size!!
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tv_title.text = mData?.get(position)?.name
        holder.tv_deliver_code.value = mData?.get(position)?.idOrder
        holder.tv_date.value = mData?.get(position)?.date
        holder.tv_created_by_name.value = mData?.get(position)?.createdByName
        holder.tv_approver_by.value = mData?.get(position)?.nameApprove
        val status = mData?.get(position)?.status
        val ztc = mData?.get(position)?.ztc
        holder.btn_status.isSelected = true
        holder.btn_status.text = if ((status.equals("P") || status.equals("L")) && ztc.equals("0")) {
            "Đã lưu"
        } else if (status.equals("P") && ztc.equals("2")) {
            "Đã phê duyệt TC"
        } else if (status.equals("R")) {
            "Đã Hủy"
        } else if (status.equals("F")) {
            "Không thành công"
        } else if (status.equals("C")) {
            "Vượt hạn mức TD"
        } else if (status.equals("T")) {
            "Chờ xử lý"
        } else if (status.equals("B")) {
            "Chờ bảo lãnh"
        } else if (status.equals("S")) {
            "Đặt thành công"
        } else if (status.equals("A")) {
            "Đã đuyệt"
        } else {
            ""
        }
        Debug.e("--- status: ${status}")
        val approve = mData?.get(position)?.idApprove
        val idPeer = GlobalApp.getInstance().profile?.idPeer

        if ((approve.equals(GlobalApp.getInstance().profile?.uid) || approve.equals(idPeer)) && (status.equals("P") || status.equals("F") || status.equals("L"))) {
            holder.btn_approve.text = "Gửi đơn hàng"
            holder.btn_approve.setBackgroundResource(R.drawable.background_button_blue)
            holder.btn_approve.isSelected =  true
            holder.btn_reject.text = "Hủy"
            holder.btn_reject.setBackgroundResource(R.drawable.background_button_red)
            holder.btn_reject.isSelected =  true
            holder.control.visibility = View.VISIBLE
        } else if ((approve.equals(GlobalApp.getInstance().profile?.uid) || approve.equals(idPeer)) && status.equals("C")) {
            holder.btn_approve.text = "Y.C Phê duyệt"
            holder.btn_approve.setBackgroundResource(R.drawable.background_button_blue)
            holder.btn_approve.isSelected =  true
            holder.btn_reject.text = "Hủy"
            holder.btn_reject.setBackgroundResource(R.drawable.background_button_red)
            holder.btn_reject.isSelected =  true
            holder.control.visibility = View.VISIBLE
        } else {
            holder.control.visibility = View.GONE
        }
        holder.tv_note.value = mData?.get(position)?.note
        holder.btn_approve.setOnClickListener { view ->
            onItemClick?.onClick(view, position)
        }
        holder.btn_reject.setOnClickListener { view ->
            onItemClick?.onClick(view, position)
        }
        holder.itemView.setOnClickListener { view ->
            onItemClick?.onClick(view, position)
        }
    }

    inner class ViewHolder(view: View, viewType: Int) : RecyclerView.ViewHolder(view) {

        val tv_title = view.findViewById<AppCompatTextView>(R.id.tv_title)
        val tv_deliver_code = view.findViewById<TextLabel>(R.id.tv_deliver_code)
        val tv_date = view.findViewById<TextLabel>(R.id.tv_date)
        val tv_created_by_name = view.findViewById<TextLabel>(R.id.tv_created_by_name)
        val tv_approver_by = view.findViewById<TextLabel>(R.id.tv_approver_by)
        val btn_status = view.findViewById<TextView>(R.id.btn_status)
        val tv_note = view.findViewById<TextLabel>(R.id.tv_note)
        val control = view.findViewById<LinearLayout>(R.id.control)
        val btn_approve = view.findViewById<TextView>(R.id.btn_approve)
        val btn_reject = view.findViewById<TextView>(R.id.btn_reject)

    }
}