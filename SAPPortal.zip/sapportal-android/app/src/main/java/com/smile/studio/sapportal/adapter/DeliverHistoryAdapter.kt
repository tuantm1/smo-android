package com.smile.studio.sapportal.adapter

import android.content.Context
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.AppCompatTextView
import androidx.recyclerview.widget.RecyclerView
import com.andexert.library.RippleView
import com.github.vipulasri.timelineview.TimelineView
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.network.model.DeliverHistory

class DeliverHistoryAdapter(val mContext: Context?, val mData: ArrayList<DeliverHistory>?) : RecyclerView.Adapter<DeliverHistoryAdapter.ViewHolder>() {

    var onItemClick: OnItemClickListenerRecyclerView? = null

    fun addAll(mData: ArrayList<DeliverHistory>) {
        this.mData?.addAll(mData)
        notifyDataSetChanged()
    }

    fun clear() {
        this.mData?.clear()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(mContext).inflate(R.layout.custom_item_history_deliver, parent, false)
        return ViewHolder(view, viewType)
    }

    override fun getItemCount(): Int {
        return mData?.size!!
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tv_deliver_code.text = mData?.get(position)?.getDeliverID()
        holder.tv_reciver.text = mData?.get(position)?.reciver
        var address: String = ""
        if (!TextUtils.isEmpty(mData?.get(position)?.address1)) {
            address = mData?.get(position)?.address1!!
        } else if (!TextUtils.isEmpty(mData?.get(position)?.address2)) {
            address = mData?.get(position)?.address2!!
        }
        holder.tv_address.text = address
        holder.rippleView.setOnRippleCompleteListener { view ->
            onItemClick?.onClick(view, position)
        }
    }

    inner class ViewHolder(view: View, viewType: Int) : RecyclerView.ViewHolder(view) {

        val timeline = view.findViewById<TimelineView>(R.id.timeline)
        val rippleView = view.findViewById<RippleView>(R.id.rippleView)
        val tv_deliver_code = view.findViewById<AppCompatTextView>(R.id.tv_deliver_code)
        val tv_reciver = view.findViewById<AppCompatTextView>(R.id.tv_reciver)
        val tv_address = view.findViewById<AppCompatTextView>(R.id.tv_address)

        init {
            timeline.initLine(viewType)
        }
    }
}