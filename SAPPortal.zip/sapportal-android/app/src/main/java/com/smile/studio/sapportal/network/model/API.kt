package com.smile.studio.sapportal.network.model

import android.content.Context
import com.smile.studio.libsmilestudio.utils.SharedPreferencesUtils
import com.smile.studio.sapportal.BuildConfig

class API {

    companion object {
        val DOMAIN = "domain"
        val SERVER_NAME = "server_name"
        var domain = BuildConfig.HOME_SERVER
        var server_name = BuildConfig.HOME_PATH
        var HOST = "http://${domain}/${server_name}/"

        fun saveState(mContext: Context) {
            SharedPreferencesUtils.putString(mContext, DOMAIN, domain)
            SharedPreferencesUtils.putString(mContext, SERVER_NAME, server_name)
        }

        fun loadState(mContext: Context) {
            domain = SharedPreferencesUtils.getString(mContext, DOMAIN, domain)
            server_name = SharedPreferencesUtils.getString(mContext, SERVER_NAME, server_name)
            HOST = "http://${domain}/${server_name}/"
        }

    }
}