package com.smile.studio.sapportal.network.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug
import kotlinx.android.parcel.Parcelize

@Parcelize
data class User(
        @field:SerializedName("id_user", alternate = arrayOf("ID_USER"))
        var uid: String? = null,

        @field:SerializedName("username", alternate = arrayOf("USERNAME"))
        var username: String? = null,

        @field:SerializedName("description", alternate = arrayOf("DESCRIPTION"))
        var description: String? = null,

        @field:SerializedName("iv_Mobile")
        var iv_Mobile: String? = "A",

        @field:SerializedName("password", alternate = arrayOf("PASSWORD"))
        var password: String? = null,

        @field:SerializedName("newPassword")
        var newPassword: String? = null,

        @field:SerializedName("reNewPassword")
        var reNewPassword: String? = null,

        @field:SerializedName("US_TYPE")
        var mType: String? = null,

        @field:SerializedName("KUNNR")
        var kunnr: String? = null,

        @field:SerializedName("idpeer")
        var idPeer: String? = null

) : Parcelable {
    fun trace() {
        Debug.e("uid: ${uid}\nname: $username\ndescription: ${description}\nkunnr: ${kunnr}")
    }

    fun getType(): String {
        when (mType) {
            TypeUser.K.name ->
                return TypeUser.K.value
            TypeUser.U.name ->
                return TypeUser.U.value
            TypeUser.S.name ->
                return TypeUser.S.value
            else ->
                return ""
        }
    }

}

enum class TypeUser(val value: String){
    K("Tài Khoản Kinh Doanh"),
    U("Tài Khoản Bảo Lãnh"),
    S("Tài Khoản Thường"),

}