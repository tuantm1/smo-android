package com.smile.studio.sapportal.network.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug
import kotlinx.android.parcel.Parcelize
import java.math.BigDecimal

@Parcelize
data class DeliverHistory(
        @field:SerializedName("SPVC")
        val id: String? = null,

        @field:SerializedName("MAXE")
        val idVehicle: String? = null,

        @field:SerializedName("MACHUYEN")
        val idCode: String? = null,

        @field:SerializedName("DD_XNK")
        val dDXNK: String? = null,

        @field:SerializedName("STT_GH")
        val codeDeliver: String? = null,

        @field:SerializedName("SALE_TYPE")
        val salesType: String? = null,

        @field:SerializedName("NGAY_GH")
        val dateDeliver: String? = null,

        @field:SerializedName("TIME_GH")
        val timeDeliver: String? = null,

        @field:SerializedName("SALE_ORDER")
        val salesOrder: String? = null,

        @field:SerializedName("ROUTER")
        val router: String? = null,

        @field:SerializedName("ROUTE_MOTA")
        val desctionRoute: String? = null,

        @field:SerializedName("TT_GIAOHANG")
        val noDeliver: String? = null,

        @field:SerializedName("CT_XK")
        val idDeliver: String? = null,

        @field:SerializedName("DIACHI_GH1")
        val address1: String? = null,

        @field:SerializedName("DIACHI_GH2")
        val address2: String? = null,

        @field:SerializedName("DIACHI_GH3")
        val reason: String? = null,

        @field:SerializedName("MOTA_XNK")
        val desciption: String? = null,

        @field:SerializedName("NGUOI_NH")
        val reciver: String? = null,

        @field:SerializedName("LOAI_VC")
        val typeShipping: String? = null,

        @field:SerializedName("LAI_XE")
        val typeVehicle: String? = null,

        @field:SerializedName("CHIPHI_VC")
        val transportationCost: BigDecimal? = null,

        @field:SerializedName("CHIPHI_LK")
        val percentCost: BigDecimal? = null,

        @field:SerializedName("LOAITIEN")
        val typeMoney: String? = null
) : Parcelable {
    fun getDeliverID(): String {
        return "#${idDeliver}"
    }

    fun trace() {
        Debug.e("deliverID: ${getDeliverID()}\nReciver: $reciver\naddress1: $address1\naddress2: $address2\naddress3: $reason")
    }
}
