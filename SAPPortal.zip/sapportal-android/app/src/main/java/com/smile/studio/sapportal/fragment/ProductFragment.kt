package com.smile.studio.sapportal.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.smile.studio.libsmilestudio.recyclerviewer.EndlessRecyclerOnScrollListener
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.activity.BaseActivity
import com.smile.studio.sapportal.adapter.ProductAdapter
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.face.SAPPortal
import com.smile.studio.sapportal.network.model.API
import com.smile.studio.sapportal.network.request.ReasonRequest
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_product.*

class ProductFragment : BaseFragment(), SwipeRefreshLayout.OnRefreshListener {

    var adapter: ProductAdapter? = null
    var layoutManager: LinearLayoutManager? = null
    var endlessRecyclerOnScrollListener: EndlessRecyclerOnScrollListener? = null

    companion object {
        fun newInstance(): ProductFragment {
            val fragment = ProductFragment()
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_product, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        swipeRefreshLayout.setColorSchemeResources(android.R.color.holo_blue_bright, android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_red_light)
        swipeRefreshLayout.setOnRefreshListener(this)
        swipeRefreshLayout.isRefreshing = false
        layoutManager = LinearLayoutManager(activity)
        recyclerView.layoutManager = layoutManager
        adapter = ProductAdapter(activity, ArrayList(), false)
        recyclerView.adapter = adapter
        adapter?.onItemClick = object : OnItemClickListenerRecyclerView {
            override fun onClick(view: View?, position: Int) {
                val item = adapter?.getItem(position)
            }

            override fun onLongClick(view: View?, position: Int) {

            }

        }
        recyclerView.setHasFixedSize(true)
        endlessRecyclerOnScrollListener = object : EndlessRecyclerOnScrollListener(layoutManager, page) {
            override fun onLoadMore(currentPage: Int) {
                page = currentPage
                getData()
            }

        }
        getData()
    }

    private fun getData() {
        (activity as BaseActivity).showProgressDialog()
        val body = ReasonRequest(idUser = GlobalApp.getInstance().profile?.uid)
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getListProductProperties(body)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            swipeRefreshLayout.isRefreshing = false
            (activity as BaseActivity).dismissProgressDialog()
        }.subscribe({
            adapter?.addAll(it.data!!)
        }, {
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    override fun onRefresh() {
        if (swipeRefreshLayout.isRefreshing) {
            adapter?.clear()
            page = 0
            getData()
        }
    }

    override fun onPause() {
        super.onPause()
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.isRefreshing = false
            swipeRefreshLayout.destroyDrawingCache()
            swipeRefreshLayout.clearAnimation()
        }
    }
}