package com.smile.studio.sapportal.activity

import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.MenuItem
import android.view.View
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.libsmilestudio.utils.KeyboardUtils
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.face.SAPPortal
import com.smile.studio.sapportal.network.model.API
import com.smile.studio.sapportal.network.model.TypeError
import com.smile.studio.sapportal.network.request.ChangePasswordRequest
import com.smile.studio.sapportal.network.model.User
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_change_password.*

class ChangePasswordActivity : BaseActivity(), View.OnClickListener, TextWatcher {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_password)
        setSupportActionBar(toolbar!!)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_back_gray)
        edt_username.setText(GlobalApp.getInstance().profile?.username)
        edt_confirm_password.addTextChangedListener(this)
        btn_cancel.isSelected = true
        btn_save.setOnClickListener(this)
        btn_cancel.setOnClickListener(this)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btn_save -> {
                KeyboardUtils.forceCloseKeyboard(edt_confirm_password)
                var flag = false
                val password = edt_password.text.toString()
                val old_password = edt_old_password.text.toString()
                val confirm_password = edt_confirm_password.text.toString()
                if (TextUtils.isEmpty(old_password)) {
                    edt_old_password.error = getString(R.string.message_error_input_old_password)
                    flag = true
                } else if (!old_password.equals(GlobalApp.getInstance().profile?.password)) {
                    edt_old_password.error = getString(R.string.message_error_input_equals_old_password)
                    flag = true
                }
                if (TextUtils.isEmpty(password)) {
                    edt_password.error = getString(R.string.message_error_input_password)
                    flag = true
                }
                if (TextUtils.isEmpty(confirm_password)) {
                    edt_confirm_password.error = getString(R.string.message_error_input_confirm_password)
                    flag = true
                } else if (!confirm_password.equals(password)) {
                    edt_confirm_password.error = getString(R.string.message_error_input_equals_confirm_password)
                    flag = true
                }
                if (confirm_password.equals(old_password)) {
                    Debug.showAlert(this@ChangePasswordActivity, getString(R.string.message_error_input_equals_new_password))
                    flag = true
                }
                if (!flag) {
                    onActionChangePassword(old_password, password, confirm_password)
                }

            }
            R.id.btn_cancel -> {
                onBackPressed()
            }
        }
    }

    private fun onActionChangePassword(oldPassword: String, password: String, confirmPassword: String) {
        showProgressDialog()
        val changePassword = ChangePasswordRequest()
        changePassword.user = User()
        changePassword.user?.uid = GlobalApp.getInstance().profile?.uid
        changePassword.user?.username = GlobalApp.getInstance().profile?.username
        changePassword.user?.password = oldPassword
        changePassword.user?.newPassword = password
        changePassword.user?.reNewPassword = confirmPassword
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).changePassword(changePassword)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            dismissProgressDialog()
        }.subscribe({
            if (it.mReturn?.type?.equals(TypeError.ERROR.value, true)!!) {
                Debug.showAlert(this@ChangePasswordActivity, getString(R.string.message_change_password_error))
            } else {
                GlobalApp.getInstance().profile?.password = password
                Debug.showAlert(this@ChangePasswordActivity, getString(R.string.message_change_password_successfull))
                onBackPressed()
            }
        }, {
            Debug.showAlert(this@ChangePasswordActivity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    override fun afterTextChanged(s: Editable?) {
        btn_save.isSelected = !TextUtils.isEmpty(edt_confirm_password.text.toString())
    }

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

    }

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

    }
}