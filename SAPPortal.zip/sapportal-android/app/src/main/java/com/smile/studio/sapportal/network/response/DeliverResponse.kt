package com.smile.studio.sapportal.network.response

import com.google.gson.annotations.SerializedName
import com.smile.studio.sapportal.network.model.DeliverHistory
import com.smile.studio.sapportal.network.model.Item

class DeliverResponse(
        @SerializedName("TB_HEADER")
        val data : ArrayList<DeliverHistory>? = null,

        @SerializedName("TB_ITEM")
        val dataItem : ArrayList<Item>? = null
) {
}