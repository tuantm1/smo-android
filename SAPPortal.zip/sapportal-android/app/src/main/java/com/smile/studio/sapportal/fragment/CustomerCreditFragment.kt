package com.smile.studio.sapportal.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.activity.BaseActivity
import com.smile.studio.sapportal.activity.DetailCreditActivity
import com.smile.studio.sapportal.adapter.CustomerCreditAdapter
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.face.SAPPortal
import com.smile.studio.sapportal.network.model.API
import com.smile.studio.sapportal.network.request.ReasonRequest
import com.smile.studio.sapportal.view.ReasonRejectDialogFragment
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_detail_customer_credit.*

class CustomerCreditFragment : BaseFragment(), SwipeRefreshLayout.OnRefreshListener {

    var adapterCustomer: CustomerCreditAdapter? = null
    var layoutManager: LinearLayoutManager? = null

    companion object {
        fun newInstance(): CustomerCreditFragment {
            val fragment = CustomerCreditFragment()
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_detail_customer_credit, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        swipeRefreshLayout.setColorSchemeResources(android.R.color.holo_blue_bright, android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_red_light)
        swipeRefreshLayout.setOnRefreshListener(this)
        swipeRefreshLayout.isRefreshing = false
        layoutManager = LinearLayoutManager(activity)
        recyclerView.layoutManager = layoutManager
        adapterCustomer = CustomerCreditAdapter(activity, ArrayList())
        recyclerView.adapter = adapterCustomer
        adapterCustomer?.onItemClick = object : OnItemClickListenerRecyclerView {
            override fun onClick(view: View?, position: Int) {
                val item = adapterCustomer?.mData?.get(position)!!
                item.trace()
                when (view?.id) {
                    R.id.btn_guarantee -> {
                        (activity as BaseActivity).showProgressDialog()
                        val reasonRequest = ReasonRequest(item.idRequest!!, item.idOrder!!)
                        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).approveOrder(reasonRequest)
                        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
                            (activity as BaseActivity).dismissProgressDialog()
                        }.subscribe({
                            Debug.showAlert(requireActivity(), "Đồng ý yêu cầu bảo lãnh")
                        }, {
                            Debug.e("--- Error: ${it.message}")
                            Debug.showAlert(activity, "Error: ${it.message}")
                        })
                        compositeDisposable.add(subscribe)
                    }
                    R.id.btn_reject -> {
                        val reason = ReasonRequest(idUser = item.idRequest!!, idOrder = item.idOrder!!, idCredit = item.idCredit)
                        val dialog = ReasonRejectDialogFragment.newInstance(reason)
                        dialog.iAction = object : ReasonRejectDialogFragment.IActon {
                            override fun callBack() {
                                adapterCustomer?.removeItem(position)
                            }

                        }
                        dialog.show(childFragmentManager, ReasonRejectDialogFragment::class.java.simpleName)
                    }
                    else -> {
                        DetailCreditActivity.openActivity(requireActivity(), item)
                    }
                }
            }

            override fun onLongClick(view: View?, position: Int) {

            }

        }
        recyclerView.setHasFixedSize(true)
        getData()
    }

    private fun getData() {
        (activity as BaseActivity).showProgressDialog()
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getListApproveCredit(GlobalApp.getInstance().profile?.uid!!)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            swipeRefreshLayout.isRefreshing = false
            (activity as BaseActivity).dismissProgressDialog()
        }.subscribe({
            adapterCustomer?.addAll(it?.data!!)
            if (adapterCustomer?.itemCount != 0) {
                tv_message.visibility = View.GONE
            } else {
                tv_message.visibility = View.VISIBLE
                tv_message.text = "Chưa có yêu cầu bảo lãnh"
            }
        }, {
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    override fun onRefresh() {
        if (swipeRefreshLayout.isRefreshing) {
            adapterCustomer?.clear()
            page = 0
            getData()
        }
    }

    override fun onPause() {
        super.onPause()
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.isRefreshing = false
            swipeRefreshLayout.destroyDrawingCache()
            swipeRefreshLayout.clearAnimation()
        }
    }

}