package com.smile.studio.sapportal.network.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class DetailDivision(

	@field:SerializedName("GT_DIVISION")
	val divisions: ArrayList<ItemDivision>? = null
) : Parcelable

@Parcelize
data class ItemDivision(

	@field:SerializedName("SPRAS")
	val spras: String? = null,

	@field:SerializedName("SPART")
	val spart: String? = null,

	@field:SerializedName("VTEXT")
	val vText: String? = null,

	@field:SerializedName("MANDT")
	val mandt: String? = null
) : Parcelable
