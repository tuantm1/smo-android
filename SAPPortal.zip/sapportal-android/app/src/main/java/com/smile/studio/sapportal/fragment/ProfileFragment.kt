package com.smile.studio.sapportal.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.libsmilestudio.utils.SharedPreferencesUtils
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.activity.ChangePasswordActivity
import com.smile.studio.sapportal.activity.ListUserActivity
import com.smile.studio.sapportal.activity.SplashActivity
import com.smile.studio.sapportal.adapter.ProfileAdapter
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.model.TypeAction
import com.smile.studio.sapportal.network.model.TypeMenu
import com.smile.studio.sapportal.network.response.Menu
import com.smile.studio.sapportal.view.SettingDomainDialogFragment
import com.yqritc.recyclerviewflexibledivider.HorizontalDividerItemDecoration
import kotlinx.android.synthetic.main.fragment_profile.*

class ProfileFragment : BaseFragment(), View.OnClickListener {

    var adapter: ProfileAdapter? = null
    var layoutManager: LinearLayoutManager? = null

    fun newInstance(): ProfileFragment {
        val fragment = ProfileFragment()
        return fragment
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        tv_username.text = GlobalApp.getInstance().profile?.username
        tv_password.text = "******"
        val mData: ArrayList<Menu> = GlobalApp.getInstance().mDataMenu.filter { it.zzstatus!!.equals(TypeMenu.MENU_PROFILE.value.toString()) } as ArrayList<Menu>
        adapter = ProfileAdapter(activity, mData)
        layoutManager = LinearLayoutManager(activity)
        recyclerView.adapter = adapter
        adapter?.onItemClick = object : OnItemClickListenerRecyclerView {
            override fun onClick(view: View?, position: Int) {
                val lstAction = adapter?.mData?.get(position)?.action
                if (lstAction?.isEmpty()!!) {
                    Debug.e("--- Error not found action")
                } else if (lstAction.size >= 1) {
                    val action = lstAction.get(0)
                    Debug.e("--- Function module: \"${action.functionmodule}\"")
                    when (action.functionmodule) {
                        TypeAction.GET_USER.value -> {
                            val intent = Intent(activity!!, ListUserActivity::class.java)
                            startActivity(intent)
                        }
                        TypeAction.CHANGE_PASSWORD.value -> {
                            val intent = Intent(activity!!, ChangePasswordActivity::class.java)
                            startActivity(intent)
                        }
                        else -> {
                            Debug.showAlert(activity, getString(R.string.message_can_not_used_feature))
                            Debug.e("--- Function module: is not validate \"${action.functionmodule}\"")
                        }
                    }
                }
            }

            override fun onLongClick(view: View?, position: Int) {

            }

        }
        recyclerView.layoutManager = layoutManager
        recyclerView.setHasFixedSize(true)
        recyclerView.isNestedScrollingEnabled = false
        recyclerView.addItemDecoration(HorizontalDividerItemDecoration.Builder(activity).drawable(R.drawable.ic_line_shape_gray).build())
        btn_logout.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btn_logout -> {
                SharedPreferencesUtils.clearAll(activity)
                val intent = Intent(activity, SplashActivity::class.java)
                startActivity(intent)
                activity?.finish()
            }
        }
    }
}