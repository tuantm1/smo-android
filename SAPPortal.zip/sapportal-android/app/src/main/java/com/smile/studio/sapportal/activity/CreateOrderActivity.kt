package com.smile.studio.sapportal.activity

import android.os.Bundle
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.fragment.order.create.CreateOrderFragment
import com.smile.studio.sapportal.fragment.order.create.DetailOrderFragment

class CreateOrderActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_order)
        onChangeFragment(CreateOrderFragment.newInstance(), "")
    }

    override fun onBackPressed() {
        if (supportFragmentManager.backStackEntryCount >= 1) {
            supportFragmentManager.popBackStack()
            val fragment = supportFragmentManager.findFragmentById(R.id.container)
            if (fragment?.tag.equals(DetailOrderFragment::class.java.simpleName)) {
            }
            Debug.e("--- Back tag: ${fragment?.tag}")
        } else {
            super.onBackPressed()
        }
    }
}