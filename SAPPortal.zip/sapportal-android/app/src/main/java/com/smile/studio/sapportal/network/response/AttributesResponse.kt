package com.smile.studio.sapportal.network.response

import com.google.gson.annotations.SerializedName

class AttributesResponse(
        @SerializedName("DATA")
        val data : ArrayList<Attributes>
) {
}