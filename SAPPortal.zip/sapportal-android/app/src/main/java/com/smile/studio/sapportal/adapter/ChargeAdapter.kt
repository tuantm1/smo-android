package com.smile.studio.sapportal.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.network.model.Charge

class ChargeAdapter(val mContext: Context?, val mData: ArrayList<Charge>?) : BaseAdapter() {

    var onItemClick: OnItemClickListenerRecyclerView? = null
    var mFilter: ArrayList<Charge>? = mData

    fun addAll(mData: ArrayList<Charge>) {
        this.mFilter?.addAll(mData)
        notifyDataSetChanged()
    }

    fun clear() {
        this.mFilter?.clear()
        notifyDataSetChanged()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var view: View? = convertView
        val holder: ViewHolder
        if (view == null) {
            view = LayoutInflater.from(mContext).inflate(R.layout.simple_spinner_item, parent, false)
            holder = ViewHolder(view)
            view?.tag = holder
        } else {
            holder = view.tag as ViewHolder
        }
        holder.init(mData?.get(position)!!)
        return view!!
    }

    override fun getItem(position: Int): Charge {
        return mFilter?.get(position)!!
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getCount(): Int {
        return mFilter?.size!!
    }

    inner class ViewHolder(view: View) {

        val tv_name = view.findViewById<TextView>(android.R.id.text1)

        fun init(charge: Charge) {
            tv_name.text = charge.description
            tv_name.isSelected = true
        }
    }

}