package com.smile.studio.sapportal.fragment

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.activity.BaseActivity
import com.smile.studio.sapportal.activity.DetailDeliverHistoryActivity
import com.smile.studio.sapportal.adapter.DeliverHistoryAdapter
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.face.SAPPortal
import com.smile.studio.sapportal.network.model.API
import com.smile.studio.sapportal.network.model.DeliverHistory
import com.smile.studio.sapportal.network.model.Item
import com.smile.studio.sapportal.network.model.TypeDeliver
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_child_deliver.*
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.util.*
import kotlin.collections.ArrayList

class ChildDeliverFragment : BaseFragment(), SwipeRefreshLayout.OnRefreshListener {

    val calendar = Calendar.getInstance()
    var layoutManager: LinearLayoutManager? = null
    var historyAdapter: DeliverHistoryAdapter? = null
    var items = ArrayList<Item>()
    var date = ""
    var typeDeliver = TypeDeliver.DELIVER.value

    companion object {
        fun newInstance(valueType: Int): ChildDeliverFragment {
            val bundle = Bundle()
            bundle.putInt(TypeDeliver::class.java.simpleName, valueType)
            val fragment = ChildDeliverFragment()
            fragment.arguments = bundle
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_child_deliver, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        typeDeliver = arguments?.getInt(TypeDeliver::class.java.simpleName, TypeDeliver.DELIVER.value)!!
        val holoGreenLight = android.R.color.holo_green_light
        swipeRefreshLayout.setColorSchemeResources(android.R.color.holo_blue_bright, holoGreenLight, android.R.color.holo_orange_light, android.R.color.holo_red_light)
        swipeRefreshLayout.setOnRefreshListener(this)
        swipeRefreshLayout.isRefreshing = false
        layoutManager = LinearLayoutManager(activity)
        recyclerView.layoutManager = layoutManager
        historyAdapter = DeliverHistoryAdapter(activity, ArrayList())
        recyclerView.adapter = historyAdapter
        historyAdapter?.onItemClick = object : OnItemClickListenerRecyclerView {
            override fun onClick(view: View?, position: Int) {
                val deliver = historyAdapter?.mData?.get(position)
                val intent = Intent(activity, DetailDeliverHistoryActivity::class.java)
                intent.putExtra(TypeDeliver::class.java.simpleName, typeDeliver)
                intent.putExtra(DeliverHistory::class.java.simpleName, deliver)
                val lstItems: ArrayList<Item> = items.filter { it.saleOrder?.equals(deliver?.salesOrder, true)!! } as ArrayList<Item>
                intent.putExtra(Item::class.java.simpleName, lstItems)
                startActivity(intent)
            }

            override fun onLongClick(view: View?, position: Int) {

            }

        }
        recyclerView.setHasFixedSize(true)
        thumb_empty.setColorFilter(ContextCompat.getColor(requireActivity(), R.color.gray))
        date = if (TextUtils.isEmpty(date)) GlobalApp.getInstance().dateFormat1.format(Date()) else date
        getData(date)
    }

    private fun getData(date: String) {
        if (TextUtils.isEmpty(date))
            return
        (activity as BaseActivity).showProgressDialog()
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getListDeliver("", date, GlobalApp.getInstance().profile?.username!!, typeDeliver)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            swipeRefreshLayout.isRefreshing = false
            (activity as BaseActivity).dismissProgressDialog()
        }.subscribe({
            historyAdapter?.addAll(it.data!!)
            items.addAll(it.dataItem!!)
            val dateShow = GlobalApp.getInstance().dateFormat2.format(GlobalApp.getInstance().dateFormat1.parse(date))
            tv_username.text = "${GlobalApp.getInstance().profile?.username} - ${dateShow}"
            tv_status.text = "Ngày cập nhật $dateShow, ${historyAdapter?.mData?.size} đơn hàng"
            if (historyAdapter?.itemCount!! > 0) {
                message_group.visibility = View.GONE
            } else {
                message_group.visibility = View.VISIBLE
            }
        }, {
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    @Subscribe(threadMode = ThreadMode.MAIN, sticky = true)
    fun onMessage(date: String) {
        try {
            this.date = date
            historyAdapter?.clear()
            getData(date)
        } catch (e : Exception){
            Debug.e("--- Error: ${e.message}")
        }
    }

    override fun onAttach(context: Context) {
        EventBus.getDefault().register(this)
        super.onAttach(context)
    }

    override fun onDestroyView() {
        EventBus.getDefault().unregister(this)
        super.onDestroyView()
    }

    override fun onRefresh() {
        if (swipeRefreshLayout.isRefreshing) {
            historyAdapter?.clear()
            items.clear()
            page = 0
            getData(date)
        }
    }

    override fun onPause() {
        super.onPause()
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.isRefreshing = false
            swipeRefreshLayout.destroyDrawingCache()
            swipeRefreshLayout.clearAnimation()
        }
    }
}