package com.smile.studio.sapportal.network.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Dashboard(

	@field:SerializedName("TEXT")
	val text: String? = null,

	@field:SerializedName("VALUE")
	val value: Int? = 0
) : Parcelable{
	fun trace(){
		Debug.e("value: ${value}\ntext: ${text}")
	}
}
