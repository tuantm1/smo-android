package com.smile.studio.sapportal.network.request

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.smile.studio.sapportal.network.model.User
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ChangePasswordRequest(

        @field:SerializedName("THEUSER")
        var user: User? = null
) : Parcelable
