package com.smile.studio.sapportal.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.network.model.Items
import com.smile.studio.sapportal.view.TextLabel

class ProductOrderAdapter(val mContext: Context?, val mData: ArrayList<Items>?) : RecyclerView.Adapter<ProductOrderAdapter.ViewHolder>() {

    var onItemClick: OnItemClickListenerRecyclerView? = null

    fun addAll(mData: ArrayList<Items>) {
        this.mData?.addAll(mData)
        notifyDataSetChanged()
    }

    fun clear() {
        this.mData?.clear()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(mContext).inflate(R.layout.custom_item_product_order, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return mData?.size!!
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tv_product_name.setValue("${mData?.get(position)?.name}")
        holder.tv_product_quantity.setValue("${mData?.get(position)?.quantity}")
        holder.tv_product_type.setValue("${mData?.get(position)?.saleUnit}")
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tv_product_name = view.findViewById<TextLabel>(R.id.tv_product_name)
        val tv_product_quantity = view.findViewById<TextLabel>(R.id.tv_product_quantity)
        val tv_product_type = view.findViewById<TextLabel>(R.id.tv_product_type)
    }
}