package com.smile.studio.sapportal.network.zip

import com.google.gson.annotations.SerializedName
import com.smile.studio.sapportal.network.model.Credit
import com.smile.studio.sapportal.network.model.Deliver
import com.smile.studio.sapportal.network.model.DetailUserCredit
import com.smile.studio.sapportal.network.response.BaseResponse

class ZipDetailUserCreadit(
        @SerializedName("")
        val user1: BaseResponse<Credit>,
        @SerializedName("")
        val user2: DetailUserCredit
) {
}