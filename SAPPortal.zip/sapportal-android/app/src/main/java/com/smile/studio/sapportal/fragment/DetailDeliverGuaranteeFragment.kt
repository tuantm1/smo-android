package com.smile.studio.sapportal.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.activity.BaseActivity
import com.smile.studio.sapportal.network.model.DeliverGuarantee

class DetailDeliverGuaranteeFragment : BaseFragment() {

    companion object {
        fun newInstance(): DetailDeliverGuaranteeFragment {
            val fragment = DetailDeliverGuaranteeFragment()
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_detail_deliver_guarantee, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        (activity as BaseActivity).shareViewModel?.getData()?.observe(viewLifecycleOwner, Observer<Any?> { detail ->
            if (detail is DeliverGuarantee) {
                detail.trace()
            }
        })
    }
}
