package com.smile.studio.sapportal.network.response

import com.google.gson.annotations.SerializedName
import com.smile.studio.sapportal.network.model.Dashboard
import com.smile.studio.sapportal.network.model.Return

class BaseResponse<T>(
        @SerializedName("RETURN")
        val message: Return? = null,
        @SerializedName("GT_DASHBOARD")
        val dashboard: T? = null,
        @SerializedName("DATA", alternate = arrayOf("MARAS", "CUSTOMERS", "GT_CREDIT", "RESPONSE", "PARENTS", "CUSTOMER", "GT_DATA", "GT_BOTOI", "GT_THANHRAY", "GT_CHARACTER", "ET_DATA"))
        val data: T? = null,
        @SerializedName("IT_MARAS")
        val maras: T? = null,
        @SerializedName("GT_SALEORG")
        val sales: T? = null,
        @SerializedName("GT_DC")
        val salesChannel: T? = null,
        @SerializedName("GT_DIVISION")
        val industryInformation: T? = null,
        @SerializedName("RES")
        val resource: T? = null,
        @SerializedName("ID_ORDER")
        val idOrder: T? = null
)