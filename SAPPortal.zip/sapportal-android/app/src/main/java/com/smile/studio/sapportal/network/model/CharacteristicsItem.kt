package com.smile.studio.sapportal.network.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug
import kotlinx.android.parcel.Parcelize

@Parcelize
class CharacteristicsItem(

        @field:SerializedName("MATNR")
        var matnr: String? = null,

        @field:SerializedName("ZSORT")
        val zSort: String? = null,

        @field:SerializedName("ZGROUP")
        val zGroup: String? = "",

        @field:SerializedName("SMBEZ")
        val smbez: String? = null,

        @field:SerializedName("VALUE")
        var value: String? = "",

        @field:SerializedName("ATNAM")
        val atnam: String? = null,

        @field:SerializedName("ZTYPE")
        val zType: String? = null,

        @field:SerializedName("ZDEFAULT")
        val zDefault: String? = null,

        @field:SerializedName("data")
        var data: ArrayList<Value2Item>? = null,

        @field:SerializedName("ausp1")
        var ausp1: String? = null
) : Parcelable {

    fun trace() {
        Debug.e("ZSORT: ${zSort}\nZGROUP: ${zGroup}\nATNAM: ${atnam}\nSMBEZ: ${smbez}\nvalue: ${value}")
    }

    companion object {

        val Z_THANH_RAY_CLIENT = "Z_THANH_RAY_CLIENT"
        val Z_BO_TOI_CLIENT = "Z_BO_TOI_CLIENT"
        val Z_MAU_SAC = "Z_MAU_SAC"
        val Z_MODEL_BT = "Z_MODEL_BT"
        val Z_H_THOANG = "Z_H_THOANG"
        val Z_DIEN_TICH = "Z_DIEN_TICH"
        val Z_HEIGHT = "Z_HEIGHT"
        val Z_WIDTH = "Z_WIDTH"
        val Z_LOAI_CUA = "Z_LOAI_CUA"
        val Z_MODEL_CUA = "Z_MODEL_CUA"
        val Z_SO_LUONG = "Z_SO_LUONG"
        val Z_KT_RAY0 = "Z_KT_RAY0"
        val Z_THANH_RAY = "Z_THANH_RAY"
        val Z_KT_THANH = "Z_KT_THANH"
        val Z_SO_THANH = "Z_SO_THANH"
        val Z_KO_DAU_TRUC = "Z_KO_DAU_TRUC"
        val Z_RAY_TL0 = "Z_RAY_TL0"
        val Z_RAY = "Z_RAY"
        val Z_KT_RAY = "Z_KT_RAY"

        fun getTitle(zgroup: String): String {
            return when (zgroup) {
                Type.GROUP_1.value -> Type.GROUP_1.description
                Type.GROUP_2.value -> Type.GROUP_2.description
                Type.GROUP_3.value -> Type.GROUP_3.description
                Type.GROUP_4.value -> Type.GROUP_4.description
                Type.GROUP_5.value -> Type.GROUP_5.description
                Type.GROUP_6.value -> Type.GROUP_6.description
                Type.GROUP_7.value -> Type.GROUP_7.description
                Type.GROUP_8.value -> Type.GROUP_8.description
                else -> Type.GROUP_9.description
            }
        }

    }

    enum class Type(val value: String, val description: String) {
        GROUP_1("01", "Quy Cách"),
        GROUP_2("02", "Kích Thước"),
        GROUP_3("03", "Độ cao lắp PC"),
        GROUP_4("04", "Chiều dài Khung/Trục"),
        GROUP_5("05", "Chiều dài Khung HKT"),
        GROUP_6("06", "Trục cửa"),
        GROUP_7("07", "Bộ tời"),
        GROUP_8("08", "Ray"),
        GROUP_9("09", "Giá đỡ")
    }
}