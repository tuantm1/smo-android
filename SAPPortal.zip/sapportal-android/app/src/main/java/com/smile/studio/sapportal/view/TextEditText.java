package com.smile.studio.sapportal.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.smile.studio.sapportal.R;

/**
 * Created by admin on 25/10/2016.
 */
@SuppressLint("NewApi")
public class TextEditText extends LinearLayout {

    private View view;
    private TextView tv_label;
    private EditText editText;

    public TextEditText(Context context) {
        super(context);
        init(context);
    }

    public TextEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public TextEditText(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    private void init(Context context) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view = inflater.inflate(R.layout.custom_layout_type_edit_text, this, true);
        tv_label = view.findViewById(R.id.tv_label);
        editText = view.findViewById(R.id.ediText);
    }

    @SuppressWarnings("ResourceAsColor")
    private void init(Context context, AttributeSet attrs) {
        init(context);
        TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.TextLabel, 0, 0);
        String text = ta.getString(R.styleable.TextLabel_textLabel);
        int color1 = ta.getColor(R.styleable.TextLabel_textColor1, ContextCompat.getColor(context, android.R.color.darker_gray));
        int inputType = ta.getInt(R.styleable.TextLabel_inputType, InputType.TYPE_CLASS_TEXT);
        int gravity = ta.getInt(R.styleable.TextLabel_gravity, Gravity.CENTER | Gravity.LEFT);
        Typeface typeface = editText.getTypeface();
        ta.recycle();
        tv_label.setText(text);
        tv_label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        tv_label.setTextColor(color1);
        editText.setSelected(true);
        editText.setInputType(inputType);
        editText.setGravity(gravity);
        editText.setTypeface(typeface);
    }

    public void setEnabled(boolean isEnabled) {
        editText.setEnabled(isEnabled);
    }

    public Object getTag() {
        return editText.getTag();
    }

    public void setTag(String tag) {
        editText.setTag(tag);
    }

    public void setGravity(int gravity) {
        editText.setGravity(gravity);
    }

    public int getId() {
        return editText.getId();
    }

    public void setId(int id) {
        editText.setId(id);
    }

    public void setLabel(String label) {
        tv_label.setText(label);
    }

    public String getValue() {
        return editText.getText().toString();
    }

    public void setValue(String value) {
        editText.setText(value);
    }

    public void setInputType(int inputType) {
        editText.setInputType(inputType);
    }

    public void setImeOptions(int imeOptions) {
        editText.setImeOptions(imeOptions);
    }

    public void setSelection(int index){
        editText.setSelection(index);
    }

    public void setOnEditorActionListener(TextView.OnEditorActionListener listener) {
        editText.setOnEditorActionListener(listener);
    }

    public void addTextChangedListener(TextWatcher listener) {
        editText.addTextChangedListener(listener);
    }

}
