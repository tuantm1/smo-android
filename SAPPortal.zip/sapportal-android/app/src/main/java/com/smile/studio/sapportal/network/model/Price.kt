package com.smile.studio.sapportal.network.model

import com.google.gson.annotations.SerializedName
import java.math.BigDecimal

data class Price(

        @field:SerializedName("NET_VALUE")
        val netValue: BigDecimal? = null,

        @field:SerializedName("ID_ORDER")
        val idOrder: String? = null,

        @field:SerializedName("TOTAL_INQUIRY")
        val totalInQuiry: String? = null,

        @field:SerializedName("TGTDH")
        val tgtdh: BigDecimal? = null,

        @field:SerializedName("STDBL")
        val stdbl: BigDecimal? = null,

        @field:SerializedName("CK")
        val ck: BigDecimal? = null,

        @field:SerializedName("TAX")
        val tax: BigDecimal? = null
)
