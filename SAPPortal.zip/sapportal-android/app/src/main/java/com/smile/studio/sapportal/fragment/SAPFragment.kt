package com.smile.studio.sapportal.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.activity.SwitchMenuActivity
import com.smile.studio.sapportal.adapter.MenuAdapter
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.model.TypeMenu
import com.smile.studio.sapportal.network.response.Menu
import kotlinx.android.synthetic.main.fragment_menu.*
import kotlinx.android.synthetic.main.fragment_menu.message_group
import kotlinx.android.synthetic.main.fragment_menu.recyclerView

class SAPFragment : BaseFragment() {

    var adapter: MenuAdapter? = null
    var layoutManager: LinearLayoutManager? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_menu, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        numberColumns = 1
        layoutManager = LinearLayoutManager(activity)
        recyclerView.layoutManager = layoutManager
        val mData = GlobalApp.getInstance().mDataMenu.filter { it.zzstatus?.equals(TypeMenu.MENU_SAP.value.toString())!! } as ArrayList<Menu>
        mData.forEachIndexed { index, menu ->
            menu.color = GlobalApp.getInstance().colors.get(index % 10)
        }
        adapter = MenuAdapter(activity, numberColumns, mData)
        recyclerView.adapter = adapter
        adapter?.onItemClick = object : OnItemClickListenerRecyclerView{
            override fun onClick(view: View?, position: Int) {
                val item = adapter?.mData?.get(position)
                item?.trace()
                val intent = Intent(activity, SwitchMenuActivity::class.java)
                intent.putExtra(Menu::class.java.simpleName, item)
                startActivity(intent)
            }

            override fun onLongClick(view: View?, position: Int) {
                
            }

        }
        recyclerView.setHasFixedSize(true)
        thumb_empty.setColorFilter(ContextCompat.getColor(requireActivity(), R.color.gray))
        if (adapter?.itemCount!! > 0) {
            message_group.visibility = View.GONE
        } else {
            message_group.visibility = View.VISIBLE
        }
    }

}