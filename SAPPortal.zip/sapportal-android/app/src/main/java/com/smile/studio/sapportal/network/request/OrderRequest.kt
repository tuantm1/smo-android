package com.smile.studio.sapportal.network.request

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.network.model.DetailProperties
import kotlinx.android.parcel.Parcelize

@Parcelize
class OrderRequest(
        @SerializedName("ID_USER")
        val uid: String,
        @SerializedName("request")
        val data: DetailProperties
) : Parcelable {
    fun trace() {
        Debug.e("ID_USER: ${uid}")
        data.trace()
    }
}

