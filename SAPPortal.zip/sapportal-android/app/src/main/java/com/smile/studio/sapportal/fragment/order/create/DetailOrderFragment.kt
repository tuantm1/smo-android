package com.smile.studio.sapportal.fragment.order.create

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.libsmilestudio.utils.KeyboardUtils
import com.smile.studio.libsmilestudio.utils.Utils
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.activity.BaseActivity
import com.smile.studio.sapportal.adapter.AttributesAdapter
import com.smile.studio.sapportal.fragment.BaseFragment
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.face.SAPPortal
import com.smile.studio.sapportal.network.model.*
import com.smile.studio.sapportal.network.response.Attributes
import com.smile.studio.sapportal.network.response.BaseResponse
import com.smile.studio.sapportal.network.zip.ZipFilter
import com.smile.studio.sapportal.view.TextEditText
import com.smile.studio.sapportal.view.TextSpinner
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.functions.Function3
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_detail_order.*
import java.text.DecimalFormat

class DetailOrderFragment : BaseFragment(), View.OnClickListener {

    var haveAttributes = false
    val LABEL_CHON_THANH_RAY = "Chọn thanh ray"
    val LABEL_CHON_BO_TOI = "Chọn bộ tời"
    val map = LinkedHashMap<String, HashMap<String, ArrayList<CharacteristicsItem>>>()
    lateinit var filterRefer: ArrayList<Value2Item>
    lateinit var filterBoToi: ArrayList<Value2Item>
    lateinit var filterThanhRay: ArrayList<Value2Item>
    var adapterBoToi: AttributesAdapter? = null
    var adapterThanhRay: AttributesAdapter? = null
    var width: Float? = 0F
    var height: Float? = 0F
    var area: Float? = 0F
    var decimalFormat = DecimalFormat("###,###.###")
    var indexItem = 0
    var dataSubmit = LinkedHashMap<Int, Attributes>()
    var matnr = ""
    lateinit var dataTranfer: DetailProperties
    var mBuffer = ArrayList<String>()

    companion object {

        fun newInstance(): DetailOrderFragment {
            val fragment = DetailOrderFragment()
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_detail_order, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        map.put(CharacteristicsItem.Type.GROUP_1.value, HashMap())
        map.put(CharacteristicsItem.Type.GROUP_2.value, HashMap())
        map.put(CharacteristicsItem.Type.GROUP_3.value, HashMap())
        map.put(CharacteristicsItem.Type.GROUP_4.value, HashMap())
        map.put(CharacteristicsItem.Type.GROUP_5.value, HashMap())
        map.put(CharacteristicsItem.Type.GROUP_6.value, HashMap())
        map.put(CharacteristicsItem.Type.GROUP_7.value, HashMap())
        map.put(CharacteristicsItem.Type.GROUP_8.value, HashMap())
        map.put(CharacteristicsItem.Type.GROUP_9.value, HashMap())
        (activity as BaseActivity).shareViewModel?.getData()?.observe(viewLifecycleOwner, Observer<Any?> { data ->
            if (data is SampleOrder) {
                data(data)
            }
        })
        btn_accept.setColorFilter(ContextCompat.getColor(requireActivity(), R.color.white))
        btn_back.setOnClickListener(this)
        btn_accept.setOnClickListener(this)
    }

    fun data(sampleOrder: SampleOrder) {
        val idTemp: String = sampleOrder.idTemplate!!
        (activity as BaseActivity).showProgressDialog()
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getDetailTemp(idTemp)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            (activity as BaseActivity).dismissProgressDialog()
        }.subscribe({
            dataTranfer = it.data!!
            val content = it.data.items?.get(0)
            tv_title.text = Utils.fromHtml(getString(R.string.title_detail_order, content?.name))
            tv_title.isSelected = true
            //Lọc lấy danh sách nhóm cần hiển thị
            val listProperties = it.data.items?.get(0)?.characteristics
            listProperties?.forEachIndexed { index, itemsItem ->
                val id = itemsItem.zGroup!!
                val child = HashMap<String, ArrayList<CharacteristicsItem>>()
                child.put(CharacteristicsItem.getTitle(id), ArrayList<CharacteristicsItem>())
                map.put(id, child)
            }
            //Lọc lấy toàn bộ danh sách thuộc tính trong nhóm cần hiển thị
            map.forEach { key, valueRoot ->
                val mData = ArrayList<CharacteristicsItem>()
                listProperties?.forEachIndexed { index, characteristicsItem ->
                    if (characteristicsItem.zGroup?.equals(key)!!) {
                        mData.add(characteristicsItem)
                        characteristicsItem.trace()
                        mBuffer.add(characteristicsItem.atnam!!)
                        haveAttributes = true
                    }
                }
                valueRoot.put(CharacteristicsItem.getTitle(key), mData)
                map.put(key, valueRoot)
            }
            if (!haveAttributes) {
                Debug.e("--- Khong co danh sach nhom thuoc tinh can hien thi")
                btn_accept.performClick()
            } else {
                Debug.e("--- Co danh sach nhom thuoc tinh can hien thi")
                matnr = it.data.items?.get(0)?.matnr!!
                loadgetCharacteristic(matnr)
            }
        }, {
            Debug.e("--- Error: ${it.message}")
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    @SuppressLint("NewApi")
    private fun loadgetCharacteristic(objek: String?) {
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getCharacteristic(objek!!)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
        }.subscribe({
            val mData = it.data
            map.forEach { key, dataGroups ->
                dataGroups.values.forEachIndexed { index, arrayList ->
                    if (!arrayList.isEmpty()) {
                        arrayList.forEachIndexed { index, chdataaracteristicsItem ->
                            mData.forEachIndexed { index, attributes ->
                                val atnam = attributes.atnam
                                if (atnam.equals(chdataaracteristicsItem.atnam) && !attributes.value2?.isEmpty()!!) {
                                    chdataaracteristicsItem.data = ArrayList(attributes.value2)
                                    dataGroups.put(CharacteristicsItem.getTitle(key), arrayList)
                                    map.put(key, dataGroups)
                                }
                            }
                        }
                    }
                }
            }
            fillter(matnr = objek)
        }, {
            Debug.e("--- Error: ${it.message}")
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    //Hiển thị lên giao diện xử lý
    @SuppressLint("NewApi")
    private fun renderUI(mFilterMap: LinkedHashMap<String, LinkedHashMap<Value2Item, ArrayList<Value2Item>>>, mFilterMap_Mau_Sac: ArrayList<Value2Item>) {
        map.forEach { key, valueRoot ->
            valueRoot.forEach { titleGroups, dataGroups ->
                if (!dataGroups.isEmpty()) {
                    val viewGroup = LayoutInflater.from(activity).inflate(R.layout.custom_item_group_detail_order, null)
                    val groupsProperties = viewGroup.findViewById<LinearLayout>(R.id.groupsProperties)
                    val tv_title = viewGroup.findViewById<TextView>(R.id.tv_title)
                    tv_title.text = titleGroups
                    stickyScrollView.addView(viewGroup)
                    dataGroups.forEachIndexed { index, characteristicsItem ->
                        if (characteristicsItem.data != null && !characteristicsItem.data?.isEmpty()!!) {
                            val textSpinner = TextSpinner(activity)
                            textSpinner.setTag(characteristicsItem.atnam)
                            textSpinner.onFocusChangeListener =
                                object : View.OnFocusChangeListener {
                                    override fun onFocusChange(v: View?, hasFocus: Boolean) {
                                        if (hasFocus) {
                                            KeyboardUtils.forceCloseKeyboard(v)
                                        }
                                    }

                                }
                            val mTitle = characteristicsItem.smbez?.replace("Model", "Loại")
                            textSpinner.setLabel(mTitle)
                            val adapter = AttributesAdapter(activity, ArrayList(), false)
                            val tag = textSpinner.tag.toString()
                            when (tag) {
                                CharacteristicsItem.Z_MODEL_CUA -> {
                                    if (!TextUtils.isEmpty(mFilterMap.keys.find { return@find it.equals(tag) })) {
                                        Debug.e("--- Dữ liệu filter Z_MODEL_CUA mở rộng: ${tag} gồm: ${mFilterMap.get(tag)?.keys}")
                                        val dataShow = ArrayList<Value2Item>()
                                        mFilterMap.get(tag)?.keys?.forEachIndexed { index, value2Item ->
                                            dataShow.add(value2Item)
                                        }
                                        adapter.addAll(dataShow)
                                    }
                                }
                                CharacteristicsItem.Z_MAU_SAC -> {
                                    adapter.addAll(mFilterMap_Mau_Sac)
                                }
                                CharacteristicsItem.Z_MODEL_BT -> {
                                    adapter.addAll(filterBoToi)
                                }
                                CharacteristicsItem.Z_THANH_RAY_CLIENT -> {
                                    adapter.addAll(filterThanhRay)
                                }
                                else -> {
                                    adapter.addAll(characteristicsItem.data!!)
                                }
                            }
                            textSpinner.setAdapter(adapter)
                            textSpinner.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
                                override fun onNothingSelected(parent: AdapterView<*>?) {

                                }

                                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                                    when (textSpinner.tag) {
                                        CharacteristicsItem.Z_MODEL_CUA -> {
                                            val value2ItemSelected = adapter.getItem(position)
                                            val attr = Attributes()
                                            attr.atnam = textSpinner.tag.toString()
                                            attr.smbez = characteristicsItem.smbez
                                            attr.zGroup = characteristicsItem.zGroup
                                            attr.zSort = characteristicsItem.zSort
                                            attr.zType = characteristicsItem.zType
                                            attr.value = value2ItemSelected.value
                                            dataSubmit.put(textSpinner.id, attr)
                                            dataSubmit.get(textSpinner.id)?.trace()
                                            try {
                                                //TODO
                                                if (!TextUtils.isEmpty(attr.value)) {
                                                    Debug.e("--- filter color")
                                                    var mDataModelDoor = ArrayList<Value2Item>()
                                                    if (!TextUtils.isEmpty(mFilterMap.keys.find {
                                                            return@find it.equals(
                                                                tag
                                                            )
                                                        })) {
                                                        mDataModelDoor = filterRefer.filter {
                                                            return@filter it.matnr.equals(
                                                                value2ItemSelected.matnr
                                                            ) && it.zmbez.equals(CharacteristicsItem.Z_MODEL_CUA) && it.value.equals(
                                                                value2ItemSelected.value
                                                            )
                                                        } as ArrayList<Value2Item>
                                                    }
                                                    val spinner =
                                                        getView()?.findViewWithTag<Spinner>(
                                                            CharacteristicsItem.Z_MAU_SAC
                                                        )
                                                    val adapterMauSac =
                                                        spinner?.adapter as AttributesAdapter
                                                    adapterMauSac.filterColor(mDataModelDoor)
                                                    spinner.setSelection(0, true)
                                                }
                                            } catch (e: Exception) {
                                                Debug.e("--- Error: ${e.message}")
                                            }
                                        }
                                        CharacteristicsItem.Z_MAU_SAC -> {
                                            Debug.e("--- Chọn data thường: ${textSpinner.tag}")
                                            val value2Item = adapter.getItem(position)
                                            value2Item.trace()
                                            val attr = Attributes()
                                            attr.atnam = textSpinner.tag.toString()
                                            attr.smbez = characteristicsItem.smbez
                                            attr.zGroup = characteristicsItem.zGroup
                                            attr.zSort = characteristicsItem.zSort
                                            attr.zType = characteristicsItem.zType
                                            attr.value = value2Item.value
                                            dataSubmit.put(textSpinner.id, attr)
                                            dataSubmit.get(textSpinner.id)?.trace()
                                        }
                                        CharacteristicsItem.Z_MODEL_BT -> {
                                            Debug.e("--- Chọn lại bộ tời")
                                            val value2Item = adapter.getItem(position)
                                            adapterBoToi?.filterBoToi(value2Item.value!!, true)
                                            val attr = Attributes()
                                            attr.atnam = textSpinner.tag.toString()
                                            attr.smbez = characteristicsItem.smbez
                                            attr.zGroup = characteristicsItem.zGroup
                                            attr.zSort = characteristicsItem.zSort
                                            attr.zType = characteristicsItem.zType
                                            attr.value = value2Item.value
                                            dataSubmit.put(textSpinner.id, attr)
                                            dataSubmit.get(textSpinner.id)?.trace()
                                            val spinner = getView()?.findViewWithTag<Spinner>(CharacteristicsItem.Z_BO_TOI_CLIENT)
                                            try {
                                                val value2ItemBT = adapterBoToi?.getItem(0)!!
                                                val attrBT = Attributes()
                                                attrBT.atnam = spinner?.tag.toString()
                                                attrBT.value = value2ItemBT.maktx
                                                attrBT.matnr = value2ItemBT.matnr
                                                dataSubmit.put(spinner?.id!!, attrBT)
                                                dataSubmit.get(spinner.id)?.trace()
                                            } catch (e: Exception) {
                                                Debug.e("--- Error: ${e.message}")
                                            }
                                        }
                                        "Z_RAY_GR", "Z_RAY_KT_SD", "Z_RAY_KT15",
                                        "Z_RAY_KT17", "Z_RAY_KT19", "Z_RAY_KT24",
                                        "Z_RAY_KHAC", "Z_RAY_TL_SD", CharacteristicsItem.Z_RAY_TL0 -> {
                                            Debug.e("--- Chọn loại thanh ray")
                                            val value2Item = adapter.getItem(position)
                                            adapterThanhRay?.filterThanhRay(matnr, value2Item.value!!, true)
                                            val attr = Attributes()
                                            attr.atnam = textSpinner.tag.toString()
                                            attr.smbez = characteristicsItem.smbez
                                            attr.zGroup = characteristicsItem.zGroup
                                            attr.zSort = characteristicsItem.zSort
                                            attr.zType = characteristicsItem.zType
                                            attr.value = value2Item.value
                                            dataSubmit.put(textSpinner.id, attr)
                                            dataSubmit.get(textSpinner.id)?.trace()
                                            val spinner = getView()?.findViewWithTag<Spinner>(CharacteristicsItem.Z_THANH_RAY_CLIENT)
                                            try {
                                                val value2ItemBT = adapterThanhRay?.getItem(0)!!
                                                val attrTR = Attributes()
                                                attrTR.atnam = spinner?.tag.toString()
                                                attrTR.value = value2ItemBT.maktx
                                                attrTR.matnr = value2ItemBT.matnr
                                                dataSubmit.put(spinner?.id!!, attrTR)
                                                dataSubmit.get(spinner.id)?.trace()
                                            } catch (e: Exception) {
                                                Debug.e("--- Error: ${e.message}")
                                            }
                                        }
                                        else -> {
                                            Debug.e("--- Chọn data thường: ${textSpinner.tag}")
                                            val value2Item = adapter.getItem(position)
                                            val attr = Attributes()
                                            attr.atnam = textSpinner.tag.toString()
                                            attr.smbez = characteristicsItem.smbez
                                            attr.zGroup = characteristicsItem.zGroup
                                            attr.zSort = characteristicsItem.zSort
                                            attr.zType = characteristicsItem.zType
                                            attr.value = value2Item.valdescr
                                            dataSubmit.put(textSpinner.id, attr)
                                            dataSubmit.get(textSpinner.id)?.trace()
                                        }
                                    }
                                }

                            })
                            textSpinner.id = indexItem
                            indexItem += 1
                            groupsProperties.addView(textSpinner)
                        } else {
                            val textEditText = TextEditText(activity)
                            val tag = characteristicsItem.atnam
                            textEditText.setTag(tag)
                            if (tag.equals(CharacteristicsItem.Z_DIEN_TICH)) {
                                textEditText.value = "0"
                                textEditText.isEnabled = false
                                textEditText.setLabel("${characteristicsItem.smbez} (m2)")
                            } else if (tag.equals(CharacteristicsItem.Z_HEIGHT) || tag.equals(CharacteristicsItem.Z_WIDTH) || tag.equals(CharacteristicsItem.Z_H_THOANG)) {
                                textEditText.setLabel("${characteristicsItem.smbez} (mm)")
                            } else {
                                textEditText.setLabel(characteristicsItem.smbez)
                            }
                            textEditText.setInputType(InputType.TYPE_CLASS_NUMBER)
                            textEditText.setImeOptions(EditorInfo.IME_ACTION_NEXT)
                            textEditText.addTextChangedListener(object : TextWatcher {
                                override fun afterTextChanged(s: Editable?) {
                                }

                                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                                }

                                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                                    val editText = textEditText.findViewWithTag<EditText>(tag)
                                    if (tag.equals(CharacteristicsItem.Z_HEIGHT)) {
                                        height = if (TextUtils.isEmpty(editText.text.toString())) 0F else editText.text.toString().toFloat() / 1000
                                        area = (width!! * height!!)
                                        Debug.e("--- tag: ${tag}: ${height}")
                                        val editAreaText = view?.findViewWithTag<EditText>(CharacteristicsItem.Z_DIEN_TICH)
                                        editAreaText?.setText(decimalFormat.format(area))
                                    } else if (tag.equals(CharacteristicsItem.Z_WIDTH)) {
                                        width = if (TextUtils.isEmpty(editText.text.toString())) 0F else editText.text.toString().toFloat() / 1000
                                        area = (width!! * height!!)
                                        Debug.e("--- tag: ${tag}: ${width} ")
                                        val editAreaText = view?.findViewWithTag<EditText>(CharacteristicsItem.Z_DIEN_TICH)
                                        editAreaText?.setText(decimalFormat.format(area))
                                    } else {
                                        Debug.e("--- tag: ${tag}")
                                    }
                                    val attr = Attributes()
                                    attr.atnam = textEditText.tag.toString()
                                    attr.smbez = characteristicsItem.smbez
                                    attr.zGroup = characteristicsItem.zGroup
                                    attr.zSort = characteristicsItem.zSort
                                    attr.zType = characteristicsItem.zType
                                    attr.value = editText.text.toString()
                                    dataSubmit.put(editText.id, attr)
                                    dataSubmit.get(editText.id)?.trace()
                                }

                            })
                            textEditText.id = indexItem
                            indexItem += 1
                            groupsProperties.addView(textEditText)
                        }
                    }
                    //Thêm các thuộc tính đặc biệt
                    when (key) {
                        CharacteristicsItem.Type.GROUP_1.value -> {
                            Debug.e("--- title: ${key}: $titleGroups")
                        }
                        CharacteristicsItem.Type.GROUP_2.value -> {
                            Debug.e("--- title: ${key}: $titleGroups")
                        }
                        CharacteristicsItem.Type.GROUP_3.value -> {
                            Debug.e("--- title: ${key}: $titleGroups")
                        }
                        CharacteristicsItem.Type.GROUP_4.value -> {
                            Debug.e("--- title: ${key}: $titleGroups")
                        }
                        CharacteristicsItem.Type.GROUP_5.value -> {
                            Debug.e("--- title: ${key}: $titleGroups")
                        }
                        CharacteristicsItem.Type.GROUP_6.value -> {
                            Debug.e("--- title: ${key}: $titleGroups")
                        }
                        CharacteristicsItem.Type.GROUP_7.value -> {
                            Debug.e("--- title: ${key}: $titleGroups")
                            val textSpinner = TextSpinner(activity)
                            textSpinner.setLabel(LABEL_CHON_BO_TOI)
                            textSpinner.setTag(CharacteristicsItem.Z_BO_TOI_CLIENT)
                            textSpinner.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
                                override fun onNothingSelected(parent: AdapterView<*>?) {

                                }

                                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                                    Debug.e("--- Cần kiểm tra giá trị chọn ${CharacteristicsItem.Z_BO_TOI_CLIENT} tại đây")
                                    val value2Item = adapterBoToi?.getItem(position)
                                    val attr = Attributes()
                                    attr.atnam = textSpinner.tag.toString()
                                    attr.value = value2Item?.maktx
                                    attr.matnr = value2Item?.matnr
                                    dataSubmit.put(textSpinner.id, attr)
                                    dataSubmit.get(textSpinner.id)?.trace()
                                }

                            })
                            adapterBoToi = AttributesAdapter(activity, ArrayList(), true)
                            adapterBoToi?.addAll(filterBoToi)
                            textSpinner.setAdapter(adapterBoToi)
                            textSpinner.id = indexItem
                            indexItem += 1
                            groupsProperties.addView(textSpinner)
                        }
                        CharacteristicsItem.Type.GROUP_8.value -> {
                            Debug.e("--- title: ${key}: $titleGroups")
                            val textSpinner1 = TextSpinner(activity)
                            textSpinner1.setLabel(LABEL_CHON_THANH_RAY)
                            textSpinner1.setTag(CharacteristicsItem.Z_THANH_RAY_CLIENT)
                            textSpinner1.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
                                override fun onNothingSelected(parent: AdapterView<*>?) {

                                }

                                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                                    Debug.e("--- Cần kiểm tra giá trị chọn ${CharacteristicsItem.Z_THANH_RAY_CLIENT} tại đây")
                                    val value2Item = adapterThanhRay?.getItem(position)
                                    val attr = Attributes()
                                    attr.atnam = textSpinner1.tag.toString()
                                    attr.value = value2Item?.description
                                    attr.matnr = value2Item?.matnrRefer
                                    dataSubmit.put(textSpinner1.id, attr)
                                    dataSubmit.get(textSpinner1.id)?.trace()
                                }

                            })
                            adapterThanhRay = AttributesAdapter(activity, ArrayList(), true)
                            adapterThanhRay?.addAll(filterThanhRay)
                            textSpinner1.setAdapter(adapterThanhRay)
                            textSpinner1.id = indexItem
                            indexItem += 1
                            groupsProperties.addView(textSpinner1)
                        }
                        CharacteristicsItem.Type.GROUP_9.value -> {
                            Debug.e("--- title: ${key}: $titleGroups")
                        }
                        else -> {
                            Debug.e("--- Không nhận dạng được thông tin")
                        }
                    }
                }
            }
        }
    }

    /**
     * Lọc lấy danh sách các thuộc tính cần hiển thị
     */
    @SuppressLint("NewApi")
    fun fillter(matnr: String) {
        val requestFilter = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getFilterAttributes(matnr)
        val requestBoToi = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getFilterBoToi(matnr)
        val requestThanhRay = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getFilterThanhRay(matnr)
        val subscribe = Observable.zip(requestFilter, requestBoToi, requestThanhRay, object : Function3<BaseResponse<ArrayList<Value2Item>>, BaseResponse<ArrayList<Value2Item>>, BaseResponse<ArrayList<Value2Item>>, ZipFilter> {
            override fun apply(t1: BaseResponse<ArrayList<Value2Item>>, t2: BaseResponse<ArrayList<Value2Item>>, t3: BaseResponse<ArrayList<Value2Item>>): ZipFilter {
                return ZipFilter(t1, t2, t3)
            }

        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
        }.subscribe({
            filterRefer = it.dataFilter.data!!
            filterBoToi = it.dataBoToi.data!!
            filterThanhRay = it.dataThanhRay.data!!
            // LinkedHashMap<ZMBEZ, LinkedHashMap<VALUE, ArrayList<ID_MATNR_REFER>>>()
            val mFilterMap_Model_Cua = LinkedHashMap<String, LinkedHashMap<Value2Item, ArrayList<Value2Item>>>()
            mBuffer.forEachIndexed { index, value ->
                val attributes =
                    filterRefer.filter { return@filter it.zmbez.equals(value) } as ArrayList<Value2Item>
                if (!attributes.isEmpty()) {
                    val childMap = LinkedHashMap<Value2Item, ArrayList<Value2Item>>()
                    attributes.groupBy { it.value }.entries.map {
                        childMap.put(it.value.get(0), it.value as ArrayList<Value2Item>)
                    }
                    mFilterMap_Model_Cua.put(value, childMap)
                }
            }
            val mFilterMap_Mau_Sac =
                filterRefer.filter { return@filter it.zmbez.equals(CharacteristicsItem.Z_MAU_SAC) } as ArrayList<Value2Item>
//            val mauSac = ArrayList<Value2Item>()
//            mFilterMap_Mau_Sac.groupBy { it.value }.entries.map {
//                mauSac.add(it.value.get(0))
//            }
            renderUI(mFilterMap_Model_Cua, mFilterMap_Mau_Sac)
        }, {
            Debug.e("--- Error: ${it.message}")
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btn_back -> {
                if (haveAttributes) {
                    activity?.onBackPressed()
                } else {
                    activity?.finish()
                }
            }
            R.id.btn_accept -> {
                dataTranfer.origin = CreateOrderFragment.VKORG
                if (haveAttributes) {
                    dataTranfer.attributes = dataSubmit
                    val intent = Intent(activity, ConfirmOrderActivity::class.java)
                    intent.putExtra(DetailProperties::class.java.simpleName, dataTranfer)
                    intent.putExtra(ConfirmOrderActivity.HAVE_ATTRIBUTES, haveAttributes)
                    startActivity(intent)
                } else {
                    dataTranfer.attributes = dataSubmit
                    val intent = Intent(activity, ConfirmOrderActivity::class.java)
                    intent.putExtra(DetailProperties::class.java.simpleName, dataTranfer)
                    intent.putExtra(ConfirmOrderActivity.HAVE_ATTRIBUTES, haveAttributes)
                    startActivity(intent)
                    requireActivity().finish()
                }
            }
        }
    }
}