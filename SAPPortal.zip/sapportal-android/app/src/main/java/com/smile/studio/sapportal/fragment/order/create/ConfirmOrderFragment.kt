package com.smile.studio.sapportal.fragment.order.create

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.libsmilestudio.utils.IAction
import com.smile.studio.libsmilestudio.utils.Utils
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.activity.BaseActivity
import com.smile.studio.sapportal.activity.SwitchMenuActivity
import com.smile.studio.sapportal.adapter.ProductAdapter
import com.smile.studio.sapportal.adapter.RouteAdapter
import com.smile.studio.sapportal.fragment.BaseFragment
import com.smile.studio.sapportal.fragment.deliver.DetailDeliverOrderDialogFragment
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.face.SAPPortal
import com.smile.studio.sapportal.network.model.*
import com.smile.studio.sapportal.network.request.OrderRequest
import com.smile.studio.sapportal.network.request.ReasonRequest
import com.smile.studio.sapportal.network.response.*
import com.smile.studio.sapportal.network.zip.ZipCharacteristicItem
import com.smile.studio.sapportal.view.AddItemDialogFragment
import com.wdullaer.materialdatetimepicker.date.DatePickerDialog
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.functions.BiFunction
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_confirm_order.*
import java.math.BigDecimal
import java.util.*
import kotlin.collections.ArrayList

class ConfirmOrderFragment constructor(var haveAttributes: Boolean) : BaseFragment(), View.OnClickListener {

    private var route: String? = null
    private var vSart: String? = null
    val calendar = Calendar.getInstance()
    lateinit var adapter: ProductAdapter
    lateinit var cityAdapter: RouteAdapter
    lateinit var districtAdapter: RouteAdapter
    var sendData: OrderRequest? = null
    var division = ""
    var totalInquiry: String? = null
    var total_after_pirce: BigDecimal? = null
    var amount_to_guarantee: BigDecimal? = null
    var order_discount: BigDecimal? = null
    var tax: BigDecimal? = null
    var nameShipTo: String? = null
    val item = Items()
    val botoi = Items()
    val thanhray = Items()
    var size = 0

    companion object {
        fun newInstance(haveAttributes: Boolean): ConfirmOrderFragment {
            val fragment = ConfirmOrderFragment(haveAttributes)
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        //TODO: update bổ sung n.dung giao diện option issue 5
        //Ngày đặt hàng, điều chỉnh hiển thị thêm ngày hiện tại và giờ hiện tại định dạng hiển thị dd/MM/yyyy HH:mm
        return inflater.inflate(R.layout.fragment_confirm_order, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initData()
        (activity as BaseActivity).shareViewModel?.getData()?.observe(viewLifecycleOwner, Observer<Any?> { data ->
            if (data is DetailProperties) {
                division = data.division!!
                sendData = OrderRequest(GlobalApp.getInstance().profile?.uid!!, data)
                item.idHeader = data.items?.get(0)?.idHeader
                item.value = data.items?.get(0)?.value
                item.zReturn = data.items?.get(0)?.zReturn
                item.matnr = data.items?.get(0)?.matnr
                item.name = data.items?.get(0)?.name
                item.saleUnit = data.items?.get(0)?.saleUnit
                item.zdkgh = data.items?.get(0)?.zdkgh
                item.type = "O"
                var KTRay = 0F
                var SLgRay = 0F
                data.attributes?.values?.forEachIndexed { index, attributes ->
                    attributes.trace()
                    if (attributes.atnam == CharacteristicsItem.Z_WIDTH) {
                        item.width = if (!TextUtils.isEmpty(attributes.value)) attributes.value?.replace(",", ".")?.toFloatOrNull() else 0F
                    }
                    if (attributes.atnam == CharacteristicsItem.Z_HEIGHT) {
                        item.height = if (!TextUtils.isEmpty(attributes.value)) attributes.value?.replace(",", ".")?.toFloatOrNull() else 0F
                    }
                    if (attributes.atnam == CharacteristicsItem.Z_BO_TOI_CLIENT) {
                        botoi.matnr = attributes.matnr
                        botoi.name = attributes.value
                        botoi.quantity = 1F
                        botoi.saleUnit = "BOO"
                        botoi.type = "O"
                    }
                    if (attributes.atnam == CharacteristicsItem.Z_DIEN_TICH) {
                        item.quantity = if (!TextUtils.isEmpty(attributes.value)) attributes.value?.replace(",", ".")?.toFloatOrNull() else 0F
                        Debug.e("--- item.quantity = ${item.quantity}")
                    }
                    if (attributes.atnam == CharacteristicsItem.Z_THANH_RAY_CLIENT) {
                        thanhray.matnr = attributes.matnr
                        thanhray.name = attributes.value
                        thanhray.saleUnit = "MM"
                        thanhray.type = "O"
                    }
                    if (attributes.atnam == CharacteristicsItem.Z_KT_RAY0) {
                        KTRay = if (!TextUtils.isEmpty(attributes.value)) attributes.value?.toFloatOrNull()!! / 1000 else 0F
                    }
                    if (attributes.atnam == CharacteristicsItem.Z_THANH_RAY) {
                        SLgRay = if (!TextUtils.isEmpty(attributes.value)) attributes.value?.toFloatOrNull()!! else 0F
                        thanhray.quantity = KTRay * SLgRay
                    }
                }
                sendData?.data?.items?.get(0)?.value = item.value
                sendData?.data?.items?.get(0)?.type = item.type
                sendData?.data?.items?.get(0)?.matnr = item.matnr
                sendData?.data?.items?.get(0)?.saleUnit = item.saleUnit
                sendData?.data?.items?.get(0)?.quantity = item.quantity
                sendData?.data?.items?.get(0)?.width = item.width
                sendData?.data?.items?.get(0)?.height = item.height
                sendData?.data?.items?.get(0)?.characteristics?.clear()
                data.attributes?.values?.forEachIndexed { index, attributes ->
                    val characteristicsItem = CharacteristicsItem(atnam = attributes.atnam, smbez = attributes.smbez, value = attributes.value,
                            zType = attributes.zType, zGroup = attributes.zGroup, zSort = attributes.zSort)
                    item.characteristics?.add(characteristicsItem)
                }
                sendData?.data?.items?.get(0)?.characteristics = item.characteristics
                sendData?.data?.items?.add(1, ItemsItem(idItem = "2", idHeader = item.idHeader, type = botoi.type,
                        zReturn = item.zReturn, id_user = GlobalApp.getInstance().profile?.uid, matnr = botoi.matnr,
                        name = botoi.name, saleUnit = botoi.saleUnit, quantity = botoi.quantity, check = "bt"))
                sendData?.data?.items?.add(2, ItemsItem(idItem = "3", idHeader = item.idHeader, type = thanhray.type,
                        zReturn = item.zReturn, id_user = GlobalApp.getInstance().profile?.uid, matnr = thanhray.matnr,
                        name = thanhray.name, saleUnit = thanhray.saleUnit, quantity = thanhray.quantity, check = "tr"))
                Debug.e("--- botoi: ${botoi.matnr}\n--- thanhray: ${thanhray.matnr}")
                var state = -1
                if (!TextUtils.isEmpty(sendData?.data?.items?.get(0)?.matnr!!)) {
                    state = 0
                }
                if (!TextUtils.isEmpty(botoi.matnr)) {
                    state = 1
                }
                if (!TextUtils.isEmpty(thanhray.matnr)) {
                    state = 2
                }
                if (!TextUtils.isEmpty(botoi.matnr) && !TextUtils.isEmpty(thanhray.matnr)) {
                    state = 3
                }
                when (state) {
                    -1 -> {
//                        Debug.e("--- khong chon bat ky data nao")
//                        (activity as BaseActivity).onBackPressed()
//                        Debug.showAlert(activity, "Vui lòng chọn các thuộc tính sản phẩm")
                    }
                    0 -> {
                        Debug.e("--- khong chon botoi + thanh ray xong van co item khac")
                        var flag = false
                        sendData?.data?.items?.get(0)?.characteristics?.forEachIndexed { index, characteristicsItem ->
                            if (!TextUtils.isEmpty(characteristicsItem.value)) {
                                flag = true
                            }
                        }
                        if (flag) {
                            mappingMara(sendData?.data?.items?.get(0)?.matnr!!, sendData?.data?.items?.get(0)?.characteristics!!)
                        } else {
//                            (activity as BaseActivity).onBackPressed()
//                            Debug.showAlert(activity, "Vui lòng chọn các thuộc tính sản phẩm")
                        }
                    }
                    1 -> {
                        Debug.e("--- co chon botoi")
                        getCharacteristicItem(1, sendData?.data?.items?.get(1)?.matnr!!, state)
                    }
                    2 -> {
                        Debug.e("--- co chon thanh ray")
                        getCharacteristicItem(2, sendData?.data?.items?.get(2)?.matnr!!, state)
                    }
                    3 -> {
                        Debug.e("--- co chon botoi + thanh ray")
                        getCharacteristicItem(1, sendData?.data?.items?.get(1)?.matnr!!, state - 1)
                        getCharacteristicItem(2, sendData?.data?.items?.get(2)?.matnr!!, state - 1)
                    }
                }
                sendData?.data?.items = data.items?.filter { return@filter !TextUtils.isEmpty(it.matnr) && !it.matnr.equals("0") } as ArrayList<ItemsItem>?
            } else {
                Debug.e("--- Chua co data tu shareViewModel")
            }
        })
        btn_accept.setColorFilter(ContextCompat.getColor(requireActivity(), R.color.white))
        btn_back.setOnClickListener(this)
        btn_accept.setOnClickListener(this)
        btn_date_end.setOnClickListener(this)
        btn_add_product.setOnClickListener(this)
        getDetailCustomer(GlobalApp.getInstance().profile?.kunnr!!)
    }

    private fun initData() {
        cityAdapter = RouteAdapter(activity, ArrayList())
        spinner_city.setAdapter(cityAdapter)
        spinner_city.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val city = cityAdapter.mData?.get(position)!!
                districtAdapter.filterDistrict(city)
            }

        })
        districtAdapter = RouteAdapter(activity, ArrayList())
        spinner_district.setAdapter(districtAdapter)
        adapter = ProductAdapter(activity, ArrayList(), true)
        adapter.onItemClick = object : OnItemClickListenerRecyclerView {
            override fun onClick(view: View?, position: Int) {
                when (view?.id) {
                    R.id.btn_remove -> {
                        sendData?.data?.items?.removeAt(position)
                        adapter.removeItem(position)
                        getcheckPrice(sendData!!)
                    }
                    else -> {
                        if (position == 0 && haveAttributes) {
                            (activity as ConfirmOrderActivity).onBackPressed()
                        } else {
//                            characteristics = adapter.getItem(position)?.characteristics!!
                            val matnr = adapter.getItem(position)?.matnr!!
                            getCharacteristicItem(position, matnr, true)
                        }
                    }
                }
            }

            override fun onLongClick(view: View?, position: Int) {

            }
        }
        radio_type_address?.setOnCheckedChangeListener { group, checkedId ->
            when (checkedId) {
                R.id.radio_showroom -> {
                    group_address_showroom.visibility = View.VISIBLE
                    group_address_other.visibility = View.GONE
                }
                R.id.radio_other -> {
                    group_address_showroom.visibility = View.GONE
                    group_address_other.visibility = View.VISIBLE
                }
            }
        }
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(activity)
        recyclerView.setHasFixedSize(true)
    }

    private fun getCharacteristicItem(position: Int, matnr: String, iShowDialog: Boolean) {
        var characteristics = ArrayList<CharacteristicsItem>()
        (activity as BaseActivity).showProgressDialog()
        val characteristic = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getCharacteristic(matnr)
        val characteristicDefault = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getCharacteristicDefault(matnr)
        val subscribe = Observable.zip(characteristic, characteristicDefault, object : BiFunction<AttributesResponse, BaseResponse<ArrayList<CharacteristicsItem>>, ZipCharacteristicItem> {
            override fun apply(t1: AttributesResponse, t2: BaseResponse<ArrayList<CharacteristicsItem>>): ZipCharacteristicItem {
                return ZipCharacteristicItem(t1, t2)
            }

        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            (activity as BaseActivity).dismissProgressDialog()
            val buffer = sendData?.data?.items?.get(position)?.characteristics!!
            try {
                characteristics.forEachIndexed { indexItem, characteristicsItem ->
                    buffer.forEachIndexed { indexBuffer, characteristicsItemBuffer ->
                        if (!TextUtils.isEmpty(characteristicsItemBuffer.value) && characteristicsItem.atnam.equals(characteristicsItemBuffer.atnam)) {
                            characteristics.get(indexItem).value = characteristicsItemBuffer.value
                            characteristics.get(indexItem).ausp1 = characteristicsItemBuffer.ausp1
                        }
                    }
                }
                adapter.getItem(position)?.characteristics = characteristics
                sendData?.data?.items?.get(position)?.characteristics = characteristics
                val map = LinkedHashMap<String, HashMap<String, ArrayList<CharacteristicsItem>>>()
                adapter.getItem(position)?.characteristics?.groupBy { it.zGroup }?.entries?.map {
                    val child = HashMap<String, ArrayList<CharacteristicsItem>>()
                    child.put(CharacteristicsItem.getTitle(it.key!!), it.value as ArrayList<CharacteristicsItem>)
                    map.put(it.key!!, child)
                }
                if (iShowDialog) {
                    (activity as BaseActivity).shareViewModel?.setData(map)
                    val dialog = DetailDeliverOrderDialogFragment.newInstance(matnr, true)
                    dialog.callback = object : DetailDeliverOrderDialogFragment.IAction {
                        override fun callback(mData: ArrayList<CharacteristicsItem>?) {
                            mData?.forEachIndexed { index, characteristicsItem ->
                                val valueHave = sendData?.data?.items?.get(0)?.characteristics?.find { return@find it.atnam.equals(characteristicsItem.atnam) }
                                if (valueHave != null) {
                                    val index = sendData?.data?.items?.get(0)?.characteristics?.indexOf(valueHave)!!
                                    sendData?.data?.items?.get(0)?.characteristics?.get(index)?.value = characteristicsItem.value
                                    sendData?.data?.items?.get(0)?.characteristics?.get(index)?.ausp1 = characteristicsItem.ausp1
                                }
                            }
                            sendData?.data?.items?.get(position)?.characteristics = mData
                        }

                    }
                    dialog.show((activity as BaseActivity).supportFragmentManager, DetailDeliverOrderDialogFragment::class.java.simpleName)
                }
            } catch (e: Exception) {
                Debug.e("--- Error: ${e.message}")
            }
        }.subscribe({
            characteristics.clear()
            val dataCharacteristic = it.characteristic_t1?.data
            val dataCharacteristicDefault = it.characteristicDefault_t2?.data
            dataCharacteristic?.forEachIndexed { mPosition, attribute ->
                dataCharacteristicDefault?.forEachIndexed { nPosition, characteristicsItem ->
                    if (attribute.atnam == characteristicsItem.atnam && !TextUtils.isEmpty(characteristicsItem.zGroup) && characteristicsItem.zDefault?.equals("X", true)!!) {
                        when (attribute.atnam) {
                            CharacteristicsItem.Z_WIDTH -> {
                                try {
                                    //TODO
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = item.characteristics?.find { return@find it.atnam.equals(CharacteristicsItem.Z_WIDTH) }?.value
                                    Debug.e("--- value Z_WIDTH: ${value}")
                                    val valueDefault = attribute.value2 as ArrayList
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    characteristics.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                } catch (e: Exception) {
                                    Debug.e("--- Error: ${e.message}")
                                }
                            }
                            CharacteristicsItem.Z_HEIGHT -> {
                                try {
                                    //TODO
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = item.characteristics?.find { return@find it.atnam.equals(CharacteristicsItem.Z_HEIGHT) }?.value
                                    Debug.e("--- value Z_HEIGHT: ${value}")
                                    val valueDefault = ArrayList<Value2Item>()
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    characteristics.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                } catch (e: Exception) {
                                    Debug.e("--- Error: ${e.message}")
                                }
                            }
                            CharacteristicsItem.Z_MODEL_CUA, CharacteristicsItem.Z_LOAI_CUA -> {
                                val atnam = attribute.atnam
                                val smbez = attribute.smbez
                                val zgroup = characteristicsItem.zGroup
                                val value = item.characteristics?.find { return@find it.atnam.equals(CharacteristicsItem.Z_MODEL_CUA) || it.atnam.equals(CharacteristicsItem.Z_LOAI_CUA) }?.value
                                Debug.e("--- value Z_LOAI_CUA: ${value}")
                                val valueDefault = attribute.value2 as ArrayList
                                val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                characteristics.add(characteristicsItem)
                                characteristicsItem.trace()
                                return@forEachIndexed
                            }
                            CharacteristicsItem.Z_SO_LUONG -> {
                                val atnam = attribute.atnam
                                val smbez = attribute.smbez
                                val zgroup = characteristicsItem.zGroup
                                val value = "1"
                                Debug.e("--- value Z_SO_LUONG: ${value}")
                                val valueDefault = attribute.value2 as ArrayList
                                val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                characteristics.add(characteristicsItem)
                                characteristicsItem.trace()
                                return@forEachIndexed
                            }
                            CharacteristicsItem.Z_KT_THANH -> {
                                val atnam = attribute.atnam
                                val smbez = attribute.smbez
                                val zgroup = characteristicsItem.zGroup
                                val value = item.characteristics?.find { return@find it.atnam.equals(CharacteristicsItem.Z_KT_RAY0) }?.value
                                Debug.e("--- value Z_KT_THANH: ${value}")
                                val valueDefault = attribute.value2 as ArrayList
                                val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                characteristics.add(characteristicsItem)
                                characteristicsItem.trace()
                                return@forEachIndexed
                            }
                            CharacteristicsItem.Z_SO_THANH -> {
                                val atnam = attribute.atnam
                                val smbez = attribute.smbez
                                val zgroup = characteristicsItem.zGroup
                                val value = item.characteristics?.find { return@find it.atnam.equals(CharacteristicsItem.Z_THANH_RAY) }?.value
                                Debug.e("--- value Z_SO_THANH: ${value}")
                                val valueDefault = attribute.value2 as ArrayList
                                val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                characteristics.add(characteristicsItem)
                                characteristicsItem.trace()
                                return@forEachIndexed
                            }
                            CharacteristicsItem.Z_KO_DAU_TRUC -> {
                                val atnam = attribute.atnam
                                val smbez = attribute.smbez
                                val zgroup = characteristicsItem.zGroup
                                val value = item.characteristics?.find { return@find it.atnam.equals(CharacteristicsItem.Z_KO_DAU_TRUC) }?.value
                                Debug.e("--- value Z_KO_DAU_TRUC: ${value}")
                                val valueDefault = attribute.value2 as ArrayList
                                val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                characteristics.add(characteristicsItem)
                                characteristicsItem.trace()
                                return@forEachIndexed
                            }
                            else -> {
                                val atnam = attribute.atnam
                                val smbez = attribute.smbez
                                val zgroup = characteristicsItem.zGroup
                                var value = attribute.ausp1
                                if (!attribute.value2?.isEmpty()!!) {
                                    value = attribute.value2.filter { return@filter Utils.removeAccent(it.valdescr!!).equals(Utils.removeAccent(attribute.ausp1)) }.get(0).valdescr
                                }
                                val valueDefault = attribute.value2 as ArrayList
                                val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                characteristics.add(characteristicsItem)
                                return@forEachIndexed
                            }
                        }
                    }
                }
            }
        }, {
            Debug.e("--- Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    private fun getCharacteristicItem(position: Int, matnr: String, state: Int) {
        (activity as BaseActivity).showProgressDialog()
        val characteristic = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getCharacteristic(matnr)
        val characteristicDefault = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getCharacteristicDefault(matnr)
        val subscribe = Observable.zip(characteristic, characteristicDefault, object : BiFunction<AttributesResponse, BaseResponse<ArrayList<CharacteristicsItem>>, ZipCharacteristicItem> {
            override fun apply(t1: AttributesResponse, t2: BaseResponse<ArrayList<CharacteristicsItem>>): ZipCharacteristicItem {
                return ZipCharacteristicItem(t1, t2)
            }

        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            (activity as BaseActivity).dismissProgressDialog()
            if (position == state) {
                mappingMara(sendData?.data?.items?.get(0)?.matnr!!, sendData?.data?.items?.get(0)?.characteristics!!)
            }
        }.subscribe({
            val dataCharacteristic = it.characteristic_t1?.data
            val dataCharacteristicDefault = it.characteristicDefault_t2?.data
            dataCharacteristic?.forEachIndexed { i, attribute ->
                botoi.characteristics?.clear()
                thanhray.characteristics?.clear()
                dataCharacteristicDefault?.forEachIndexed { j, characteristicsItem ->
                    if (attribute.atnam == characteristicsItem.atnam && characteristicsItem.zDefault?.equals("X", true)!!) {
                        if (attribute.value2?.size!! > 0) {
                            when (attribute.atnam) {
                                CharacteristicsItem.Z_WIDTH -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = item.characteristics?.find { return@find it.atnam.equals(CharacteristicsItem.Z_WIDTH) }?.value
                                    Debug.e("--- value Z_WIDTH: ${value}")
                                    val valueDefault = attribute.value2 as ArrayList
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    botoi.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_HEIGHT -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = item.characteristics?.find { return@find it.atnam.equals(CharacteristicsItem.Z_HEIGHT) }?.value
                                    Debug.e("--- value Z_HEIGHT: ${value}")
                                    val valueDefault = attribute.value2 as ArrayList
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    botoi.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_LOAI_CUA -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = item.characteristics?.find { return@find it.atnam.equals(CharacteristicsItem.Z_LOAI_CUA) }?.value
                                    Debug.e("--- value Z_LOAI_CUA: ${value}")
                                    val valueDefault = attribute.value2 as ArrayList
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    botoi.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_SO_LUONG -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = "1"
                                    Debug.e("--- value Z_SO_LUONG: ${value}")
                                    val valueDefault = attribute.value2 as ArrayList
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    botoi.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_KT_THANH -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = item.characteristics?.find { return@find it.atnam.equals(CharacteristicsItem.Z_KT_RAY0) }?.value
                                    Debug.e("--- value Z_KT_THANH: ${value}")
                                    val valueDefault = attribute.value2 as ArrayList
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    thanhray.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_SO_THANH -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = item.characteristics?.find { return@find it.atnam.equals(CharacteristicsItem.Z_SO_THANH) }?.value
                                    Debug.e("--- value Z_SO_THANH: ${value}")
                                    val valueDefault = attribute.value2 as ArrayList
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    thanhray.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_KO_DAU_TRUC -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = item.characteristics?.find { return@find it.atnam.equals(CharacteristicsItem.Z_KO_DAU_TRUC) }?.value
                                    Debug.e("--- value Z_KO_DAU_TRUC: ${value}")
                                    val valueDefault = attribute.value2 as ArrayList
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    botoi.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                else -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = characteristicsItem.value
                                    Debug.e("--- value ${atnam}: ${value}")
                                    val valueDefault = attribute.value2 as ArrayList
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    when (position) {
                                        1 -> {
                                            botoi.characteristics?.add(characteristicsItem)
                                        }
                                        2 -> {
                                            thanhray.characteristics?.add(characteristicsItem)
                                        }
                                    }
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                            }
                        } else {
                            when (attribute.atnam) {
                                CharacteristicsItem.Z_WIDTH -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = item.characteristics?.find { return@find it.atnam.equals(CharacteristicsItem.Z_WIDTH) }?.value
                                    Debug.e("--- value Z_WIDTH: ${value}")
                                    val valueDefault = ArrayList<Value2Item>()
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    botoi.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_HEIGHT -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = item.characteristics?.find { return@find it.atnam.equals(CharacteristicsItem.Z_HEIGHT) }?.value
                                    Debug.e("--- value Z_HEIGHT: ${value}")
                                    val valueDefault = ArrayList<Value2Item>()
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    botoi.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_MODEL_CUA, CharacteristicsItem.Z_LOAI_CUA -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = item.characteristics?.find { return@find it.atnam.equals(CharacteristicsItem.Z_MODEL_CUA) || it.atnam.equals(CharacteristicsItem.Z_LOAI_CUA) }?.value
                                    Debug.e("--- value Z_LOAI_CUA: ${value}")
                                    val valueDefault = ArrayList<Value2Item>()
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    botoi.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_SO_LUONG -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = "1"
                                    Debug.e("--- value Z_SO_LUONG: ${value}")
                                    val valueDefault = ArrayList<Value2Item>()
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    botoi.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_KT_THANH -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = item.characteristics?.find { return@find it.atnam.equals(CharacteristicsItem.Z_KT_THANH) }?.value
                                    Debug.e("--- value Z_KT_THANH: ${value}")
                                    val valueDefault = ArrayList<Value2Item>()
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    thanhray.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_SO_THANH -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = item.characteristics?.find { return@find it.atnam.equals(CharacteristicsItem.Z_SO_THANH) }?.value
                                    Debug.e("--- value Z_SO_THANH: ${value}")
                                    val valueDefault = ArrayList<Value2Item>()
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    thanhray.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                CharacteristicsItem.Z_KO_DAU_TRUC -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = item.characteristics?.find { return@find it.atnam.equals(CharacteristicsItem.Z_KO_DAU_TRUC) }?.value
                                    Debug.e("--- value Z_KO_DAU_TRUC: ${value}")
                                    val valueDefault = attribute.value2 as ArrayList
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    botoi.characteristics?.add(characteristicsItem)
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                                else -> {
                                    val atnam = attribute.atnam
                                    val smbez = attribute.smbez
                                    val zgroup = characteristicsItem.zGroup
                                    val value = characteristicsItem.value
                                    Debug.e("--- value ${atnam}: ${value}")
                                    val valueDefault = ArrayList<Value2Item>()
                                    val characteristicsItem = CharacteristicsItem(atnam = atnam, smbez = smbez, zGroup = zgroup, value = value, data = valueDefault, ausp1 = attribute.ausp1)
                                    when (position) {
                                        1 -> {
                                            botoi.characteristics?.add(characteristicsItem)
                                        }
                                        2 -> {
                                            thanhray.characteristics?.add(characteristicsItem)
                                        }
                                    }
                                    characteristicsItem.trace()
                                    return@forEachIndexed
                                }
                            }
                        }
                    }
                }
            }
        }, {
            Debug.e("--- Error: ${it.message}")
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    var count = 0

    /**
     * Get time estimate send deliver to customer
     * And auto update get characteristics item BOTOI, THANHRAY
     */
    private fun getEstimate(detailProperties: DetailProperties) {
        val itMaras = ArrayList<Items>()
        detailProperties.items?.forEachIndexed { index, itemsItem ->
            itMaras.add(Items(matnr = itemsItem.matnr))
        }
        val body = ReasonRequest(idUser = detailProperties.idUser, division = detailProperties.division, itMaras = itMaras)
        (activity as BaseActivity).showProgressDialog()
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getEsitmateDelive(body)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            (activity as BaseActivity).dismissProgressDialog()
            if (count == 0) {
                if (!TextUtils.isEmpty(item.matnr))
                    adapter.add(item)
                if (!TextUtils.isEmpty(botoi.matnr)) {
                    adapter.add(botoi)
                    val indexBotoi = adapter.mData.indexOf(botoi)
                    getCharacteristicItem(indexBotoi, botoi.matnr!!, false)
                }
                if (!TextUtils.isEmpty(thanhray.matnr)) {
                    adapter.add(thanhray)
                    val indexThanhray = adapter.mData.indexOf(thanhray)
                    getCharacteristicItem(indexThanhray, thanhray.matnr!!, false)
                }
                count++
            }
        }.subscribe({ response ->
            itMaras.forEachIndexed { index, itemsClient ->
                response.data?.forEachIndexed { n, itemsResponse ->
                    itMaras.forEachIndexed { m, itemsClient ->
                        response.data.forEachIndexed { n, itemsResponse ->
                            if (itemsClient.matnr?.equals(itemsResponse.matnr)!!) {
                                try {
                                    when (n) {
                                        0 -> {
                                            item.name = response.data.get(m).name
                                            item.extwg = response.data.get(m).extwg
                                            sendData?.data?.items?.get(0)?.name = item.name
                                            item.zPrice = response.data.get(m).zPrice
                                            val dateStart = System.currentTimeMillis()
                                            tv_date_start.value = GlobalApp.getInstance().dateFormat4.format(Date(dateStart))
                                            sendData?.data?.zDateCreate = tv_date_start.value.toString()
                                            val calendar = Calendar.getInstance()
                                            calendar.timeInMillis = dateStart
                                            calendar.add(Calendar.DAY_OF_WEEK, response.data.get(m).zdkgh?.toIntOrNull()!!)
                                            tv_date_estimated.value = GlobalApp.getInstance().dateFormat2.format(calendar.time)
                                            tv_date_end.value = GlobalApp.getInstance().dateFormat2.format(calendar.time)
                                            return@forEachIndexed
                                        }
                                        1 -> {
                                            botoi.zPrice = response.data.get(m).zPrice
                                            return@forEachIndexed
                                        }
                                        2 -> {
                                            thanhray.zPrice = response.data.get(m).zPrice
                                            return@forEachIndexed
                                        }
                                    }
                                } catch (e: Exception) {
                                    Debug.e("--- Error: ${e.message}")
                                }
                            }
                        }
                    }
                }
            }
        }, {
            Debug.e("--- Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    fun createOrder(body: OrderRequest) {
        body.data.items?.forEachIndexed { i, itemsItem ->
            itemsItem.characteristics?.forEachIndexed { j, characteristicsItem ->
                body.data.items?.get(i)?.characteristics?.get(j)?.value = characteristicsItem.value?.replace(",", ".")
            }
        }
        Debug.e("--- body: ${body.data.items}")
//        if (BuildConfig.DEBUG)
//            return
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).createOrder(body)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
        }.subscribe({
            val idOrder = it.idOrder
            getDetailOrder(idOrder!!)
        }, {
            Debug.e("--- Error: ${it.message}")
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    fun getDetailOrder(idOrder: String) {
        val body = ReasonRequest(idOrder = idOrder)
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getDetailOrder(body)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
        }.subscribe({
            it.data?.trace()
            if (it.data?.status.equals("L", true)) {
                onChangeListOrderScreen()
            } else {
                checkApproveOrder(idOrder)
            }
        }, {
            Debug.e("--- Error: ${it.message}")
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    private fun onChangeListOrderScreen() {
        Debug.e("--- Sang m.hình danh sách đơn hàng")
        val intent = Intent(activity, SwitchMenuActivity::class.java)
        intent.putExtra(Menu::class.java.simpleName, Menu(description = "Danh sách đơn đặt hàng", action = arrayListOf(Action(functionmodule = TypeAction.GET_ORDER.value))))
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_CLEAR_TASK or
                Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        activity?.finish()
    }

    private fun checkApproveOrder(idOrder: String) {
        val body = ReasonRequest(idOrder = idOrder, idUser = GlobalApp.getInstance().profile?.uid!!, checkCredit = "X")
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).approveOrder(body)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
        }.subscribe({
            onChangeListOrderScreen()
        }, {
            Debug.e("--- Error: ${it.message}")
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    fun mappingMara(matnr: String, character: ArrayList<CharacteristicsItem>) {
        val reason = ReasonRequest(matnr = matnr, characteristics = character)
        reason.trace()
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).mappingMara(reason)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            (activity as BaseActivity).dismissProgressDialog()
        }.subscribe({ data ->
            if (!TextUtils.isEmpty(data.eMessage)) {
                val alertDialog: AlertDialog.Builder = AlertDialog.Builder(requireActivity())
                alertDialog.setMessage(data.eMessage)
                alertDialog.setNegativeButton("Chọn lại") { dialog: DialogInterface, which: Int ->
                    activity?.onBackPressed()
                }
                alertDialog.setPositiveButton("Xác nhận") { dialog: DialogInterface, which: Int ->
                }
                alertDialog.show()
            }
            onConfirmAction(data)
        }, {
            Debug.e("--- Error: ${it.message}")
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    private fun onConfirmAction(it: Value2Item) {
        if (it.eFlag.equals("0")) {
            //Trong tiêu chuẩn
            checkBox_instandard.isChecked = true
            checkBox_outstandard.isChecked = false
        } else {
            //Ngoài tiêu chuẩn
            checkBox_instandard.isChecked = false
            checkBox_outstandard.isChecked = true
        }

        sendData?.data?.items?.get(0)?.matnr = it.matnrRefer
        when (sendData?.data?.items?.size!!) {
            1 -> {
                sendData?.data?.items?.get(0)?.matnr = it.matnrRefer
            }
            2 -> {
                sendData?.data?.items?.get(1)?.characteristics = botoi.characteristics
            }
            3 -> {
                sendData?.data?.items?.get(1)?.characteristics = botoi.characteristics
                sendData?.data?.items?.get(2)?.characteristics = thanhray.characteristics
            }
        }
        getEstimate(sendData?.data!!)
        getcheckPrice(sendData!!)
    }

    fun getcheckPrice(body: OrderRequest) {
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).checkPrice(body)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
        }.subscribe({
            totalInquiry = it.totalInQuiry!!
            amount_to_guarantee = it.tgtdh!!
            tv_amount_to_guarantee.value = "${GlobalApp.getInstance().decimalFormat.format(amount_to_guarantee)} VNĐ"
            order_discount = it.ck!!
            tv_order_discount.value = "${GlobalApp.getInstance().decimalFormat.format(order_discount)} VNĐ"
            val total_order_discount = it.tgtdh - it.ck
            tv_total_order_discount.value = "${GlobalApp.getInstance().decimalFormat.format(total_order_discount)} VNĐ"
            tax = it.tax!!
            tv_tax.value = "${GlobalApp.getInstance().decimalFormat.format(tax)} VNĐ"
            total_after_pirce = total_order_discount + it.tax
            Debug.e("--- zprice: ${total_after_pirce}")
            tv_total_after_pirce.value = "${GlobalApp.getInstance().decimalFormat.format(total_after_pirce)} VNĐ"
        }, {
            Debug.e("--- Error: ${it.message}")
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    fun getDetailCustomer(kunnr: String) {
        (activity as BaseActivity).showProgressDialog()
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getDetailCustomers(kunnr)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            (activity as BaseActivity).dismissProgressDialog()
        }.subscribe({
            val detailCustomer = it.data!!
            detailCustomer.trace()
            nameShipTo = "${detailCustomer.uid} - ${detailCustomer.username} - ${detailCustomer.city}"
            tv_dealer_order.value = "${detailCustomer.uid} - ${detailCustomer.username}"
            tv_address.value = detailCustomer.address
            tv_phone.value = detailCustomer.phone
            tv_status.value = "Khởi tạo"
            it.data.zCredit?.forEachIndexed { index, czRedit ->
                if (czRedit.cs?.equals("CS${division}")!!) {
                    czRedit.trace()
                    tv_zCredit.value = "${GlobalApp.getInstance().decimalFormat.format(czRedit.value)} VNĐ"
                }
            }
            it.data.zCreditCustomer?.forEachIndexed { index, zcReditCUS ->
                if (zcReditCUS.cs?.equals("CS${division}")!!) {
                    zcReditCUS.trace()
                    tv_zcreditcus.value = "${GlobalApp.getInstance().decimalFormat.format(zcReditCUS.value)} VNĐ"
                }
            }
            getRouter(detailCustomer.route!!, detailCustomer.vSart!!)
        }, {
            Debug.e("--- Error: ${it.message}")
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    private fun getRouter(idRouter: String, vsart: String) {
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getRoute()
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
        }.subscribe({
            districtAdapter.addAll(it?.route!!)
            val mDataRoute = it.route.filter { return@filter idRouter.equals(it.route) }
            if (mDataRoute.size > 0) {
                tv_district.value = mDataRoute.get(0).bezei
                route = mDataRoute.get(0).route.toString()
            } else {
                Debug.e("--- Khong thay idRouter:${idRouter}")
            }
            val mDataVSart = it.t173t?.filter { return@filter vsart.equals(it.vSart) }
            cityAdapter.addAll(it.t173t!!)
            if (mDataVSart?.size!! > 0) {
                tv_city.value = mDataVSart.get(0).bezei
                vSart = mDataVSart.get(0).vSart.toString()
            } else {
                Debug.e("--- Khong thay vsart: ${vsart}")
            }
        }, {
            Debug.e("--- Error: ${it.message}")
//            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btn_back -> {
                activity?.onBackPressed()
            }
            R.id.btn_date_end -> {
                calendar.time = Date(System.currentTimeMillis())
                val datePickerDialog = DatePickerDialog.newInstance(object : DatePickerDialog.OnDateSetListener {
                    override fun onDateSet(view: DatePickerDialog, year: Int, monthOfYear: Int, dayOfMonth: Int) {
                        calendar.set(year, monthOfYear, dayOfMonth)
                        if (calendar.timeInMillis >= System.currentTimeMillis()) {
                            tv_date_end.value = GlobalApp.getInstance().dateFormat2.format(calendar.time)
                        } else {
                            Debug.showAlert(activity, "Hãy chọn lại ngày giao hàng")
                        }
                    }
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH))
                datePickerDialog.minDate = calendar
                datePickerDialog.show(activity?.supportFragmentManager!!, DatePickerDialog::class.java.simpleName)
            }
            R.id.btn_accept -> {
                val alertDialog: AlertDialog.Builder = AlertDialog.Builder(requireActivity())
                alertDialog.setMessage("Bạn muốn gửi đơn hàng?")
                alertDialog.setPositiveButton("Huỷ") { dialog: DialogInterface, which: Int ->
                }
                alertDialog.setNeutralButton("Gửi đơn hàng") { dialog: DialogInterface, which: Int ->
                    if (TextUtils.isEmpty(tv_date_end.value)) {
                        Debug.showAlert(activity, "Vui lòng xác nhận ngày yêu cầu giao hàng")
                        btn_date_end.performClick()
                        return@setNeutralButton
                    }
                    sendData?.data?.nameShipTo = nameShipTo
                    sendData?.data?.usernameReciver = edt_username_reciver.value
                    sendData?.data?.usernameCustomer = tv_username_customer.value
                    sendData?.data?.phoneEndUser = tv_phone_end_user.value
                    sendData?.data?.addressCustomer = edt_address_customer.value
                    sendData?.data?.status = "P"
                    sendData?.data?.zDate = tv_date_end.value
                    sendData?.data?.zPrice = total_after_pirce.toString()
                    sendData?.data?.totalPrice = amount_to_guarantee.toString()
                    sendData?.data?.ck = order_discount.toString()
                    sendData?.data?.tax = tax.toString()
                    sendData?.data?.totalInquiry = totalInquiry.toString()
                    when (radio_type_address.checkedRadioButtonId) {
                        R.id.radio_showroom -> {
                            sendData?.data?.address = tv_address.value
                            sendData?.data?.vsart = vSart
                            sendData?.data?.route = route
                        }
                        R.id.radio_other -> {
                            sendData?.data?.address = edt_address.value
                            val city: Route = spinner_city?.value as Route
                            sendData?.data?.vsart = city.vSart
                            val district: Route = spinner_district?.value as Route
                            sendData?.data?.route = district.route
                        }
                    }
                    sendData?.data?.ztc = if (radio_type.checkedRadioButtonId == R.id.checkBox_instandard) 0 else 1
                    sendData?.data?.trace()
                    if (TextUtils.isEmpty(sendData?.data?.address)) {
                        Debug.showAlert(activity, "Vui lòng chọn địa chỉ giao hàng")
                    } else {
                        createOrder(sendData!!)
                    }
                }
                alertDialog.show()
            }

            R.id.btn_add_product -> {
                var mType = "PK"
                if (adapter.mData.size > 0) {
                    mType = item.extwg!!
                }
                if (!TextUtils.isEmpty(GlobalApp.getInstance().zType)) {
                    mType = GlobalApp.getInstance().zType!!
                }
                val body = ReasonRequest(idUser = GlobalApp.getInstance().profile?.uid, ztype = mType)
                (activity as BaseActivity).showProgressDialog()
                val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getListProductProperties(body)
                val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
                    (activity as BaseActivity).dismissProgressDialog()
                }.subscribe({
                    it.data?.forEachIndexed { index, items ->
                        it.data.get(index).quantity = 1.0F
                    }
                    (activity as BaseActivity).shareViewModel?.setData(it.data)
                    val dialog = AddItemDialogFragment.newInstance()
                    dialog.callBack = object : IAction.Factory.ActionObject {
                        override fun callback(data: Any?) {
                            val mItem = data as Items
                            mItem.trace()
                            var mIndex = -1
                            var indexAdd = -1
                            adapter.mData.forEachIndexed { index, items ->
                                if (items.matnr.equals(mItem.matnr)) {
                                    mIndex = index
                                    return@forEachIndexed
                                }
                            }
                            if (mIndex == -1) {
                                sendData?.data?.items?.add(ItemsItem(idItem = "${adapter.itemCount}", idHeader = item.idHeader, type = item.type,
                                        zReturn = item.zReturn, id_user = GlobalApp.getInstance().profile?.uid, matnr = mItem.matnr,
                                        name = mItem.name, saleUnit = mItem.getUnit(), quantity = mItem.quantity))
                                adapter.add(mItem)
                                indexAdd = adapter.itemCount - 1
                            } else {
                                mItem.quantity = mItem.quantity
                                mItem.zPrice = mItem.zPrice!!
                                sendData?.data?.items?.set(mIndex, ItemsItem(idItem = "${adapter.itemCount}", idHeader = mItem.idHeader, type = mItem.type,
                                        zReturn = mItem.zReturn, id_user = GlobalApp.getInstance().profile?.uid, matnr = mItem.matnr,
                                        name = mItem.name, saleUnit = mItem.getUnit(), quantity = mItem.quantity))
                                adapter.updatePosition(mIndex, mItem)
                                indexAdd = mIndex
                            }
                            getCharacteristicItem(indexAdd, mItem.matnr!!, false)
                            getcheckPrice(sendData!!)
                            dialog.dismiss()
                        }

                    }
                    dialog.show((activity as ConfirmOrderActivity).supportFragmentManager, AddItemDialogFragment::class.java.simpleName)
                }, {
                    Debug.e("--- Error: ${it.message}")
                    Debug.showAlert(activity, "Error: ${it.message}")
                })
                compositeDisposable.add(subscribe)
            }
        }
    }
}