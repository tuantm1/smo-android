package com.smile.studio.sapportal.adapter

import android.content.Context
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.network.model.Value2Item

class AttributesAdapter(val mContext: Context?, private val mData: ArrayList<Value2Item>?, val isBoToiThanhRay: Boolean) : BaseAdapter() {

    var onItemClick: OnItemClickListenerRecyclerView? = null
    var mFilter: ArrayList<Value2Item>? = mData

    fun addAll(mData: ArrayList<Value2Item>) {
        this.mFilter?.add(0, Value2Item())
        this.mFilter?.addAll(mData)
        notifyDataSetChanged()
    }

    fun clear() {
        this.mFilter?.clear()
        notifyDataSetChanged()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var view: View? = convertView
        val holder: ViewHolder
        if (view == null) {
            view = LayoutInflater.from(mContext).inflate(R.layout.simple_spinner_item, parent, false)
            holder = ViewHolder(view)
            view?.tag = holder
        } else {
            holder = view.tag as ViewHolder
        }
        if (!isBoToiThanhRay) {
            holder.tv_name.text = mFilter?.get(position)?.value
        } else {
            holder.tv_name.text = if (!TextUtils.isEmpty(mFilter?.get(position)?.valdescr)) mFilter?.get(position)?.valdescr
            else if (!TextUtils.isEmpty(mFilter?.get(position)?.description)) mFilter?.get(position)?.description
            else if (!TextUtils.isEmpty(mFilter?.get(position)?.maktx)) mFilter?.get(position)?.maktx else mFilter?.get(position)?.value
        }
        holder.tv_name.isSelected = true
        return view!!
    }

    override fun getItem(position: Int): Value2Item {
        return mFilter?.get(position)!!
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getCount(): Int {
        return mFilter?.size!!
    }

    fun filterColor(compare: ArrayList<Value2Item>) {
        val bufferData = ArrayList<Value2Item>()
        compare.forEachIndexed { mIndex, value2ItemCompare ->
            if (!TextUtils.isEmpty(value2ItemCompare.matnrRefer)) {
                Debug.e("--- matnrRefer Model Cửa: ${value2ItemCompare.matnrRefer}")
                mData?.forEachIndexed { nIndex, value2Item ->
                    if (value2ItemCompare.matnrRefer?.equals(value2Item.matnrRefer)!!) {
                        Debug.e("--- matnrRefer màu sắc: ${value2Item.matnrRefer}")
                        bufferData.add(value2Item)
                    }
                }
            }
        }
        mFilter = bufferData
        mFilter?.add(0, Value2Item())
        notifyDataSetChanged()
    }

    fun filterBoToi(value: String, isBoToi: Boolean) {
        mFilter = ArrayList()
        if (!isBoToi)
            mFilter?.add(Value2Item())
        mFilter?.addAll(mData?.filter { return@filter it.value.equals(value) } as ArrayList<Value2Item>)
        Debug.e("--- size: ${mFilter?.size}")
        notifyDataSetChanged()
    }

    fun filterThanhRay(matnr: String, value: String, isThanhRay: Boolean) {
        mFilter = ArrayList()
        if (!isThanhRay)
            mFilter?.add(Value2Item())
        mFilter?.addAll(mData?.filter { return@filter it.matnr.equals(matnr) and it.value.equals(value) } as ArrayList<Value2Item>)
        Debug.e("--- size: ${mFilter?.size}")
        notifyDataSetChanged()
    }

    inner class ViewHolder(view: View) {
        val tv_name = view.findViewById<TextView>(android.R.id.text1)
    }

}