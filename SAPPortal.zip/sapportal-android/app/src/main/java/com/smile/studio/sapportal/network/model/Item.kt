package com.smile.studio.sapportal.network.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Item(

		@field:SerializedName("DVT")
        val dVT: String? = null,

		@field:SerializedName("SALE_ORDER")
        val saleOrder: String? = null,

		@field:SerializedName("MOTA_MH")
        val description: String? = null,

		@field:SerializedName("NHOM_HANG")
        val nHOMHANG: String? = null,

		@field:SerializedName("SO_BO")
        val sOBO: Double? = null,

		@field:SerializedName("SO_BO2")
		val sOBO2: Double? = null,

		@field:SerializedName("MOTA_NH")
        val mOTANH: String? = null,

		@field:SerializedName("LUONG")
        val lUONG: Double? = null,

		@field:SerializedName("KT")
        val kT: String? = null,

		@field:SerializedName("RAY")
        val rAY: String? = null,

		@field:SerializedName("ZZ_BUZEI")
        val item: String? = null,

		@field:SerializedName("KHUNG")
        val kHUNG: String? = null,

		@field:SerializedName("LOAITIEN")
        val typeMoney: String? = null,

		@field:SerializedName("TL")
        val tL: String? = null,

		@field:SerializedName("ZZ_BELNR_PVC")
        val idItem: String? = null,

		@field:SerializedName("CHIEU_RONG")
		val width: Double? = null,

		@field:SerializedName("CHIEU_CAO")
        val height: Double? = null,

		@field:SerializedName("DIEN_TICH")
		val acreage: Double? = null,

		@field:SerializedName("THE_TICH")
		val capacity: Double? = null,

		@field:SerializedName("LOAI_CUA")
        val lOAICUA: String? = null,

		@field:SerializedName("TRUC_KT")
        val tRUCKT: String? = null,

		@field:SerializedName("MATHANG")
        val mATHANG: String? = null,

		@field:SerializedName("MATNR")
        val matnr: String? = null

) : Parcelable
