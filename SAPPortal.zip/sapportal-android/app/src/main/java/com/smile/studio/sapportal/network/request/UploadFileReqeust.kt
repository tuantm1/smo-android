package com.smile.studio.sapportal.network.request

import com.google.gson.annotations.SerializedName

data class UploadFileReqeust(

	@field:SerializedName("id_order")
	val idOrder: String? = null,

	@field:SerializedName("xstring")
	val xstring: String? = null
)
