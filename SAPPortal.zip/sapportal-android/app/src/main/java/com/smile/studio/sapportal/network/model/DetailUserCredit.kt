package com.smile.studio.sapportal.network.model

import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug
import java.math.BigDecimal

class DetailUserCredit(
        @SerializedName("GRADE")
        val grade: String? = null,
        @SerializedName("HMCL")
        val underwriting_limits: BigDecimal? = null,
        @SerializedName("PARENTS")
        val parents: ArrayList<User>? = null,
        @SerializedName("USER")
        val user: User

) {
    fun trace() {
        Debug.e("HMCL: ${underwriting_limits}")
    }
}