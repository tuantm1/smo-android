package com.smile.studio.sapportal.adapter

import android.content.Context
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Filter
import android.widget.Filterable
import android.widget.TextView
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.network.model.SampleOrder

class SampleOrderAdapter(val mContext: Context?, val mData: ArrayList<SampleOrder>?) : BaseAdapter(), Filterable {

    var onItemClick: OnItemClickListenerRecyclerView? = null
    var mDataFilter = mData

    fun addAll(mData: ArrayList<SampleOrder>) {
        this.mData?.addAll(mData)
        notifyDataSetChanged()
    }

    fun clear() {
        this.mData?.clear()
        this.mDataFilter?.clear()
        notifyDataSetChanged()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var view: View? = convertView
        val holder: ViewHolder
        if (view == null) {
            view = LayoutInflater.from(mContext).inflate(R.layout.simple_spinner_item, parent, false)
            holder = ViewHolder(view)
            view?.tag = holder
        } else {
            holder = view.tag as ViewHolder
        }
        holder.init(mDataFilter?.get(position))
        return view!!
    }

    override fun getItem(position: Int): SampleOrder {
        return mDataFilter?.get(position)!!
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getCount(): Int {
        return mDataFilter?.size!!
    }

    inner class ViewHolder(view: View) {

        val tv_name = view.findViewById<TextView>(android.R.id.text1)

        fun init(item: SampleOrder?) {
            tv_name.text = item?.name
            tv_name.isSelected = true
        }
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                var mFilter = ArrayList<SampleOrder>()
                mFilter.clear()
                if (TextUtils.isEmpty(constraint)) {
                    mFilter = mData!!
                } else {
                    val keyword = constraint.toString().trim()
                    val regex = Regex(keyword)
                    mFilter.addAll(mData?.filter { return@filter it.ordertype?.matches(regex)!! } as ArrayList<SampleOrder>)
                }
                val filterResults = FilterResults()
                filterResults.values = mFilter
                return filterResults
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                mDataFilter = results?.values as ArrayList<SampleOrder>?
                mDataFilter?.add(0, SampleOrder())
                notifyDataSetChanged()
            }

        }
    }

}