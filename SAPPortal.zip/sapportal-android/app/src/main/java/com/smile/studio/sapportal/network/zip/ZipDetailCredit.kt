package com.smile.studio.sapportal.network.zip

import com.google.gson.annotations.SerializedName
import com.smile.studio.sapportal.network.model.*
import com.smile.studio.sapportal.network.response.BaseResponse
import com.smile.studio.sapportal.network.response.DetailProfileResponse
import io.reactivex.Observable

class ZipDetailCredit(

        @SerializedName("Deliver")
        val deliver_t1: BaseResponse<Deliver>? = null,

        @SerializedName("DetailUserCredit")
        val detailUserCredit_t2: DetailUserCredit? = null,

        @SerializedName("DetailDivision")
        val detailDivision_t3: DetailDivision? = null,

        @SerializedName("DetailProfileResponse")
        val detailUser_t4 : DetailProfileResponse? = null
) {

}