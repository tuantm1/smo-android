package com.smile.studio.sapportal.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.activity.BaseActivity
import com.smile.studio.sapportal.network.model.Customer
import kotlinx.android.synthetic.main.fragment_detail_customer.*

class CustomerDetailFragment : BaseFragment() {

    companion object {
        fun newInstance(): CustomerDetailFragment {
            val fragment = CustomerDetailFragment()
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_detail_customer, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        (activity as BaseActivity).shareViewModel?.getData()?.observe(viewLifecycleOwner, Observer<Any?> { customer ->
            if (customer is Customer) {
                tv_customer_id.text = "${customer.uid?.trim()}"
                tv_customer_name.text = "${customer.username?.trim()}"
                tv_customer_tax.text = "${customer.tax?.trim()}"
                tv_customer_tel_phone.text = "${customer.telphone?.trim()}"
                tv_customer_mobile_phone.text = "${customer.phone?.trim()}"
                tv_customer_email.text = "${customer.email?.trim()}"
                tv_customer_fax.text = "${customer.faxNumber?.trim()}"
                tv_customer_address.text = "${customer.address?.trim()}"
            }
        })

    }
}