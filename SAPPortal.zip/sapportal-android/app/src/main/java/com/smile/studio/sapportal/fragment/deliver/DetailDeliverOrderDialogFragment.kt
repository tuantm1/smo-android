package com.smile.studio.sapportal.fragment.deliver

import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.lifecycle.Observer
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.libsmilestudio.utils.Utils
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.activity.BaseActivity
import com.smile.studio.sapportal.adapter.AttributesAdapter
import com.smile.studio.sapportal.network.model.CharacteristicsItem
import com.smile.studio.sapportal.view.TextEditText
import com.smile.studio.sapportal.view.TextLabel
import com.smile.studio.sapportal.view.TextSpinner
import kotlinx.android.synthetic.main.dialog_fragment_detail_deliver_order.*
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.LinkedHashMap

class DetailDeliverOrderDialogFragment() : BottomSheetDialogFragment() {

    var atnam: String = ""
    var isCreate: Boolean = false
    var callback: IAction? = null
    var indexItem = 0
    var dataSubmit = LinkedHashMap<Int, CharacteristicsItem>()

    interface IAction {
        fun callback(mData: ArrayList<CharacteristicsItem>?)
    }

    constructor(atnam: String, isCreate: Boolean) : this() {
        this.atnam = atnam
        this.isCreate = isCreate
    }

    companion object {

        fun newInstance(): DetailDeliverOrderDialogFragment {
            val fragment = DetailDeliverOrderDialogFragment()
            return fragment
        }

        fun newInstance(atnam: String, isCreate: Boolean): DetailDeliverOrderDialogFragment {
            val fragment = DetailDeliverOrderDialogFragment(atnam, isCreate)
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.dialog_fragment_detail_deliver_order, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        (activity as BaseActivity).shareViewModel?.getData()?.observe(viewLifecycleOwner, Observer<Any?> { data ->
            val map = data as LinkedHashMap<String, HashMap<String, ArrayList<CharacteristicsItem>>>
            map.forEach { key, valueRoot ->
                valueRoot.forEach { titleGroups, dataGroups ->
                    if (!dataGroups.isEmpty()) {
                        if (isCreate) {
                            initCreateOrder(titleGroups, dataGroups)
                        } else {
                            initDetailOrder(titleGroups, dataGroups)
                        }
                    }
                }
            }

        })
    }

    override fun onDestroy() {
        super.onDestroy()
        if (callback != null && isCreate) {
            callback?.let {
                val mData = ArrayList<CharacteristicsItem>()
                dataSubmit.values.forEachIndexed { index, characteristicsItem ->
                    mData.add(characteristicsItem)
                }
                callback?.callback(mData)
            }
        }
    }

    private fun initCreateOrder(titleGroups: String, dataGroups: ArrayList<CharacteristicsItem>) {
        val viewGroup = LayoutInflater.from(activity).inflate(R.layout.custom_item_group_detail_order, null)
        val groupsProperties = viewGroup.findViewById<LinearLayout>(R.id.groupsProperties)
        val tv_title = viewGroup.findViewById<TextView>(R.id.tv_title)
        tv_title.text = titleGroups
        stickyScrollView.addView(viewGroup)
        dataGroups.forEachIndexed { index, characteristicsItem ->
            val ausp1 = dataGroups.get(index).ausp1!!
            if (characteristicsItem.data != null && !characteristicsItem.data?.isEmpty()!!) {
                val textSpinner = TextSpinner(activity)
                textSpinner.tag = characteristicsItem.atnam
                textSpinner.setLabel(characteristicsItem.smbez)
                val adapter = AttributesAdapter(activity, characteristicsItem.data, true)
                textSpinner.setAdapter(adapter)
                textSpinner.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                        val mData = adapter.getItem(position)
                        characteristicsItem.value = mData.value
                        characteristicsItem.ausp1 = mData.value
                        dataSubmit.put(textSpinner.id, characteristicsItem)
                    }

                    override fun onNothingSelected(parent: AdapterView<*>?) {

                    }

                })
                var position = 0
                adapter.mFilter?.forEachIndexed { index, value2Item ->
                    if (value2Item.value.equals(ausp1) || Utils.removeAccent(value2Item.valdescr).equals(Utils.removeAccent(ausp1))) {
                        position = index
                    }
                }
                textSpinner.setSelection(position, true)
                textSpinner.id = indexItem
                indexItem += 1
                groupsProperties.addView(textSpinner)
            } else {
                val textEditText = TextEditText(activity)
                val tag = characteristicsItem.atnam
                textEditText.id = indexItem
                textEditText.tag = tag
                if (tag.equals(CharacteristicsItem.Z_DIEN_TICH)) {
                    textEditText.setLabel("${characteristicsItem.smbez} (m2)")
                    textEditText.value = characteristicsItem.value
                } else if (tag.equals(CharacteristicsItem.Z_HEIGHT) || tag.equals(CharacteristicsItem.Z_WIDTH) || tag.equals(CharacteristicsItem.Z_H_THOANG)) {
                    textEditText.setLabel("${characteristicsItem.smbez} (mm)")
                    textEditText.value = characteristicsItem.value
                } else if (tag.equals(CharacteristicsItem.Z_KT_RAY)) {
                    textEditText.setLabel(characteristicsItem.smbez)
                    try {
                        //TODO
                        val zKTThanh = groupsProperties.findViewWithTag<TextEditText>(CharacteristicsItem.Z_KT_THANH)?.value!!
                        val zSoThanh = groupsProperties.findViewWithTag<TextEditText>(CharacteristicsItem.Z_SO_THANH)?.value!!
                        textEditText.value = (zKTThanh.toInt().div(1000) * zSoThanh.toInt()).toString()
                    } catch (e: Exception) {
                        Debug.e("--- Error: ${e.message}")
                    }
                } else {
                    textEditText.setLabel(characteristicsItem.smbez?.replace("Model", "Loại"))
                    textEditText.value = characteristicsItem.value
                }
                textEditText.setInputType(InputType.TYPE_CLASS_NUMBER)
                textEditText.setImeOptions(EditorInfo.IME_ACTION_NEXT)
                dataSubmit.put(textEditText.id, characteristicsItem)
                textEditText.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

                    }

                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                        characteristicsItem.value = textEditText.value.toString().trim()
                        dataSubmit.put(textEditText.id, characteristicsItem)
                    }

                    override fun afterTextChanged(s: Editable?) {
                    }
                })
                indexItem += 1
                groupsProperties.addView(textEditText)
            }
        }
    }

    private fun initDetailOrder(titleGroups: String, dataGroups: ArrayList<CharacteristicsItem>) {
        val viewGroup = LayoutInflater.from(activity).inflate(R.layout.custom_item_group_detail_order, null)
        val groupsProperties = viewGroup.findViewById<LinearLayout>(R.id.groupsProperties)
        val tv_title = viewGroup.findViewById<TextView>(R.id.tv_title)
        tv_title.text = titleGroups
        stickyScrollView.addView(viewGroup)
        dataGroups.forEachIndexed { index, characteristicsItem ->
            when (characteristicsItem.atnam) {
                CharacteristicsItem.Z_MODEL_CUA, CharacteristicsItem.Z_LOAI_CUA -> {
                    val textLabel = TextLabel(activity)
                    val tag = characteristicsItem.atnam
                    textLabel.tag = tag
                    textLabel.setLabel(characteristicsItem.smbez?.replace("Model", "Loại"))
                    textLabel.value = characteristicsItem.value
                    groupsProperties.addView(textLabel)
                }
                else -> {
                    if (characteristicsItem.data != null && !characteristicsItem.data?.isEmpty()!!) {
                        val textLabel = TextLabel(activity)
                        val tag = characteristicsItem.atnam
                        textLabel.tag = tag
                        Debug.e("--- tag: ${tag}: name: ${characteristicsItem.smbez}")
                        textLabel.setLabel(characteristicsItem.smbez)
                        val ausp1 = characteristicsItem.ausp1
                        characteristicsItem.data?.forEachIndexed { index, value2Item ->
                            if (value2Item.value.equals(ausp1)) {
                                textLabel.value = value2Item.value
                            } else if (Utils.removeAccent(value2Item.valdescr).equals(Utils.removeAccent(ausp1))) {
                                textLabel.value = value2Item.valdescr
                            }
                        }
                        groupsProperties.addView(textLabel)
                    } else {
                        val textLabel = TextLabel(activity)
                        val tag = characteristicsItem.atnam
                        Debug.e("--- tag: ${tag}: name: ${characteristicsItem.smbez}")
                        textLabel.tag = tag
                        if (tag.equals(CharacteristicsItem.Z_KT_RAY)) {
                            textLabel.setLabel(characteristicsItem.smbez)
                            try {
                                //TODO
                                val zKTThanh = groupsProperties.findViewWithTag<TextLabel>(CharacteristicsItem.Z_KT_THANH)?.value!!
                                val zSoThanh = groupsProperties.findViewWithTag<TextLabel>(CharacteristicsItem.Z_SO_THANH)?.value!!
                                textLabel.value = (zKTThanh.toInt().div(1000) * zSoThanh.toInt()).toString()
                            } catch (e : Exception){
                                Debug.e("--- Error: ${e.message}")
                            }
                        } else if (tag.equals(CharacteristicsItem.Z_DIEN_TICH)) {
                            textLabel.setLabel("${characteristicsItem.smbez} (m2)")
                            textLabel.value = characteristicsItem.value
                        } else if (tag.equals(CharacteristicsItem.Z_HEIGHT) || tag.equals(CharacteristicsItem.Z_WIDTH) || tag.equals(CharacteristicsItem.Z_H_THOANG)) {
                            textLabel.setLabel("${characteristicsItem.smbez} (mm)")
                            textLabel.value = characteristicsItem.value
                        } else {
                            textLabel.setLabel(characteristicsItem.smbez?.replace("Model", "Loại"))
                            textLabel.value = characteristicsItem.value
                        }
                        groupsProperties.addView(textLabel)
                    }
                }
            }
        }
    }
}