package com.smile.studio.sapportal.network.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Product(

	@field:SerializedName("MAKTX")
	val mAKTX: String? = null,

	@field:SerializedName("MAKTG")
	val mAKTG: String? = null,

	@field:SerializedName("ZPRICE_AF_TAX")
	val zPRICEAFTAX: Double? = null,

	@field:SerializedName("MATKL")
	val mATKL: String? = null,

	@field:SerializedName("MEINS")
	val mEINS: String? = null,

	@field:SerializedName("LABOR")
	val lABOR: String? = null,

	@field:SerializedName("ZPRICE")
	val zPRICE: Double? = null,

	@field:SerializedName("MATNR", alternate = arrayOf("NAME"))
	val name: String? = null
) : Parcelable {
    fun trace() {
        Debug.e("")
    }
}
