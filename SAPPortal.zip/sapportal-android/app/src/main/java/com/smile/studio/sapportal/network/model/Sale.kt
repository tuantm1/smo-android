package com.smile.studio.sapportal.network.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Sale(

        @field:SerializedName("SPART")
        val spart: String? = null,

        @field:SerializedName("SPRAS")
        val spras: String? = null,

        @field:SerializedName("VKORG")
        val vkorg: String? = null,

        @field:SerializedName("VTWEG")
        val vtweg: String? = null,

        @field:SerializedName("VTEXT")
        val vtext: String? = null,

        @field:SerializedName("MANDT")
        val mandt: String? = null
) : Parcelable {

    fun trace() {
        Debug.e("MANDT: ${mandt}\nSPRAS: ${spras}\nVKORG: ${vkorg}\nVTEXT: ${vtext}")
    }
}
