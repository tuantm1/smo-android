package com.smile.studio.sapportal.network.zip

import com.google.gson.annotations.SerializedName
import com.smile.studio.sapportal.network.model.Sale
import com.smile.studio.sapportal.network.model.SampleOrder
import com.smile.studio.sapportal.network.response.BaseResponse

class ZipInfoSale(
        @SerializedName("GT_SALEORG")
        val salesUnit: BaseResponse<ArrayList<Sale>>? = null,
        @SerializedName("GT_DC")
        val salesChannel: BaseResponse<ArrayList<Sale>>? = null,
        @SerializedName("GT_DIVISION")
        val industryInformation: BaseResponse<ArrayList<Sale>>? = null,
        @SerializedName("RES")
        val sampleOrder: BaseResponse<ArrayList<SampleOrder>>? = null
)