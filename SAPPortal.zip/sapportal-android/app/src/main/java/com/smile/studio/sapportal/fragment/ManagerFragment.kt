package com.smile.studio.sapportal.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.smile.studio.libsmilestudio.fragment.TabFragmentAdapter
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.model.TypeMenu
import com.smile.studio.sapportal.network.response.Menu
import kotlinx.android.synthetic.main.fragment_manager.*

class ManagerFragment : BaseFragment() {

    var adapter: TabFragmentAdapter? = null
    var mapFragments = LinkedHashMap<String, Fragment>()
    val maxItem = 6

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_manager, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val mData = GlobalApp.getInstance().mDataMenu.filter { it.zzstatus?.equals(TypeMenu.MENU_HOME.value.toString())!! } as ArrayList<Menu>
        val totalPage = mData.size / maxItem
        var numberTab = 0
        val buff = ArrayList<Menu>()
        mData.forEachIndexed { index, menu ->
            menu.color = GlobalApp.getInstance().colors.get(index % 10)
            buff.add(menu)
            if ((index + 1) % maxItem == 0 || index == mData.size - 1) {
                mapFragments.put("${ChildMenuHomeFragment::class.java.simpleName}_${index + 1}", ChildMenuHomeFragment.newInstance(buff.clone() as ArrayList<Menu>))
                numberTab += 1
                buff.clear()
            }
        }
        adapter = TabFragmentAdapter(context, childFragmentManager, mapFragments, false, viewPager)
        viewPager.adapter = adapter
        viewPager.offscreenPageLimit = totalPage
        dotsIndicator.setViewPager(viewPager)
        thumb_empty.setColorFilter(ContextCompat.getColor(requireActivity(), R.color.gray))
        if (mData.size > 0) {
            message_group.visibility = View.GONE
            groups_content.visibility = View.VISIBLE
        } else {
            message_group.visibility = View.VISIBLE
            groups_content.visibility = View.GONE
        }
    }
}