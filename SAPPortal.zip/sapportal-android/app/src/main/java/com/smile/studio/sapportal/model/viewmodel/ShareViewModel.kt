package com.smile.studio.sapportal.model.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

/**
 * Created by longq on 25/01/2018.
 */
open class ShareViewModel<T> : ViewModel() {

    private val data = MutableLiveData<Any?>()

    fun setData(item: Any?) {
        data.setValue(item)
    }

    fun getData(): LiveData<Any?> {
        return data
    }

}