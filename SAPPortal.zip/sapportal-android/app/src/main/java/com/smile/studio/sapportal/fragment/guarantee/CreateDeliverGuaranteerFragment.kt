package com.smile.studio.sapportal.fragment.guarantee

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.activity.BaseActivity
import com.smile.studio.sapportal.adapter.ProductAdapter
import com.smile.studio.sapportal.adapter.UserAdapter
import com.smile.studio.sapportal.fragment.BaseFragment
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.face.SAPPortal
import com.smile.studio.sapportal.network.model.API
import com.smile.studio.sapportal.network.model.Deliver
import com.smile.studio.sapportal.network.model.TypeError
import com.smile.studio.sapportal.network.model.User
import com.smile.studio.sapportal.network.request.CreditRequest
import com.smile.studio.sapportal.network.request.ReasonRequest
import com.smile.studio.sapportal.network.request.TheCredit
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_created_deliver_guarantee.*
import java.math.BigDecimal
import java.util.*
import kotlin.collections.ArrayList

class CreateDeliverGuaranteerFragment : BaseFragment() {

    var division: String? = null
    var deliver: Deliver? = null
    var userAdapter: UserAdapter? = null
    var adapter: ProductAdapter? = null
    var layoutManager: LinearLayoutManager? = null
    var zDate: String? = null
    lateinit var zPrice: BigDecimal
    lateinit var stbl: BigDecimal
    var user : User? = null
    var creditRequest = CreditRequest()

    companion object {
        fun newInstance(): CreateDeliverGuaranteerFragment {
            val fragment = CreateDeliverGuaranteerFragment()
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_created_deliver_guarantee, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        creditRequest.theCredit = TheCredit()
        layoutManager = LinearLayoutManager(requireActivity())
        recyclerView.layoutManager = layoutManager
        adapter = ProductAdapter(activity, ArrayList(), false)
        recyclerView.adapter = adapter
        userAdapter = UserAdapter(activity, ArrayList())
        spinner_user_guaranntee.adapter = userAdapter
        spinner_user_guaranntee.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                user = spinner_user_guaranntee.adapter?.getItem(position) as User
                creditRequest.theCredit?.idApprove = user?.uid
                Debug.e("--- Info User selected")
                val body = ReasonRequest(idUser = user?.uid, idOrder = deliver?.idOrder)
                getDetailUserBL(body, true)
            }

        }
        spinner_expire_date.adapter = ArrayAdapter<String>(requireActivity(), android.R.layout.simple_spinner_item, arrayOf("01", "02", "03", "04", "05", "06", "07", "08", "09", "10"))
        spinner_expire_date.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val expire = spinner_expire_date.adapter?.getItem(position) as String
                creditRequest.theCredit?.zday = expire
                Debug.e("--- expire: ${expire}")
                val calendar = Calendar.getInstance()
                calendar.time = Date(System.currentTimeMillis())
                calendar.add(Calendar.DATE, expire.toInt())
                val date = GlobalApp.getInstance().dateFormat2.format(calendar.time)
                tv_date_delivery.value = date
                zDate = date
                creditRequest.theCredit?.zdate = tv_date.value.toString()
            }

        }
        (activity as BaseActivity).shareViewModel?.getData()?.observe(viewLifecycleOwner, Observer<Any?> { data ->
            if (data is Deliver) {
                deliver = data
                creditRequest.theCredit?.idOrder = deliver?.idOrder
                creditRequest.theCredit?.idRequest = GlobalApp.getInstance().profile?.uid
                division = deliver?.division
                Debug.e("--- Có thông tin đơn hàng cần bảo lãnh")
                adapter?.addAll(data.items!!)
                val dateCreate = GlobalApp.getInstance().dateFormat2.format(Date(System.currentTimeMillis()))
                tv_date.value = dateCreate
                tv_agency.value = data.nameShipTo
                tv_number_deliver.value = data.idOrder
                tv_total_pirce.value = "${GlobalApp.getInstance().decimalFormat.format(data.totalPrice)} VNĐ"
                val status = when (data.status) {
                    TypeError.SUCCESS.value -> {
                        "Đặt thành công"
                    }
                    TypeError.CREDIT_LIMIT_EXCEEDED.value -> {
                        "Vượt hạn mức tính dụng"
                    }
                    TypeError.REJECTED.value -> {
                        "Đã huỷ"
                    }
                    else -> {
                        "Chờ bảo lãnh"
                    }
                }
                tv_status.value = status
                tv_total_pirce.value = "${GlobalApp.getInstance().decimalFormat.format(deliver?.zPrice)} VNĐ"
                creditRequest.theCredit?.zprice = deliver?.zPrice?.toString()
                tv_amount_to_guarantee.value = "${GlobalApp.getInstance().decimalFormat.format(deliver?.stdbl)} VNĐ"
                tv_amount_to_guarantee1.value = "${GlobalApp.getInstance().decimalFormat.format(deliver?.totalInquiry)} VNĐ"
                tv_amount_to_guarantee2.value = "${GlobalApp.getInstance().decimalFormat.format(deliver?.guaranteeAmount)} VNĐ"
                creditRequest.theCredit?.stbl = deliver?.guaranteeAmount?.toString()
                val body = ReasonRequest(idUser = GlobalApp.getInstance().profile?.uid, idOrder = data.idOrder)
                getDetailUserBL(body, false)
                getDetailUser()
            }
        })
    }

    fun getDetailUser() {
        val body = ReasonRequest(idUser = deliver?.idUser)
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getDetailUser(body)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
        }.subscribe({
            val kunnr = it.user?.kunnr
            getDetailCustomer(kunnr)
        }, {
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    private fun getDetailCustomer(kunnr: String?) {
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getDetailCustomers(kunnr!!)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
        }.subscribe({
            it.data?.zCredit?.forEachIndexed { index, czRedit ->
                if (czRedit.cs?.equals("CS${division}")!!) {
                    czRedit.trace()
                    tv_zCredit.value = "${GlobalApp.getInstance().decimalFormat.format(czRedit.value)} VNĐ"
                }
            }
            it.data?.zCreditCustomer?.forEachIndexed { index, zCreditCustomer ->
                if (zCreditCustomer.cs?.equals("CS${division}")!!) {
                    zCreditCustomer.trace()
                    tv_zcreditcus.value = "${GlobalApp.getInstance().decimalFormat.format(zCreditCustomer.value)} VNĐ"
                }
            }
        }, {
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    fun getDetailUserBL(body: ReasonRequest, isSelected: Boolean) {
        (activity as BaseActivity).showProgressDialog()
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getUserCredit(body)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            (activity as BaseActivity).dismissProgressDialog()
        }.subscribe({
            if (!isSelected) {
                tv_sale?.value = it?.user?.description
//                val zDay = spinner_expire_date.selectedItem as String
//                creditRequest.theCredit = TheCredit(idOrder = deliver?.idOrder, idRequest = GlobalApp.getInstance().profile?.uid, idApprove = user?.uid, zdate = tv_date.value.toString(),
//                        zprice = tv_total_pirce.valueMoney, stbl = tv_amount_to_guarantee2.valueMoney, zday = zDay)
            }
            userAdapter?.clear()
            userAdapter?.addAll(it?.parents!!)
            tv_underwriting_limits?.value = "${GlobalApp.getInstance().decimalFormat.format(it?.underwriting_limits)} VNĐ"
        }, {
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }
}
