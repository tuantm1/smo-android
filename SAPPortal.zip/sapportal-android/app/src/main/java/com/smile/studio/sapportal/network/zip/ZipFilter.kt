package com.smile.studio.sapportal.network.zip

import com.google.gson.annotations.SerializedName
import com.smile.studio.sapportal.network.model.Value2Item
import com.smile.studio.sapportal.network.response.BaseResponse

class ZipFilter(
        @SerializedName("GT_DATA")
        val dataFilter: BaseResponse<ArrayList<Value2Item>>,
        @SerializedName("GT_BOTOI")
        val dataBoToi: BaseResponse<ArrayList<Value2Item>>,
        @SerializedName("GT_THANHRAY")
        val dataThanhRay: BaseResponse<ArrayList<Value2Item>>
)