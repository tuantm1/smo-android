package com.smile.studio.sapportal.network.response

import com.google.gson.annotations.SerializedName

class PDFResponse(
        @SerializedName("ZRAWDATA")
        val data: String? = null
)