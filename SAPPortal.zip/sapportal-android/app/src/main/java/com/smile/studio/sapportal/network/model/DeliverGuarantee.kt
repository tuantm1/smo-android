package com.smile.studio.sapportal.network.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.model.GlobalApp
import kotlinx.android.parcel.Parcelize

@Parcelize
data class DeliverGuarantee(

        @field:SerializedName("ROUTE")
        val route: String? = null,

        @field:SerializedName("NET_VALUE")
        val netValue: Double? = null,

        @field:SerializedName("VSART")
        val vSart: String? = null,

        @field:SerializedName("STATUS_BL")
        val statusbl: String? = null,

        @field:SerializedName("ID_K")
        val idk: String? = null,

        @field:SerializedName("TAX")
        val tax: Double? = null,

        @field:SerializedName("ITEMS")
        val items: List<ItemsItem>? = null,

        @field:SerializedName("STBL")
        val guaranteeAmount: Double? = null,

        @field:SerializedName("DIVISION")
        val dIVISION: String? = null,

        @field:SerializedName("ZTYPE")
        val type: String? = null,

        @field:SerializedName("STATUS")
        val status: String? = null,

        @field:SerializedName("ID_U")
        val idu: String? = null,

        @field:SerializedName("NOTE")
        val note: String? = null,

        @field:SerializedName("SHIPTO_ID")
        val shiptoID: String? = null,

        @field:SerializedName("TOTAL_PRICE")
        val totalPrice: Double? = null,

        @field:SerializedName("CREATE_BY_NAME")
        val createByName: String? = null,

        @field:SerializedName("Z_DATE")
        val date: String? = null,

        @field:SerializedName("ZTERM")
        val term: String? = null,

        @field:SerializedName("ZIMAGE")
        val image: String? = null,

        @field:SerializedName("KUNNR")
        val kunnr: String? = null,

        @field:SerializedName("TODAY")
        val today: String? = null,

        @field:SerializedName("CK")
        val ck: Double? = null,

        @field:SerializedName("CREDIT_VALUE_CUS")
        val creditValueCUS: Double? = null,

        @field:SerializedName("NAME_APPROVE")
        val nameApprove: String? = null,

        @field:SerializedName("ZLEVEL")
        val level: String? = null,

        @field:SerializedName("ORDER_TYPE")
        val orderType: String? = null,

        @field:SerializedName("NAME_SHIPTO")
        val nameshipTo: String? = null,

        @field:SerializedName("ZPRICE")
        val price: Double? = null,

        @field:SerializedName("NAME")
        val name: String? = null,

        @field:SerializedName("ID_ORDER")
        val idOrder: String? = null,

        @field:SerializedName("TOTAL_INQUIRY")
        val totalInquiry: Double? = null,

        @field:SerializedName("AUART")
        val auart: String? = null,

        @field:SerializedName("STDBL")
        val stdbl: Double? = null,

        @field:SerializedName("ADDRESS")
        val address: String? = null,

        @field:SerializedName("CREATE_BY")
        val createBy: String? = null,

        @field:SerializedName("CREDIT_VALUE")
        val creditValue: Double? = null,

        @field:SerializedName("ID_USER")
        val iduser: String? = null,

        @field:SerializedName("PHONE_NUMBER")
        val phoneNumber: String? = null,

        @field:SerializedName("ID_APPROVE")
        val idApprove: String? = null,

        @field:SerializedName("DC")
        val dc: String? = null
) : Parcelable {
    fun trace() {
        Debug.e("idOrder: ${idOrder}\ndate request: ${date}\naddress: ${address}\nmoney: ${GlobalApp.getInstance().decimalFormat.format(price)} VNĐ\nguaranteeAmount: ${GlobalApp.getInstance().decimalFormat.format(guaranteeAmount)} VNĐ")
    }
}
