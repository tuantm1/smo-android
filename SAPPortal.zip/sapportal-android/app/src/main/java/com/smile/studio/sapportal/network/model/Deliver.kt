package com.smile.studio.sapportal.network.model

import android.os.Parcelable
import android.text.TextUtils
import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug
import kotlinx.android.parcel.Parcelize
import java.math.BigDecimal

@Parcelize
data class Deliver(

        @field:SerializedName("ROUTE")
        val route: String? = null,

        @field:SerializedName("NET_VALUE")
        val netValue: Double? = null,

        @field:SerializedName("VSART")
        val vSart: String? = null,

        @field:SerializedName("STATUS_BL")
        val statusbl: String? = null,

        @field:SerializedName("ID_K")
        val idk: String? = null,

        @field:SerializedName("TAX")
        val tax: Double? = null,

        @field:SerializedName("ITEMS")
        val items: ArrayList<Items>? = null,

        @field:SerializedName("STBL")
        val guaranteeAmount: BigDecimal? = null,

        @field:SerializedName("DIVISION")
        val division: String? = null,

        @field:SerializedName("ZTYPE")
        val zType: String? = null,

        @field:SerializedName("STATUS")
        val status: String? = null,

        @field:SerializedName("ID_U")
        val idu: String? = null,

        @field:SerializedName("NOTE")
        val note: String? = null,

        @field:SerializedName("TOTAL_PRICE")
        val totalPrice: Double? = null,

        @field:SerializedName("Z_DATE")
        val date: String? = null,

        @field:SerializedName("ZNTCXD")
        val zntcxd: String? = null,

        @field:SerializedName("ZNGAYGH")
        val zngaygh: String? = null,

        @field:SerializedName("ZNGUOIGH")
        val znguoigh: String? = null,

        @field:SerializedName("ZTERM")
        val zterm: String? = null,

        @field:SerializedName("ZIMAGE")
        val zimage: String? = null,

        @field:SerializedName("KUNNR")
        val kunnr: String? = null,

        @field:SerializedName("TODAY")
        val today: String? = null,

        @field:SerializedName("CK")
        val discount: Double? = null,

        @field:SerializedName("CREDIT_VALUE_CUS")
        val creditValueCus: Double? = null,

        @field:SerializedName("NAME_APPROVE")
        val nameApprove: String? = null,

        @field:SerializedName("ZLEVEL")
        val zLevel: String? = null,

        @field:SerializedName("ORDER_TYPE")
        val orderType: String? = null,

        @field:SerializedName("SHIPTO_ID")
        val shipToID: String? = null,

        @field:SerializedName("NAME_SHIPTO")
        val nameShipTo: String? = null,

        @field:SerializedName("ZPRICE")
        val zPrice: BigDecimal? = null,

        @field:SerializedName("NAME")
        val name: String? = null,

        @field:SerializedName("ID_ORDER")
        val idOrder: String? = null,

        @field:SerializedName("TOTAL_INQUIRY")
        val totalInquiry: Double? = null,

        @field:SerializedName("AUART")
        val auart: String? = null,

        @field:SerializedName("STDBL")
        val stdbl: BigDecimal? = null,

        @field:SerializedName("ADDRESS")
        val address: String? = null,

        @field:SerializedName("CREATE_BY")
        val createdByID: String? = null,

        @field:SerializedName("CREATE_BY_NAME")
        val createdByName: String? = null,

        @field:SerializedName("CREDIT_VALUE")
        val creditValue: Double? = null,

        @field:SerializedName("ID_USER")
        val idUser: String? = null,

        @field:SerializedName("TEN_NNH")
        val usernameReciver: String? = null,

        @field:SerializedName("PHONE_NUMBER")
        val phoneNumber: String? = null,

        @field:SerializedName("TEN_KHC")
        val usernameCustomer: String? = null,

        @field:SerializedName("SDT_KHC")
        val phoneEndUser: String? = null,

        @field:SerializedName("DC_KHC")
        val addressCustomer: String? = null,

        @field:SerializedName("ID_APPROVE")
        val idApprove: String? = null,

        @field:SerializedName("DC")
        val dc: String? = null,

        @field:SerializedName("ZTC")
        val ztc: String? = null
) : Parcelable {
    fun trace() {
        Debug.e("name: ${name}\nidOrder: ${idOrder}\nidUser: ${idUser}\nidApprove: ${idApprove}\ndate: ${date}\ncreated_by: ${createdByID}\nnote: ${note}\nstatus: ${status} \nstatusbl: ${statusbl}")
    }
}

@Parcelize
data class Items(

        @field:SerializedName("QUANTITY")
        var quantity: Float? = 0F,

        @field:SerializedName("WIDTH")
        var width: Float? = 0F,

        @field:SerializedName("HEIGHT")
        var height: Float? = 0F,

        @field:SerializedName("ID_ITEM")
        val idItem: String? = null,

        @field:SerializedName("ID_HEADER")
        var idHeader: String? = null,

        @field:SerializedName("SALE_UNIT", alternate = arrayOf("MATKL"))
        var saleUnit: String? = null,

        @field:SerializedName("MEINS")
        var meins: String? = null,

        @field:SerializedName("CHARACTERISTICS")
        var characteristics: ArrayList<CharacteristicsItem>? = ArrayList(),

        @field:SerializedName("THANH_LE")
        val thanhle: String? = null,

        @field:SerializedName("TYPE")
        var type: String? = null,

        @field:SerializedName("MATNR")
        var matnr: String? = null,

        @field:SerializedName("NAME", alternate = arrayOf("MAKTX"))
        var name: String? = null,

        @field:SerializedName("Z_RETURN")
        var zReturn: String? = null,

        @field:SerializedName("ZDKGH")
        var zdkgh: String? = null,

        @field:SerializedName("value")
        var value: String? = null,

        @field:SerializedName("ZPRICE")
        var zPrice: BigDecimal? = null,

        @field:SerializedName("EXTWG")
        var extwg: String? = ""
) : Parcelable {
    fun trace() {
        Debug.e("matnr: ${matnr}\nname: ${name}\nquantity: ${quantity}")
        characteristics?.let {
            it.forEachIndexed { index, characteristicsItem ->
                characteristicsItem.trace()
            }
        }
    }

    fun getUnit(): String? {
        if (!TextUtils.isEmpty(meins)) {
            return meins
        } else {
            return saleUnit
        }
    }
}
