package com.smile.studio.sapportal.activity

import android.os.Bundle
import androidx.fragment.app.Fragment
import com.smile.studio.libsmilestudio.fragment.TabFragmentAdapter
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.fragment.CustomerCreditFragment
import com.smile.studio.sapportal.fragment.CustomerDetailFragment
import com.smile.studio.sapportal.network.model.Customer
import kotlinx.android.synthetic.main.activity_change_password.toolbar
import kotlinx.android.synthetic.main.activity_detail_customer.*

class DetailCustomerActivity : BaseActivity() {

    var customer: Customer? = null
    var mapFragments = LinkedHashMap<String, Fragment>()
    var adapter: TabFragmentAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_customer)
        setSupportActionBar(toolbar!!)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_back_gray)
        savedInstanceState?.let {
            customer = it.getParcelable(Customer::class.java.simpleName)
        } ?: run {
            customer = intent.getParcelableExtra(Customer::class.java.simpleName)
        }
        shareViewModel?.setData(customer)
        mapFragments.put(getString(R.string.title_detail_tab_customer), CustomerDetailFragment.newInstance())
        mapFragments.put(getString(R.string.title_detail_tab_customer_credit), CustomerCreditFragment.newInstance())
        adapter = TabFragmentAdapter(this, supportFragmentManager, mapFragments, false, viewPager)
        viewPager.adapter = adapter
        tabLayout.setupWithViewPager(viewPager)
    }
}