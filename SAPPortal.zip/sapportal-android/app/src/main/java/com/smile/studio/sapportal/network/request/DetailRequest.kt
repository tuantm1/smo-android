package com.smile.studio.sapportal.network.request

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize
import java.math.BigDecimal

@Parcelize
data class DetailRequest(

        @field:SerializedName("I_MACHUYEN")
        var imachuyen: String? = null,

        @field:SerializedName("TB_UPDATE")
        var items: ArrayList<ItemUpdate>? = null
) : Parcelable

@Parcelize
data class ItemUpdate(

        @field:SerializedName("Spvc")
		var iteItem: String? = null,

        @field:SerializedName("Item")
        var item: String? = null,

        @field:SerializedName("TT_GIAOHANG")
        var state: Int? = null,

        @field:SerializedName("CHI_PHI")
        var payment: BigDecimal? = null,

        @field:SerializedName("ZZ_DIACHI_GH3")
        var reason: String? = null,

        @field:SerializedName("ZZ_LOAIPHI")
        var charge_value: String? = null,

        @field:SerializedName("ZZ_LOAIPHI_DES")
        var charge_description: String? = null,

        @field:SerializedName("ZZ_LOCATION_LAT")
        var location_lat: Double? = null,

        @field:SerializedName("ZZ_LOCATION_LONG")
        var location_long: Double? = null
) : Parcelable
