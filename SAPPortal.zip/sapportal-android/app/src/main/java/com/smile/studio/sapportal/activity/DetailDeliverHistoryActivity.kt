package com.smile.studio.sapportal.activity

import android.Manifest
import android.annotation.SuppressLint
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Location
import android.os.Bundle
import android.text.TextUtils
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.esafirm.imagepicker.features.ImagePicker
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.gson.JsonObject
import com.gun0912.tedpermission.PermissionListener
import com.gun0912.tedpermission.TedPermission
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.libsmilestudio.utils.Utils
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.adapter.ChargeAdapter
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.face.SAPPortal
import com.smile.studio.sapportal.network.model.*
import com.smile.studio.sapportal.network.request.DetailRequest
import com.smile.studio.sapportal.network.request.ItemUpdate
import id.zelory.compressor.Compressor
import id.zelory.compressor.constraint.default
import id.zelory.compressor.constraint.format
import id.zelory.compressor.constraint.quality
import id.zelory.compressor.constraint.size
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_detail_deliver_history.*
import kotlinx.coroutines.launch
import java.io.File
import java.util.*
import kotlin.collections.ArrayList

class DetailDeliverHistoryActivity : BaseActivity(), View.OnClickListener {

    private var actualImageFile: File? = null
    var detail: DeliverHistory? = null
    var typeDeliver: Int? = TypeDeliver.DELIVER.value
    var lstItem: ArrayList<Item>? = null
    var charge: Charge? = null
    private var fusedLocationProviderClient: FusedLocationProviderClient? = null
    var latitude = 0.0
    var longitude = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_deliver_history)
        setSupportActionBar(toolbar!!)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_back_gray)
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)
        savedInstanceState?.let {
            typeDeliver = it.getInt(TypeDeliver::class.java.simpleName)
            detail = it.getParcelable(DeliverHistory::class.java.simpleName)
        } ?: run {
            typeDeliver = intent.getIntExtra(TypeDeliver::class.java.simpleName, TypeDeliver.DELIVER.value)
            detail = intent.getParcelableExtra(DeliverHistory::class.java.simpleName)
        }
        lstItem = intent.getParcelableArrayListExtra(Item::class.java.simpleName)
        tv_title_toolbar.text = getString(R.string.title_detail_deliver, detail?.idDeliver)
        tv_deliver_code.text = Utils.fromHtml(getString(R.string.title_detail_deliver_id, detail?.getDeliverID()))
        tv_reciver.text = Utils.fromHtml(getString(R.string.title_detail_deliver_reciver, detail?.reciver))
        tv_address.text = Utils.fromHtml(getString(R.string.title_detail_deliver_address, detail?.address1))
        tv_store.text = Utils.fromHtml(getString(R.string.title_detail_deliver_store, detail?.desciption))
        tv_timer.text = Utils.fromHtml(getString(R.string.title_detail_deliver_timer, detail?.timeDeliver))
        try {
            edt_cost.setText(GlobalApp.getInstance().decimalFormat.format(detail?.transportationCost))
        } catch (e: Exception) {
            Debug.e("--- Error: ${e.message}")
        }
        val strReason = if (!TextUtils.isEmpty(detail?.reason.toString())) detail?.reason.toString() else ""
        edt_reason.setText(strReason)
        var mName = ""
        lstItem?.forEach { item ->
            mName += "${item.description}, "
        }
        mName = mName.dropLast(2)
        tv_deliver_name.text = Utils.fromHtml(getString(R.string.title_detail_deliver_name, mName))
        btn_confirm_vehical_deliver.isSelected = true
        btn_printer.isSelected = true
        btn_upload_image.isSelected = true
        btn_confirm_vehical_deliver.setOnClickListener(this)
        btn_printer.setOnClickListener(this)
        btn_upload_image.setOnClickListener(this)
        btn_save.setOnClickListener(this)
        when (typeDeliver) {
            TypeDeliver.DELIVER.value -> {
                group_confirm.visibility = View.VISIBLE
                btn_confirm_vehical_deliver.visibility = View.GONE
                getData()
            }
            TypeDeliver.NOT_DELIVER.value -> {
                group_confirm.visibility = View.GONE
                btn_confirm_vehical_deliver.visibility = View.VISIBLE
            }
        }
        loadCharges()
    }

    private fun loadCharges() {
        val adapter = ChargeAdapter(this, ArrayList())
        spinner_charges.setAdapter(adapter)
        spinner_charges.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                charge = adapter.getItem(position)
                spinner_charges.setSelection(0, true)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

        })
        val subscribe = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getCharges()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doFinally {
                }.subscribe({
                    adapter.addAll(it.data!!)
                }, {
                    Debug.showAlert(this, "Error: ${it.message}")
                })
        compositeDisposable.add(subscribe)
    }

    private fun getData() {
        showProgressDialog()
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getImage(detail?.salesOrder!!)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            dismissProgressDialog()
        }.subscribe({
            showImageDecodeBase64(it.data?.image!!)
        }, {
            Debug.showAlert(this@DetailDeliverHistoryActivity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    @SuppressLint("NewApi")
    private fun showImageDecodeBase64(stringImageBase64: String) {
        val imageDecode = Base64.getDecoder().decode(stringImageBase64)
        val image = BitmapFactory.decodeByteArray(imageDecode, 0, imageDecode.size)
        Glide.with(this@DetailDeliverHistoryActivity).load(image)
                .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.ALL)
                        .format(DecodeFormat.PREFER_ARGB_8888)
                        .dontAnimate())
                .thumbnail(0.5f)
                .into(thumb)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(TypeDeliver::class.java.simpleName, typeDeliver!!)
        outState.putParcelable(DeliverHistory::class.java.simpleName, detail)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btn_save -> {
                postDetailDeliver()
            }
            R.id.btn_confirm_vehical_deliver -> {
                TedPermission.with(this)
                        .setPermissionListener(object : PermissionListener {
                            @SuppressLint("MissingPermission")
                            override fun onPermissionGranted() {
                                fusedLocationProviderClient?.lastLocation
                                        ?.addOnSuccessListener(this@DetailDeliverHistoryActivity) { it: Location? ->
                                            if (it != null) {
                                                latitude = it.latitude
                                                longitude = it.longitude
                                            }
                                            Debug.e("--- location: $latitude, $longitude")
                                            onActionConfirmDeliver()
                                        }
                            }

                            override fun onPermissionDenied(deniedPermissions: MutableList<String>?) {
                            }
                        })
                        .setDeniedMessage("If you reject permission, you can not use this service\n\nPlease turn on permissions at [Setting] > [Permission]")
                        .setPermissions(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
                        .check()
            }
            R.id.btn_printer -> {
                val intent = Intent(this@DetailDeliverHistoryActivity, PDFPrinterActivity::class.java)
                intent.putExtra(DeliverHistory::class.java.simpleName, detail?.salesOrder)
                startActivity(intent)
            }
            R.id.btn_upload_image -> {
                TedPermission.with(this)
                        .setPermissionListener(object : PermissionListener {
                            override fun onPermissionGranted() {
                                ImagePicker.cameraOnly().start(this@DetailDeliverHistoryActivity)
                            }

                            override fun onPermissionDenied(deniedPermissions: MutableList<String>?) {
                            }
                        })
                        .setDeniedMessage("If you reject permission,you can not use this service\n\nPlease turn on permissions at [Setting] > [Permission]")
                        .setPermissions(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA)
                        .check()
            }
        }
    }

    private fun onActionConfirmDeliver() {
        val alertDialog: AlertDialog.Builder = AlertDialog.Builder(this)
        alertDialog.setTitle(R.string.title_dialog_notification)
        alertDialog.setMessage(Utils.fromHtml(getString(R.string.text_message_confirm_deliver, detail?.idDeliver)))
        alertDialog.setNegativeButton(R.string.text_button_no) { dialog: DialogInterface, which: Int ->
        }
        alertDialog.setPositiveButton(R.string.text_button_yes) { dialog: DialogInterface, which: Int ->
            postDetailDeliver()
        }
        alertDialog.show()
    }

    private fun postDetailDeliver() {
        val detailRequest = DetailRequest()
        detailRequest.imachuyen = GlobalApp.getInstance().profile?.username
        detailRequest.items = ArrayList<ItemUpdate>()
        lstItem?.forEachIndexed { index, item ->
            val payment = edt_cost.text.toString().toBigDecimal()
            val reason = edt_reason.text.toString()
            val charge_value = charge?.value
            val charge_description = charge?.description
            detailRequest.items?.add(ItemUpdate(iteItem = item.idItem, item = item.item, state = 3, payment = payment, reason = reason,
                    charge_value = charge_value, charge_description = charge_description,
                    location_lat = latitude, location_long = longitude))
        }
        showProgressDialog()
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).updateDeliver(detailRequest)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .doFinally {
                    dismissProgressDialog()
                }.subscribe({
                    group_confirm.visibility = View.VISIBLE
                    btn_confirm_vehical_deliver.visibility = View.GONE
                }, {
                    Debug.showAlert(this@DetailDeliverHistoryActivity, "Error: ${it.message}")
                })
        compositeDisposable.add(subscribe)
    }

    @SuppressLint("NewApi")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        try {
            val images = ImagePicker.getImages(data)
            if (images != null && !images.isEmpty()) {
                showProgressDialog()
                val image = images.get(0).path
                actualImageFile = File(image)
                lifecycleScope.launch {
                    val compressedImageFile = Compressor.compress(this@DetailDeliverHistoryActivity, actualImageFile!!) {
                        default(300, 120)
//                        default(1280, 720)
                        quality(80)
                        format(Bitmap.CompressFormat.PNG)
                        size(1024)
                    }
                    compressedImageFile.let {
                        val imageBase64 = Base64.getEncoder().encodeToString(compressedImageFile.readBytes())
                        val mData = imageBase64?.chunked(1024 * 100)
                        val jsonObject = JsonObject()
                        jsonObject.addProperty("ID_ORDER", detail?.salesOrder)
                        mData?.forEachIndexed { index, value ->
                            if (index > 0) {
                                jsonObject.addProperty("XSTRING_${index}", value)
                            } else {
                                jsonObject.addProperty("XSTRING", value)
                            }
                        }
                        Debug.e("--- jsonObject: ${jsonObject}")
//                        val uploadFileRequest = UploadFileReqeust(detail?.idDeliver, imageBase64)
                        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).uploadFile(jsonObject)
                        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                                .doFinally {
                                    dismissProgressDialog()
                                    showImageDecodeBase64(imageBase64)
                                }.subscribe({
                                    if (it.message?.type?.equals(TypeError.ERROR.value)!!) {
                                        Debug.showAlert(this@DetailDeliverHistoryActivity, "Lỗi gửi hình ảnh")
                                    } else {

                                    }
                                }, {
                                    Debug.showAlert(this@DetailDeliverHistoryActivity, "Error: ${it.message}")
                                })
                        compositeDisposable.add(subscribe)
                    }
                }

            } else {
                Debug.e("--- Không có file convert")
            }
        } catch (e: Exception) {
            Debug.e("--- Lỗi: ${e.message}")
        }
    }

}