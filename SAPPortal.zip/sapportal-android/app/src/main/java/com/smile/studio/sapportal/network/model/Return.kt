package com.smile.studio.sapportal.network.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import com.smile.studio.libsmilestudio.utils.Debug
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Return(

        @field:SerializedName("ID")
        val id: String? = null,

        @field:SerializedName("SYSTEM")
        val system: String? = null,

        @field:SerializedName("NUMBER")
        val number: String? = null,

        @field:SerializedName("FIELD")
        val field: String? = null,

        @field:SerializedName("MESSAGE")
        val message: String? = null,

        @field:SerializedName("MESSAGE_V1")
        val messagev1: String? = null,

        @field:SerializedName("MESSAGE_V2")
        val messagev2: String? = null,

        @field:SerializedName("MESSAGE_V3")
        val messagev3: String? = null,

        @field:SerializedName("MESSAGE_V4")
        val messagev4: String? = null,

        @field:SerializedName("LOG_NO")
        val logno: String? = null,

        @field:SerializedName("ROW")
        val row: Int? = null,

        @field:SerializedName("TYPE")
        val type: String? = null,

        @field:SerializedName("LOG_MSG_NO")
        val logmsgno: String? = null,

        @field:SerializedName("PARAMETER")
        val parameter: String? = null
) : Parcelable {
    fun trace() {
        Debug.e("uid: ${id}\ntype: ${type}")
    }
}
