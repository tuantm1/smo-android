package com.smile.studio.sapportal.activity

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.*
import android.text.TextUtils
import android.view.Menu
import android.view.MenuItem
import android.view.MotionEvent
import com.github.barteksc.pdfviewer.listener.*
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.face.SAPPortal
import com.smile.studio.sapportal.network.model.API
import com.smile.studio.sapportal.network.model.DeliverHistory
import com.smile.studio.sapportal.network.request.DeliverPDFRequest
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_pdf_printer.*
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.util.*

class PDFPrinterActivity : BaseActivity(), OnLoadCompleteListener, OnPageChangeListener, OnPageScrollListener, OnErrorListener, OnPageErrorListener, OnRenderListener, OnTapListener {

    var saleOrder: String? = null
    var decodeBase64: ByteArray? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pdf_printer)
        setSupportActionBar(toolbar!!)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_back_gray)
        savedInstanceState?.let {
            saleOrder = it.getString(DeliverHistory::class.java.simpleName)
        } ?: run {
            saleOrder = intent.getStringExtra(DeliverHistory::class.java.simpleName)
        }
        getData()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.pdf_printer_menu, menu!!)
        return super.onCreateOptionsMenu(menu)
    }

    @SuppressLint("NewApi")
    private fun getData() {
        showProgressDialog()
        val calendar  =  Calendar.getInstance()
        calendar.time = Date()
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMinimum(Calendar.DAY_OF_MONTH))
        val from = GlobalApp.getInstance().dateFormat1.format(calendar.time)
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH))
        val to = GlobalApp.getInstance().dateFormat1.format(calendar.time)
        val deliverPDFRequest = DeliverPDFRequest(saleOrder!!, from, to)
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getPDFToBase64(deliverPDFRequest)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            dismissProgressDialog()
        }.subscribe({
            if (!TextUtils.isEmpty(it.data)) {
                decodeBase64 = Base64.getDecoder().decode(it.data)
                pdfView.fromBytes(decodeBase64)
                        .enableSwipe(true) // allows to block changing pages using swipe
                        .swipeHorizontal(true)
                        .enableDoubletap(true)
                        .defaultPage(0)
                        .onLoad(this@PDFPrinterActivity) // called after document is loaded and starts to be rendered
                        .onError(this@PDFPrinterActivity)
                        .onPageError(this@PDFPrinterActivity)
                        .enableAnnotationRendering(false) // render annotations (such as comments, colors or forms)
                        .enableAntialiasing(true) // improve rendering a little bit on low-res screens
                        .pageSnap(true)
                        .autoSpacing(true)
                        .pageFling(true)
                        .onTap(this@PDFPrinterActivity)
//                    .password("")
                        .onPageChange(this)
                        .nightMode(false)
                        .load()
            } else {
                Debug.showAlert(this@PDFPrinterActivity, getString(R.string.message_error_get_pdf))
            }
        }, {
            Debug.showAlert(this@PDFPrinterActivity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(DeliverHistory::class.java.simpleName, saleOrder)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
            }
            R.id.navigation_print -> {
                onActionPrinter()
            }
        }
        return super.onOptionsItemSelected(item)
    }

    @SuppressLint("NewApi")
    private fun onActionPrinter() {
        Debug.e("--- printer")
        val pda: PrintDocumentAdapter = object : PrintDocumentAdapter() {
            override fun onLayout(oldAttributes: PrintAttributes?, newAttributes: PrintAttributes?, cancellationSignal: CancellationSignal?, callback: LayoutResultCallback?, extras: Bundle?) {
                if (cancellationSignal?.isCanceled!!) {
                    callback?.onLayoutCancelled()
                    return
                }
                val pdi: PrintDocumentInfo = PrintDocumentInfo.Builder("${saleOrder}.PDF").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build()
                callback?.onLayoutFinished(pdi, true)
            }

            override fun onWrite(pages: Array<out PageRange>?, destination: ParcelFileDescriptor?, cancellationSignal: CancellationSignal?, callback: WriteResultCallback?) {
                var output: OutputStream? = null
                try {
                    output = FileOutputStream(destination?.fileDescriptor)
                    output.write(decodeBase64!!)
                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    Debug.e("--- Error: ${e.message}")
                } finally {
                    try {
                        output?.close()
                    } catch (e: IOException) {
                        Debug.e("--- Error: ${e.message}")
                    }
                }
            }

        }
        val printManager = getSystemService(Context.PRINT_SERVICE) as PrintManager
        val printJobName = "${getString(R.string.app_name)} Documennt"
        printManager.print(printJobName, pda, null)

    }

    override fun loadComplete(nbPages: Int) {

    }

    override fun onPageChanged(page: Int, pageCount: Int) {

    }

    override fun onPageScrolled(page: Int, positionOffset: Float) {

    }

    override fun onError(t: Throwable?) {
        Debug.e("--- Error: ${t?.message}")
    }

    override fun onPageError(page: Int, t: Throwable?) {
        Debug.e("--- Error: ${t?.message}")
    }

    override fun onInitiallyRendered(nbPages: Int) {

    }

    override fun onTap(e: MotionEvent?): Boolean {
        return true
    }
}