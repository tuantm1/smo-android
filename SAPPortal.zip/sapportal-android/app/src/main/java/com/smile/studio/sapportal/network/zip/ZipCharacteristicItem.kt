package com.smile.studio.sapportal.network.zip

import com.google.gson.annotations.SerializedName
import com.smile.studio.sapportal.network.model.CharacteristicsItem
import com.smile.studio.sapportal.network.response.AttributesResponse
import com.smile.studio.sapportal.network.response.BaseResponse

class ZipCharacteristicItem(
        @SerializedName("Characteristic")
        val characteristic_t1: AttributesResponse? = null,

        @SerializedName("CharacteristicDefault")
        val characteristicDefault_t2: BaseResponse<ArrayList<CharacteristicsItem>>? = null
)