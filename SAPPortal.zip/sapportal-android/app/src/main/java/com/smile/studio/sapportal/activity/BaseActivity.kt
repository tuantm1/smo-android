@file:Suppress("DEPRECATION")

package com.smile.studio.sapportal.activity

import android.app.ProgressDialog
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.text.TextUtils
import android.util.DisplayMetrics
import android.view.MenuItem
import android.view.Window
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.ViewModelProviders
import com.bumptech.glide.Glide
import com.google.firebase.analytics.FirebaseAnalytics
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.model.viewmodel.ShareViewModel
import io.reactivex.disposables.CompositeDisposable

open class BaseActivity : AppCompatActivity() {

    var progressDialog: ProgressDialog? = null
    val compositeDisposable = CompositeDisposable()
    val TIME_DELAY = 1500L
    var analytics: FirebaseAnalytics? = null
    var shareViewModel: ShareViewModel<*>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        analytics = FirebaseAnalytics.getInstance(this)
        analytics?.setAnalyticsCollectionEnabled(true)
        shareViewModel = ViewModelProviders.of(this).get(ShareViewModel::class.java)
        adjustScale()
    }

    open fun adjustScale() {
        val configuration = resources.configuration
        configuration.fontScale = 1f
        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(metrics)
        metrics.scaledDensity = configuration.fontScale * metrics.density
        configuration.densityDpi = DisplayMetrics.DENSITY_DEVICE_STABLE
        baseContext.resources.updateConfiguration(configuration, metrics)
    }

    fun onChangeFragment(fragment: Fragment, tag: String) {
        val transaction = supportFragmentManager.beginTransaction()
        transaction.setCustomAnimations(R.anim.slide_in_left, R.anim.slide_out_right)
        if (!TextUtils.isEmpty(tag)) {
            transaction.replace(R.id.container, fragment, tag).addToBackStack(tag)
        } else {
            transaction.replace(R.id.container, fragment)
        }
        try {
            transaction.commit()
        } catch (e: IllegalStateException) {
            transaction.commitAllowingStateLoss()
        }
    }

    fun onChangeFragmentClean(fragment: Fragment, tag: String) {
        supportFragmentManager.popBackStack(tag, FragmentManager.POP_BACK_STACK_INCLUSIVE)
        val transaction = supportFragmentManager.beginTransaction()
        transaction.setCustomAnimations(R.anim.slide_in_left, R.anim.slide_out_right)
        if (!TextUtils.isEmpty(tag)) {
            transaction.replace(R.id.container, fragment, tag).addToBackStack(tag)
        } else {
            transaction.replace(R.id.container, fragment)
        }
        try {
            transaction.commit()
        } catch (e: IllegalStateException) {
            transaction.commitAllowingStateLoss()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onDestroy() {
        compositeDisposable.clear()
        super.onDestroy()
        System.gc()
        Runtime.getRuntime().gc()
    }

    fun showProgressDialog() {
        if (progressDialog == null) {
            progressDialog = ProgressDialog.show(this, null, null, true)
            progressDialog?.setContentView(R.layout.custom_progress_dialog)
            progressDialog?.isIndeterminate = true
            progressDialog?.setCancelable(false)
            progressDialog?.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
                val drawable = ProgressBar(this).indeterminateDrawable.mutate()
                drawable.setColorFilter(ContextCompat.getColor(this, R.color.colorAccent), PorterDuff.Mode.SRC_IN)
                progressDialog?.setIndeterminateDrawable(drawable)
            }
        }
        if (progressDialog != null && !progressDialog?.isShowing!!) {
            progressDialog?.show()
        }
    }

    fun dismissProgressDialog() {
        if (progressDialog != null && progressDialog?.isShowing!!) {
            progressDialog?.dismiss()
        }
    }

    override fun onLowMemory() {
        super.onLowMemory()
        Glide.get(this).clearMemory()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        Glide.get(this).trimMemory(level)
    }
}
