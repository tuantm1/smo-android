package com.smile.studio.sapportal.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.fragment.deliver.DetailDeliverFragment
import com.smile.studio.sapportal.network.model.Deliver
import kotlinx.android.synthetic.main.activity_detail_deliver_history.*

class DetailDeliverActivity : BaseActivity() {

    var mapFragments: LinkedHashMap<String, Fragment>? = LinkedHashMap<String, Fragment>()
    var mListDeliver: ArrayList<Deliver>? = null
    var page = 0

    companion object {
        val PAGE = "page"

        fun openIntentData(context: Context, deliver: Deliver) {
            val intent = Intent(context, DetailDeliverActivity::class.java)
            intent.putExtra(Deliver::class.java.simpleName, deliver)
            context.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_deliver)
        setSupportActionBar(toolbar!!)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_back_gray)
        page = intent.getIntExtra(PAGE, 0)
        val deliver: Deliver = intent.getParcelableExtra<Deliver>(Deliver::class.java.simpleName)!!
        shareViewModel?.setData(deliver)
        onChangeFragment(DetailDeliverFragment.newInstance(), "")
//        mListDeliver = GlobalApp.getInstance().gson.fromJson(jsonObject, Array<Deliver>::class.java).toList() as ArrayList<Deliver>
//        tv_page_of_groups.text = getString(R.string.title_page_of_groups, page + 1, mListDeliver?.size)
//        mListDeliver?.forEachIndexed { index, deliver ->
//            mapFragments?.put(deliver.idOrder.toString(), DetailDeliverFragment.newInstance(deliver))
//        }
//        val tabFragmentAdapter = TabFragmentAdapter(this@DetailDeliverActivity, supportFragmentManager, mapFragments, true, viewPager)
//        viewPager.adapter = tabFragmentAdapter
//        viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
//            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
//
//            }
//
//            override fun onPageSelected(position: Int) {
//                tv_page_of_groups.text = getString(R.string.title_page_of_groups, position + 1, mListDeliver?.size)
//            }
//
//            override fun onPageScrollStateChanged(state: Int) {
//
//            }
//        })
//        viewPager.setCurrentItem(page, true)
    }

}