package com.smile.studio.sapportal.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.smile.studio.sapportal.R
import kotlinx.android.synthetic.main.custom_item_customer_credit.*

class ApproveCreditListFragment : BaseFragment(), View.OnClickListener {

    companion object {
        fun newInstance(): ApproveCreditListFragment {
            val fragment = ApproveCreditListFragment()
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_approve_credit_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        btn_guarantee.isSelected = true
        btn_guarantee.setOnClickListener(this)
        btn_reject.isSelected = true
        btn_reject.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when(v?.id){
            R.id.btn_guarantee -> {

            }
            R.id.btn_reject -> {

            }
        }
    }
}