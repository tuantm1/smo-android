package com.smile.studio.sapportal.adapter

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.AppCompatTextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.andexert.library.RippleView
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.libsmilestudio.utils.AndroidDeviceInfo
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.network.response.Menu

class MenuAdapter(val mContext: Context?, val numberColumns: Int, val mData: ArrayList<Menu>?) : RecyclerView.Adapter<MenuAdapter.ViewHolder>() {

    var onItemClick: OnItemClickListenerRecyclerView? = null
    var width = 0
    var height = 0

    init {
        val point = AndroidDeviceInfo.getScreenSize(mContext)
        width = point.x / numberColumns
        when (numberColumns) {
            1 -> {
                height = width * 7 / 21
            }
            2 -> {
                height = width * 9 / 14
            }
        }
    }

    fun addAll(mData: ArrayList<Menu>) {
        this.mData?.addAll(mData)
        notifyDataSetChanged()
    }

    fun clear() {
        this.mData?.clear()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(mContext).inflate(R.layout.custom_item_menu, parent, false)
        view.layoutParams = ViewGroup.LayoutParams(width, height)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return mData?.size!!
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        try {
            holder.cardView.setCardBackgroundColor(Color.parseColor(mData?.get(position)?.color))
        } catch (e: Exception) {
            Debug.e("--- Error: ${e.message}")
        }
        holder.tv_title.text = mData?.get(position)?.description
        holder.rippleView.setOnRippleCompleteListener { view ->
            onItemClick?.onClick(view, position)
        }
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val rippleView = view.findViewById<RippleView>(R.id.rippleView)
        val cardView = view.findViewById<CardView>(R.id.cardView)
        val tv_title = view.findViewById<AppCompatTextView>(R.id.tv_title)
    }
}