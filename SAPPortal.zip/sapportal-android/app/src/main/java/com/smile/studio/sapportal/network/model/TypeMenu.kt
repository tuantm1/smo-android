package com.smile.studio.sapportal.network.model

enum class TypeMenu(val  value: Int) {

    MENU_PROFILE(1), MENU_HOME(2), MENU_SAP(3)
}