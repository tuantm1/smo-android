package com.smile.studio.sapportal.activity

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.View
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.BuildConfig
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.face.SAPPortal
import com.smile.studio.sapportal.network.model.API
import com.smile.studio.sapportal.network.model.User
import com.smile.studio.sapportal.view.SettingDomainDialogFragment
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_login.*
import java.util.concurrent.TimeUnit

class LoginActivity : BaseActivity(), View.OnClickListener, TextWatcher {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_login)
        edt_password.addTextChangedListener(this)
        btn_login.setOnClickListener(this)
        btn_setting.setOnClickListener(this)
        if (BuildConfig.DEBUG) {
            edt_username.setText(BuildConfig.ACCOUNT)
            edt_password.setText(BuildConfig.PASSWORD)
        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btn_setting -> {
                SettingDomainDialogFragment.newInstance().show(supportFragmentManager, SettingDomainDialogFragment::class.java.simpleName)
            }
            R.id.btn_login -> {
                var flag = false
                var username = edt_username.text.toString()
                var password = edt_password.text.toString()
                if (TextUtils.isEmpty(username)) {
                    flag = true
                    edt_username.error = getString(R.string.message_error_input_username)
                }
                if (TextUtils.isEmpty(password)) {
                    flag = true
                    edt_password.error = getString(R.string.message_error_input_password)
                }
                showProgressDialog()
                if (!flag) {
                    onActionLogin(username, password)
                } else {
                    dismissProgressDialog()
                }
            }
        }
    }

    private fun onActionLogin(username: String, password: String) {
        val userlogin = User(username = username, password = password)
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).login(userlogin)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            dismissProgressDialog()
        }.subscribe({
            try {
                if (!it.authen?.uid.equals("0000000000")) {
                    Debug.e("--- User login successfull")
                    Debug.showAlert(this@LoginActivity, getString(R.string.message_successull_login_system))
                    GlobalApp.getInstance().mDataMenu.clear()
                    it?.authen?.menu?.forEachIndexed { index, menu ->
                        GlobalApp.getInstance().mDataMenu.add(menu)
                    }
                    GlobalApp.getInstance().profile = User(uid = it.authen?.uid, username = it.authen?.username, password = password, kunnr = it.authen?.kunnr, idPeer = it.authen?.idpeer)
                    val subscribe = Observable.timer(300, TimeUnit.MILLISECONDS).subscribe {
                        val intent = Intent(this@LoginActivity, MainActivity::class.java)
                        startActivity(intent)
                        finish()
                    }
                    compositeDisposable.add(subscribe)
                } else {
                    Debug.e("--- User login error")
                    Debug.showAlert(this@LoginActivity, getString(R.string.message_error_login_system))
                }
            } catch (e: Exception) {
                Debug.e("--- Error: ${e.message}")
                Debug.showAlert(this@LoginActivity, getString(R.string.message_error_login_system))
            }
        }, {
            Debug.showAlert(this@LoginActivity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    override fun afterTextChanged(s: Editable?) {
        btn_login.isSelected = !TextUtils.isEmpty(edt_password.text.toString())
    }

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

    }

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

    }
}