package com.smile.studio.sapportal.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.activity.BaseActivity
import com.smile.studio.sapportal.adapter.ProductAdapter
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.face.SAPPortal
import com.smile.studio.sapportal.network.model.*
import com.smile.studio.sapportal.network.request.ReasonRequest
import com.smile.studio.sapportal.network.response.BaseResponse
import com.smile.studio.sapportal.network.response.DetailProfileResponse
import com.smile.studio.sapportal.network.zip.ZipDetailCredit
import com.smile.studio.sapportal.network.zip.ZipDetailUserCreadit
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.functions.BiFunction
import io.reactivex.functions.Function4
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.fragment_confirm_order.*
import kotlinx.android.synthetic.main.fragment_detail_credit.*
import kotlinx.android.synthetic.main.fragment_detail_credit.recyclerView
import kotlinx.android.synthetic.main.fragment_detail_credit.tv_amount_to_guarantee
import kotlinx.android.synthetic.main.fragment_detail_credit.tv_status
import kotlinx.android.synthetic.main.fragment_detail_credit.tv_zCredit
import kotlinx.android.synthetic.main.fragment_detail_credit.tv_zcreditcus
import java.util.*
import kotlin.collections.ArrayList

class DetailCreditFragment : BaseFragment() {

    var credit: Credit? = null
    var adapter: ProductAdapter? = null
    var layoutmanager: LinearLayoutManager? = null
    var division: String? = null

    companion object {
        fun newInstance(credit: Credit?): DetailCreditFragment {
            val bundle = Bundle()
            bundle.putParcelable(Deliver::class.java.simpleName, credit)
            val fragment = DetailCreditFragment()
            fragment.arguments = bundle
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_detail_credit, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        credit = arguments?.getParcelable(Deliver::class.java.simpleName)
        adapter = ProductAdapter(activity, ArrayList(), false)
        recyclerView.adapter = adapter
        layoutmanager = LinearLayoutManager(activity)
        recyclerView.layoutManager = layoutmanager
        recyclerView.setHasFixedSize(true)
        recyclerView.isNestedScrollingEnabled = false
        getDetailCredit()
    }

    private fun getDetailCredit() {
        val body1 = ReasonRequest(idCredit = credit?.idCredit)
        val requestDetailUserCredit1 = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getDetailCredit(body1)
        val body2 = ReasonRequest(idUser = credit?.idApprove, idOrder = credit?.idOrder)
        val requestDetailUserCredit2 = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getUserCredit(body2)
        val subscribe = Observable.zip(requestDetailUserCredit1, requestDetailUserCredit2, object : BiFunction<BaseResponse<Credit>, DetailUserCredit, ZipDetailUserCreadit> {
            override fun apply(t1: BaseResponse<Credit>, t2: DetailUserCredit): ZipDetailUserCreadit {
                return ZipDetailUserCreadit(t1, t2)
            }

        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {

        }.subscribe({
            val credit = it?.user1?.data
            val detailUser2Credit = it?.user2
            tv_underwriting_limits.value = "${GlobalApp.getInstance().decimalFormat.format(detailUser2Credit?.underwriting_limits)} VNĐ"
            tv_status.value = if (credit?.status.equals("")) "Đang tạo bảo lãnh" else "Đã bảo lãnh"
            tv_created.value = credit?.date
            val amount = credit?.day?.toInt()!!
            tv_time_credit.value = amount.toString()
            val calendar = Calendar.getInstance()
            calendar.time = GlobalApp.getInstance().dateFormat2.parse(credit.date)
            calendar.add(Calendar.DATE, amount)
            tv_expire_credit.value = GlobalApp.getInstance().dateFormat2.format(calendar.time)
            tv_note.text = credit.note
            data(credit)
        }, {
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    private fun data(credit: Credit?) {
        val creditRequest = ReasonRequest(idUser = credit?.idRequest, idOrder = credit?.idOrder, idCredit = credit?.idApprove)
        (activity as BaseActivity).showProgressDialog()
        val requestDeliver = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getDetailOrder(ReasonRequest(idOrder = creditRequest.idOrder))
        val requestCredit = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getUserCredit(ReasonRequest(idUser = creditRequest.idUser, idOrder = creditRequest.idOrder))
        val requestDision = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getDivision(creditRequest)
        val requestDetailUser = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getDetailUser(ReasonRequest(idUser = creditRequest.idUser))
        val subscribe = Observable.zip(requestDeliver, requestCredit, requestDision, requestDetailUser, object : Function4<BaseResponse<Deliver>, DetailUserCredit, DetailDivision, DetailProfileResponse, ZipDetailCredit> {
            override fun apply(t1: BaseResponse<Deliver>, t2: DetailUserCredit, t3: DetailDivision, t4: DetailProfileResponse): ZipDetailCredit {
                return ZipDetailCredit(t1, t2, t3, t4)
            }

        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            (activity as BaseActivity).dismissProgressDialog()
        }.subscribe({
            division = it.deliver_t1?.data?.division
            tv_requestName.value = it.detailUser_t4?.user?.description
            it.detailUserCredit_t2?.parents?.forEachIndexed { index, user ->
                if (user.uid.equals(credit?.idRequest)) {
                    tv_requestName.value = user.description
                }
                if (user.uid.equals(credit?.idApprove)) {
                    tv_approveName.value = user.description
                }
            }
            var type = ""
            it.detailDivision_t3?.divisions?.forEachIndexed { index, itemDivision ->
                if (it.detailUserCredit_t2?.grade.equals("CS${itemDivision.spart}")) {
                    type = itemDivision.vText!!
                }
            }
            val deliver = it.deliver_t1?.data!!
            tv_agency.value = deliver.nameShipTo
            tv_number.value = deliver.idOrder
            tv_zpirce.value = "${GlobalApp.getInstance().decimalFormat.format(deliver.zPrice)} VNĐ"
            tv_stdbl.value = "${GlobalApp.getInstance().decimalFormat.format(deliver.stdbl)} VNĐ"
            tv_total_inquiry.value = "${GlobalApp.getInstance().decimalFormat.format(deliver.totalInquiry)} VNĐ"
            tv_amount_to_guarantee.value = "${GlobalApp.getInstance().decimalFormat.format(deliver.guaranteeAmount)} VNĐ"
            getDetailUser(it.deliver_t1.data)
        }, {
            Debug.e("--- Error: ${it.message}")
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    private fun getDetailCusomter(kunnr: String) {
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getDetailCustomers(kunnr)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
        }.subscribe({
            //Công nợ hiện tại
            it.data?.zCreditCustomer?.forEachIndexed { index, zCreditCustomer ->
                if (zCreditCustomer.cs?.equals("CS${division}")!!) {
                    zCreditCustomer.trace()
                    tv_zcreditcus.value = "${GlobalApp.getInstance().decimalFormat.format(zCreditCustomer.value)} VNĐ"
                }
            }
            //Hạn mức tín dụng
            it.data?.zCredit?.forEachIndexed { index, czRedit ->
                if (czRedit.cs?.equals("CS${division}")!!) {
                    czRedit.trace()
                    tv_zCredit.value = "${GlobalApp.getInstance().decimalFormat.format(czRedit.value)} VNĐ"
                }
            }
        }, {
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    private fun getDetailUser(detailOrder: Deliver) {
        val body = ReasonRequest(idUser = detailOrder.idUser)
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getDetailUser(body)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
        }.subscribe({
            Debug.e("--- kunnr: ${it.user?.kunnr!!}")
            getDetailCusomter(it.user.kunnr!!)
        }, {
            Debug.showAlert(activity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

}