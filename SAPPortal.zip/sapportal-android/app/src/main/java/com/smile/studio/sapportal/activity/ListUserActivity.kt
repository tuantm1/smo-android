package com.smile.studio.sapportal.activity

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.MenuItem
import android.view.View
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.libsmilestudio.utils.KeyboardUtils
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.adapter.DetailProfileAdapter
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.face.SAPPortal
import com.smile.studio.sapportal.network.model.API
import com.smile.studio.sapportal.network.request.ReasonRequest
import com.smile.studio.sapportal.network.model.User
import com.smile.studio.sapportal.network.response.DetailProfileResponse
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_change_password.toolbar
import kotlinx.android.synthetic.main.activity_list_user.*
import java.util.*
import kotlin.collections.ArrayList

class ListUserActivity : BaseActivity(), SearchView.OnQueryTextListener, SwipeRefreshLayout.OnRefreshListener {

    var searchView: SearchView? = null
    var keyword: String? = null
    var adapter: DetailProfileAdapter? = null
    var layoutManager: LinearLayoutManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_user)
        setSupportActionBar(toolbar!!)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_back)
        swipeRefreshLayout.setColorSchemeResources(android.R.color.holo_blue_bright, android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_red_light)
        swipeRefreshLayout.setOnRefreshListener(this)
        swipeRefreshLayout.isRefreshing = false
        layoutManager = LinearLayoutManager(this)
        recyclerView.layoutManager = layoutManager
        adapter = DetailProfileAdapter(this, ArrayList())
        recyclerView.adapter = adapter
        adapter?.onItemClick = object : OnItemClickListenerRecyclerView {
            override fun onClick(view: View?, position: Int) {
                val item = adapter?.mData?.get(position)
                item?.trace()
                val intent = Intent(this@ListUserActivity, DetailUserActivity::class.java)
                intent.putExtra(DetailProfileResponse::class.java.simpleName, item)
                startActivity(intent)
            }

            override fun onLongClick(view: View?, position: Int) {

            }

        }
        recyclerView.setHasFixedSize(true)
        getData()
    }

    private fun getData() {
        val callResponse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java).getListUser(GlobalApp.getInstance().profile?.uid!!)
        val subscribe = callResponse.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            swipeRefreshLayout.isRefreshing = false
        }.subscribe({
            showListUser(it.lstUser)
        }, {
            Debug.e("--- Error: ${it.message}")
            Debug.showAlert(this@ListUserActivity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    private fun showListUser(lstUser: ArrayList<User>?) {
        val mData : ArrayList<DetailProfileResponse>? = ArrayList()
        showProgressDialog()
        val requests = ArrayList<Observable<DetailProfileResponse>>()
        val callResonse = GlobalApp.getInstance().baseURL(API.HOST).create(SAPPortal::class.java)
        lstUser?.forEach { user ->
            requests.add(callResonse.getDetailUser(ReasonRequest(idUser = user.uid)))
        }
        val subscribe = Observable.zip(requests) { args -> Arrays.asList(args)
            args.forEachIndexed { index, detailItem ->
                val profile = detailItem as DetailProfileResponse
                mData?.add(profile)
            }
        }.subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).doFinally {
            dismissProgressDialog()
            adapter?.addAll(mData!!)
        }.subscribe({
        }, {
            Debug.e("--- Error: ${it.message}")
            Debug.showAlert(this@ListUserActivity, "Error: ${it.message}")
        })
        compositeDisposable.add(subscribe)
    }

    override fun onCreateOptionsMenu(menu: android.view.Menu?): Boolean {
        menuInflater.inflate(R.menu.swich_menu, menu)
        searchView = menu?.findItem(R.id.navigation_search)?.actionView as SearchView
        searchView?.queryHint = getString(R.string.hint_search)
        searchView?.setOnQueryTextListener(this)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onQueryTextSubmit(query: String?): Boolean {
        val query = query?.trim { it <= ' ' } as String
        if (!TextUtils.isEmpty(keyword) || keyword != query) {
            keyword = query
            Debug.e("--- search: $keyword")
            KeyboardUtils.toggleKeyboardVisibility(this@ListUserActivity)
            keyword = null.toString()
            searchView?.clearFocus()
        }
        return true
    }

    override fun onQueryTextChange(newText: String): Boolean {
        return false
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onRefresh() {
        if (swipeRefreshLayout.isRefreshing) {
            adapter?.clear()
            getData()
        }
    }

    override fun onPause() {
        super.onPause()
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.isRefreshing = false
            swipeRefreshLayout.destroyDrawingCache()
            swipeRefreshLayout.clearAnimation()
        }
    }
}