package com.smile.studio.sapportal.network.model

enum class TypeDeliver(val value: Int) {
    NOT_DELIVER(2), DELIVER(3)
}