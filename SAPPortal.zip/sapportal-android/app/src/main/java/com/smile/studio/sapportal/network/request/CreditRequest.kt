package com.smile.studio.sapportal.network.request

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class CreditRequest(

        @field:SerializedName("theCredit")
        var theCredit: TheCredit? = TheCredit(),

        @field:SerializedName("zstatus")
        var zstatus: String? = "1"
) : Parcelable

@Parcelize
data class TheCredit(

        @field:SerializedName("zprice")
        var zprice: String? = null,

        @field:SerializedName("id_request")
        var idRequest: String? = null,

        @field:SerializedName("id_order")
        var idOrder: String? = null,

        @field:SerializedName("name_requester")
        val nameRequester: String? = null,

        @field:SerializedName("grade")
        val grade: String? = null,

        @field:SerializedName("PARENTS")
        val parents: List<ParentsItem>? = null,

        @field:SerializedName("id_parent")
        val idParent: String? = null,

        @field:SerializedName("id_approve")
        var idApprove: String? = null,

        @field:SerializedName("stbl")
        var stbl: String? = null,

        @field:SerializedName("hmcl")
        val hmcl: Int? = null,

        @field:SerializedName("zdate")
        var zdate: String? = null,

        @field:SerializedName("zday")
        var zday: String? = null,

        @field:SerializedName("status")
        var status: Int? = 1

) : Parcelable

@Parcelize
data class ParentsItem(

        @field:SerializedName("KUNNR")
        val kunnr: String? = null,

        @field:SerializedName("PEER_TO_PEER")
        val peertopeer: String? = null,

        @field:SerializedName("PASSWORD")
        val password: String? = null,

        @field:SerializedName("DESCRIPTION")
        val description: String? = null,

        @field:SerializedName("PARENT_NAME")
        val parentname: String? = null,

        @field:SerializedName("PARENT_ID_2")
        val parentid2: String? = null,

        @field:SerializedName("USERNAME")
        val username: String? = null,

        @field:SerializedName("ID_GR")
        val idgr: String? = null,

        @field:SerializedName("ID_USER")
        val idUser: String? = null,

        @field:SerializedName("US_TYPE")
        val usType: String? = null,

        @field:SerializedName("PARENT_ID")
        val parentID: String? = null
) : Parcelable
