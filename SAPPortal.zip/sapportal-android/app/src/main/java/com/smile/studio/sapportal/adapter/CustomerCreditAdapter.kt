package com.smile.studio.sapportal.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.appcompat.widget.AppCompatTextView
import androidx.recyclerview.widget.RecyclerView
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.model.Credit
import com.smile.studio.sapportal.view.TextLabel

class CustomerCreditAdapter(val mContext: Context?, val mData: ArrayList<Credit>?) : RecyclerView.Adapter<CustomerCreditAdapter.ViewHolder>() {

    var onItemClick: OnItemClickListenerRecyclerView? = null

    fun removeItem(position: Int) {
        this.mData?.removeAt(position)
        notifyDataSetChanged()
    }

    fun addAll(mData: ArrayList<Credit>) {
        this.mData?.addAll(mData)
        notifyDataSetChanged()
    }

    fun clear() {
        this.mData?.clear()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(mContext).inflate(R.layout.custom_item_customer_credit, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return mData?.size!!
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tv_credit_id.setValue(mData?.get(position)?.idCredit)
        holder.tv_date.setValue(mData?.get(position)?.date)
        holder.tv_agency.setValue(mData?.get(position)?.note)
        holder.tv_guarantee.setValue("${GlobalApp.getInstance().decimalFormat.format(mData?.get(position)?.guaranteeAmount)} VNĐ")
        holder.btn_guarantee.isSelected = true
        holder.btn_reject.isSelected = true
        holder.btn_guarantee.setOnClickListener { view ->
            onItemClick?.onClick(view, position)
        }
        holder.btn_reject.setOnClickListener { view ->
            onItemClick?.onClick(view, position)
        }
        holder.itemView.setOnClickListener { view ->
            onItemClick?.onClick(view, position)
        }
        when (mData?.get(position)?.status) {
            "1" -> {
                holder.btn_guarantee.visibility = View.INVISIBLE
                holder.btn_reject.setBackgroundResource(R.drawable.background_button_blue)
                holder.btn_reject.text = "Đã bảo lãnh"
                holder.btn_reject.setOnClickListener(null)
            }
            "2" -> {
                holder.btn_guarantee.visibility = View.INVISIBLE
                holder.btn_reject.setBackgroundResource(R.drawable.background_button_red)
                holder.btn_reject.text = "Đã từ chối"
                holder.btn_reject.setOnClickListener(null)
            }
            else -> {
                holder.control.visibility = View.VISIBLE
                if (mData?.get(position)?.idApprove.equals(GlobalApp.getInstance().profile?.uid)) {
                    holder.btn_guarantee.visibility = View.VISIBLE
                    holder.btn_reject.setBackgroundResource(R.drawable.background_button_red)
                    holder.btn_reject.text = "Từ chối"
                } else {
                    holder.btn_guarantee.visibility = View.INVISIBLE
                    holder.btn_reject.setBackgroundResource(R.drawable.background_button_red)
                    holder.btn_reject.text = "Từ chối"
                }
            }
        }
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tv_credit_id = view.findViewById<TextLabel>(R.id.tv_credit_id)
        val tv_date = view.findViewById<TextLabel>(R.id.tv_date)
        val tv_agency = view.findViewById<TextLabel>(R.id.tv_agency)
        val tv_guarantee = view.findViewById<TextLabel>(R.id.tv_guarantee)
        val control = view.findViewById<LinearLayout>(R.id.control)
        val btn_guarantee = view.findViewById<AppCompatTextView>(R.id.btn_guarantee)
        val btn_reject = view.findViewById<AppCompatTextView>(R.id.btn_reject)
    }
}