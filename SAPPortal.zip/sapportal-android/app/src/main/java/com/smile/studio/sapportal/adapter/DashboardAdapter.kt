package com.smile.studio.sapportal.adapter

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.widget.AppCompatTextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.libsmilestudio.utils.AndroidDeviceInfo
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.model.Dashboard

class DashboardAdapter(val mContext: Context?, val mData: ArrayList<Dashboard>?) : RecyclerView.Adapter<DashboardAdapter.ViewHolder>() {

    var onItemClick: OnItemClickListenerRecyclerView? = null
    var width = 0
    var height = 0

    init {
        val point = AndroidDeviceInfo.getScreenSize(mContext)
        width = point.x
        height = width * 7 / 21
    }

    fun addAll(mData: ArrayList<Dashboard>) {
        this.mData?.clear()
        this.mData?.addAll(mData)
        notifyDataSetChanged()
    }

    fun clear() {
        this.mData?.clear()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(mContext).inflate(R.layout.custom_item_dashboard, parent, false)
        view.layoutParams = ViewGroup.LayoutParams(width, height)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return mData?.size!!
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.cardView.setCardBackgroundColor(Color.parseColor(GlobalApp.getInstance().colors.get(position%10)))
        holder.tv_value.text = mData?.get(position)?.value.toString()
        holder.tv_descriptionn.text = mData?.get(position)?.text
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val cardView = view.findViewById<CardView>(R.id.cardView)
        val tv_value = view.findViewById<TextView>(R.id.tv_value)
        val tv_descriptionn = view.findViewById<TextView>(R.id.tv_descriptionn)
    }
}