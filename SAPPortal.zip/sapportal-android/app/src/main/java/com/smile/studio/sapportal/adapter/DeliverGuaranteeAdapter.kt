package com.smile.studio.sapportal.adapter

import android.content.Context
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.appcompat.widget.AppCompatTextView
import androidx.recyclerview.widget.RecyclerView
import com.smile.studio.libsmilestudio.recyclerviewer.OnItemClickListenerRecyclerView
import com.smile.studio.libsmilestudio.utils.Debug
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.model.GlobalApp
import com.smile.studio.sapportal.network.model.Deliver
import com.smile.studio.sapportal.view.TextLabel

class DeliverGuaranteeAdapter(val mContext: Context?, val mData: ArrayList<Deliver>?) : RecyclerView.Adapter<DeliverGuaranteeAdapter.ViewHolder>() {

    var onItemClick: OnItemClickListenerRecyclerView? = null

    fun removeItem(position: Int) {
        this.mData?.removeAt(position)
        notifyDataSetChanged()
    }

    fun addAll(mData: ArrayList<Deliver>) {
        this.mData?.addAll(mData)
        notifyDataSetChanged()
    }

    fun clear() {
        this.mData?.clear()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(mContext).inflate(R.layout.custom_item_customer_delvier_guarantee, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return mData?.size!!
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tv_credit_id.setValue(mData?.get(position)?.idOrder)
        holder.tv_date.setValue(mData?.get(position)?.date)
        holder.tv_agency.setValue(mData?.get(position)?.nameShipTo)
        holder.tv_max_money.setValue("${GlobalApp.getInstance().decimalFormat.format(mData?.get(position)?.guaranteeAmount)} VNĐ")
        holder.btn_approve.isSelected = true
        holder.btn_reject.isSelected = true
        if ((mData?.get(position)?.statusbl.equals("X") && mData?.get(position)?.status?.equals("B")!!) ||
                (mData?.get(position)?.statusbl.equals("X") && mData?.get(position)?.status?.equals("S")!!)) {
            holder.btn_reject.text = "Đã bảo lãnh"
            holder.btn_approve.visibility = View.INVISIBLE
            holder.btn_reject.setBackgroundResource(R.drawable.background_button_blue)
        } else if (TextUtils.isEmpty(mData?.get(position)?.statusbl)) {
            Debug.e("---  Chưa bảo lãnh")
            holder.btn_approve.visibility = View.VISIBLE
            holder.btn_reject.text = mContext?.getString(R.string.title_credit_reject)
            holder.btn_reject.setBackgroundResource(R.drawable.background_button_red)
        }
        holder.btn_approve.setOnClickListener { view ->
            onItemClick?.onClick(view, position)
        }
        holder.btn_reject.setOnClickListener { view ->
            onItemClick?.onClick(view, position)
        }
        holder.itemView.setOnClickListener { view ->
            onItemClick?.onClick(view, position)
        }
    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tv_credit_id = view.findViewById<TextLabel>(R.id.tv_deliver_guarantee_id)
        val tv_date = view.findViewById<TextLabel>(R.id.tv_date)
        val tv_agency = view.findViewById<TextLabel>(R.id.tv_agency)
        val tv_max_money = view.findViewById<TextLabel>(R.id.tv_guarantee)
        val btn_approve = view.findViewById<AppCompatTextView>(R.id.btn_approve)
        val btn_reject = view.findViewById<AppCompatTextView>(R.id.btn_reject)
    }
}