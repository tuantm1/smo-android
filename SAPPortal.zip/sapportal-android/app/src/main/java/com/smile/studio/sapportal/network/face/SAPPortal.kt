package com.smile.studio.sapportal.network.face

import com.google.gson.JsonObject
import com.smile.studio.sapportal.network.model.*
import com.smile.studio.sapportal.network.request.*
import com.smile.studio.sapportal.network.response.*
import com.smile.studio.sapportal.network.zip.ZipFilter
import io.reactivex.Observable
import okhttp3.ResponseBody
import retrofit2.http.*
import java.util.*
import kotlin.collections.ArrayList

interface SAPPortal {

    /**
     * Lấy thông tin loại phí
     */
    @GET("GET_LOAIPHI")
    fun getCharges() : Observable<BaseResponse<ArrayList<Charge>>>

    /**
     * Lấy thông tin ngày dự kiến giao hàng
     */
    @POST("get_mara")
    fun getEsitmateDelive(@Body body: ReasonRequest): Observable<BaseResponse<ArrayList<Items>>>

    /**
     * Thực hiện xác nhận bảo lãnh đơn hàng vượt hạn mức
     */
    @POST("create_credit")
    fun createCredit(@Body body: CreditRequest): Observable<ResponseBody>

    /**
     * Gửi thông tin tạo đơn hàng
     */
    @POST("create_order")
    fun createOrder(@Body body: OrderRequest): Observable<BaseResponse<String>>

    /**
     * Lấy thông tin convert thuộc tính
     */
    @FormUrlEncoded
    @POST("get_characteristic_default")
    fun getCharacteristicDefault(@Field("matnr") matnr: String): Observable<BaseResponse<ArrayList<CharacteristicsItem>>>

    /**
     * Lấy thông tin giá đơn đặt hàng
     */
    @POST("check_price")
    fun checkPrice(@Body body: OrderRequest): Observable<Price>

    /**
     * POST Info data selection
     */
    @POST("mapping_mara")
    fun mappingMara(@Body body: ReasonRequest): Observable<Value2Item>

    /**
     * Lấy thông tin chi tiết danh sách thanh ray
     */
    @FormUrlEncoded
    @POST("get_mapping_thanhray")
    fun getFilterThanhRay(@Field("ID_ITEM_MASTER") idItemMaster: String): Observable<BaseResponse<ArrayList<Value2Item>>>

    /**
     * Lấy thông tin chi tiết danh sách bộ tời
     */
    @FormUrlEncoded
    @POST("get_mapping_botoi")
    fun getFilterBoToi(@Field("ID_ITEM_MASTER") idItemMaster: String): Observable<BaseResponse<ArrayList<Value2Item>>>

    /**
     * Lấy thông tin chi tiết danh sách thuộc tính
     */
    @FormUrlEncoded
    @POST("get_mat_refer")
    fun getFilterAttributes(@Field("matnr") objek: String): Observable<BaseResponse<ArrayList<Value2Item>>>

    /**
     * Lấy thông tin chi tiết danh sách thuộc tính
     */
    @FormUrlEncoded
    @POST("get_characteristic")
    fun getCharacteristic(@Field("OBJEK") objek: String): Observable<AttributesResponse>

    /**
     * Lấy thông tin cấu hình đơn hàng
     */
    @FormUrlEncoded
    @POST("get_detail_temp")
    fun getDetailTemp(@Field("ID_TEMP") idTemp: String): Observable<BaseResponse<DetailProperties>>

    /**
     * Lấy thông tin đơn đặt hàng mẫu
     */
    @POST("GET_TEMP")
    fun getSampleOrder(@Body idUser: ReasonRequest): Observable<BaseResponse<ArrayList<SampleOrder>>>

    /**
     * Lấy thông tin ngành hàng
     */
    @POST("get_division")
    fun getIndustryInformation(): Observable<BaseResponse<ArrayList<Sale>>>

    /**
     * Lấy thông tin ngành hàng
     */
    @FormUrlEncoded
    @POST("get_dc")
    fun getSaleChannel(@Field("kunnr") kunnr: String): Observable<BaseResponse<ArrayList<Sale>>>

    /**
     * Lấy danh sách thông tin đơn vị bán hàng
     */
    @FormUrlEncoded
    @POST("get_sale_org")
    fun getSaleOrgin(@Field("kunnr") kunnr: String): Observable<BaseResponse<ArrayList<Sale>>>

    /**
     * Lấy thông tin danh sách đường phố, quận huyện
     */
    @GET("get_route")
    fun getRoute(): Observable<RouterResponse>

    /**
     * Update status deliver
     */
    @POST("SD_TTCVT_1")
    fun updateDeliver(@Body deliverUpdate: DetailRequest): Observable<BaseResponse<Objects>>

    /**
     * Danh sách đơn hàng
     */
    @FormUrlEncoded
    @POST("get_order")
    fun getListDeliver(@Field("id_user") idUser: String): Observable<BaseResponse<ArrayList<Deliver>>>

    /**
     * Danh sách đơn hàng cần bảo lãnh
     */
    @POST("credit")
    fun getListDeliverGuarantee(@Body reason: ReasonRequest): Observable<BaseResponse<ArrayList<Deliver>>>

    /** ***START***DETAIL***CREDIT*** **/
    /**
     * Lấy thông tin chi tiết sản phẩm đặt hàng
     */
    @POST("get_detail_order")
    fun getDetailOrder(@Body reason: ReasonRequest): Observable<BaseResponse<Deliver>>

    /**
     * Lấy thông tin bảo lãnh SX còn lại
     */
    @POST("get_division")
    fun getDivision(@Body reason: ReasonRequest): Observable<DetailDivision>

    /**
     * Lấy thông tin bảo lãnh SX còn lại
     */
    @POST("get_detail_bl")
    fun getDetailCredit(@Body reason: ReasonRequest): Observable<BaseResponse<Credit>>

    /**
     * Thông tin người bảo lãnh
     */
    @POST("get_detail_user_bl")
    fun getUserCredit(@Body reason: ReasonRequest): Observable<DetailUserCredit>
    /** ***END***DETAIL***CREDIT*** **/

    /**
     * Xác nhận đồng ý bảo lãnh
     */
    @POST("approve_order")
    fun approveOrder(@Body reason: ReasonRequest): Observable<BaseResponse<Object>>

    /**
     * Từ chối bảo lãnh
     */
    @POST("reject_credit")
    fun rejectReason(@Body reason: ReasonRequest): Observable<BaseResponse<Object>>

    /**
     * Danh sách yêu cầu bảo lãnh
     */
    @FormUrlEncoded
    @POST("approve_credit_list")
    fun getListApproveCredit(@Field("ID_USER") idUser: String): Observable<BaseResponse<ArrayList<Credit>>>

    /**
     * Thông tin chi tiết khách hàng
     */
    @FormUrlEncoded
    @POST("get_detail_customer")
    fun getDetailCustomers(@Field("KUNNR") idUser: String): Observable<BaseResponse<DetailCustomer>>

    /**
     * Lấy danh sách khách hàng & công nợ
     */
    @GET("get_customer")
    fun getListCustomers(@Query("ID_USER") idUser: String): Observable<BaseResponse<ArrayList<Customer>>>

    /**
     * Lấy danh sách sản phẩm và thuộc tính
     */
    @POST("get_mara")
    fun getListProductProperties(@Body request: ReasonRequest): Observable<BaseResponse<ArrayList<Items>>>

    /**
     * Lấy thông tin file DPF
     */
    @POST("khgh")
    fun getPDFToBase64(@Body deliverPDFRequest: DeliverPDFRequest): Observable<PDFResponse>

    /**
     * Get Image Detail Deliver
     */
    @GET("get_image")
    fun getImage(@Query("so_number") saleOrder: String): Observable<BaseResponse<ImageResponse>>

    /**
     * Upload file image có cắt chuỗi hình ảnh
     */
    @POST("upload")
    fun uploadFile(@Body jsonObject: JsonObject): Observable<BaseResponse<Objects>>

    /**
     * Upload file image
     */
    @POST("upload")
    fun uploadFile(@Body uploadFileRequest: UploadFileReqeust): Observable<BaseResponse<Objects>>

    /**
     * Lấy danh sách lịch giao hàng
     */
    @GET("sd_ttcvt_1")
    fun getListDeliver(@Query("I_MACVT") macvt: String, @Query("I_NGAYGIAO") date: String, @Query("I_MACHUYEN") machuyen: String, @Query("I_TT_GH") ttgh: Int): Observable<DeliverResponse>

    /**
     * Lấy thông tin chi tiết người dùng
     */
    @POST("get_detail_user")
    fun getDetailUser(@Body reason: ReasonRequest): Observable<DetailProfileResponse>

    /**
     * Lấy danh sách tài khoản người dùng quản lý
     */
    @GET("get_user")
    fun getListUser(@Query("id_user") uid: String): Observable<ListUserResponse>

    /**
     * Đổi mật khẩu
     */
    @POST("changepassword")
    fun changePassword(@Body changePassword: ChangePasswordRequest): Observable<ProfileResponse>

    /**
     * Đăng nhập thông tin tài khoản
     */
    @POST("login")
    fun login(@Body userlogin: User): Observable<ProfileResponse>

    /**
     * Lấy danh sách dasbroad
     */
    @FormUrlEncoded
    @POST("get_dashboard")
    fun getDashboard(@Field("id_user") uid: String): Observable<BaseResponse<ArrayList<Dashboard>>>
}