package com.smile.studio.sapportal.network.response

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ImageResponse(

	@field:SerializedName("ID_ORDER")
	val idOrder: String? = null,

	@field:SerializedName("SO_NUMBER")
	val saleOderNumber: String? = null,

	@field:SerializedName("ZIMAGE")
	val image: String? = null
) : Parcelable
