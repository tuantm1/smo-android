package com.smile.studio.sapportal.fragment.order.create

import android.os.Bundle
import com.smile.studio.sapportal.R
import com.smile.studio.sapportal.activity.BaseActivity
import com.smile.studio.sapportal.network.model.DetailProperties

class ConfirmOrderActivity : BaseActivity() {

    companion object{
        val HAVE_ATTRIBUTES = "haveAttributes"
    }

    lateinit var dataTranfer: DetailProperties

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_confirm_order)
        val haveAttributes = intent.getBooleanExtra(HAVE_ATTRIBUTES, false)
        dataTranfer = intent.getParcelableExtra<DetailProperties>(DetailProperties::class.java.simpleName)!!
        shareViewModel?.setData(dataTranfer)
        onChangeFragment(ConfirmOrderFragment.newInstance(haveAttributes), "")
    }

}


