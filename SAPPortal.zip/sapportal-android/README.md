# MyAustdoor

Ứng dụng trên cổng Portal được tích hợp với phần mềm SAP code trên mô hình MVC Architecture pattern using Kotlin.

## Screenshots
![login](screenshots/login.png)
![homescreen](screenshots/home.png)
![manager](screenshots/manager.png)
![create-order](screenshots/create-order.png)

## Features

  - [x] Đăng nhập thông tin tài khoản MyAustdoor
  - [x] Hiển thị thông tin, phân quyền tài khoản đăng nhập
  - [x] Tạo và phê duyệt thông tin đơn hàng bảo lãnh
  - [x] Quản lý và theo dõi thông tin đơn hàng trên hệ thống

## Requirement
Android SDK >= 26

## Test case

## APK file here
[download a released apk](https://github.com/longquangpham90/sapportal-android/releases)

## Copyright & License
Copyright (c) 2020 SAPPortal. All rights reserved.
